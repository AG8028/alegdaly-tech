import { useEffect, useMemo, useState } from 'react'
import {
  Building2, Clock, CheckCircle2, XCircle, Settings2, Copy, Check, MessageCircle,
  Pause, Play, Phone, MapPin, Users, Coins, ExternalLink, BellRing, BellOff, Mail, Smartphone, ChevronDown, Trash2, X,
} from 'lucide-react'
import { schedule } from '../lib/schedule'
import { triggers } from '../lib/triggers'
import { push } from '../lib/push'
import { auth } from '../lib/auth'
import { db } from '../lib/db'
import { social } from '../lib/social'
import { share } from '../lib/share'
import { useLiveShared } from '../lib/useLive'
import { useSession } from '../components/Session'
import { Card, SectionTitle, Field, fieldCls, PrimaryBtn, GhostBtn, Spinner, EmptyState, useToast } from '../components/ui'
import MoneyInput from '../components/MoneyInput'
import { tr, useLang } from '../components/i18n'
import { copyText } from '../components/credentials'
import {
  CFG_COLL, CFG_ID, REQ_COLL, OFFICE_COLL, STATUS_COLL, OFFICES_LINK, PLANS, planOf,
  addMonths, daysLeft, officeState, fmtNum, fmtDate, dayOf,
} from '../components/saas'

/** رسالة التذكير الموحّدة للمكتب (واتساب يدوي) */
function renewText(o, cfg) {
  const d = daysLeft(o.expiresAt)
  const head = d > 0
    ? tr('مرحباً {name}، اشتراك مكتبكم «{office}» في ALEGDALY TECH ينتهي بعد {n} يوم.', { name: o.ownerName || '', office: o.officeName, n: d })
    : tr('مرحباً {name}، انتهى اشتراك مكتبكم «{office}» في ALEGDALY TECH وتم قفل المساحة مؤقتاً.', { name: o.ownerName || '', office: o.officeName })
  return `${head}\n${tr('للتجديد من هنا:')} ${OFFICES_LINK}${cfg?.nitaNumber ? `\nNITA: ${cfg.nitaNumber}` : ''}${cfg?.amanaNumber ? `\nAMANA: ${cfg.amanaNumber}` : ''}`
}

const DAY_STEPS = [7, 3, 1]

/**
 * تذكيرات تلقائية من السيرفر (تعمل والتطبيق مغلق):
 * - بريد للمكتب قبل الانتهاء بـ 7 و 3 و 1 يوم
 * - إشعار يومي لك بالمكاتب التي تنتهي قريباً
 */
function RemindersCard({ cfg, gid }) {
  const toast = useToast()
  const [busy, setBusy] = useState(false)
  const rem = cfg?.reminders || null
  const on = !!rem?.ids?.length
  const diag = push.diagnose()
  const { lang } = useLang()

  async function enable() {
    if (busy || !gid) return
    const me = auth.getCurrentUser()
    if (!me) {
      toast(tr('سجّل دخولك بحساب المالك أولاً'), 'err')
      return
    }
    setBusy(true)
    const ids = []
    try {
      const contact = cfg?.whatsapp ? `\n${tr('واتساب:')} ${cfg.whatsapp}` : ''
      for (const n of DAY_STEPS) {
        const r = await schedule.create({
          daily: '09:00',
          action: 'email',
          to: { collection: OFFICE_COLL, field: 'email' },
          when: { dateField: 'expiresDay', inDays: n },
          subject: n === 1
            ? 'ALEGDALY TECH — اشتراك {{officeName}} ينتهي غداً'
            : `ALEGDALY TECH — اشتراك {{officeName}} ينتهي بعد ${n} أيام`,
          body:
            `مرحباً {{ownerName}}،\n\nاشتراك مكتبكم «{{officeName}}» في ALEGDALY TECH ينتهي يوم {{expiresDay}}.\n` +
            'عند الانتهاء تُقفل مساحة المكتب وشاشات الوكلاء حتى التجديد، وتبقى كل بياناتكم محفوظة.\n\n' +
            `للتجديد: ${OFFICES_LINK}${contact}\n\nALEGDALY TECH`,
        })
        ids.push(r.id)
      }
      const r = await schedule.create({
        daily: '09:00',
        action: 'push',
        target: { userId: me.id },
        source: {
          collection: OFFICE_COLL,
          filters: { status: { ne: 'suspended' } },
          window: { dateField: 'expiresDay', days: 7, from: -3 },
          sort: { field: 'expiresDay', dir: 'asc' },
        },
        title: '⏳ {{count}} مكتب ينتهي اشتراكه قريباً',
        body: '{{#rows}}• {{officeName}} — {{daysUntil.expiresDay}} يوم\n{{/rows}}',
        url: '#/sales',
      })
      ids.push(r.id)
      await db.upsertShared(CFG_COLL, { reminders: { ids, since: new Date().toISOString() } }, CFG_ID, { groupId: gid, writableBy: 'admins' })
      toast(tr('تم تفعيل التذكيرات التلقائية'))
    } catch (e) {
      for (const id of ids) await schedule.cancel(id).catch(() => {})
      toast(e?.message || tr('حدث خطأ، حاول مرة أخرى'), 'err')
    } finally {
      setBusy(false)
    }
  }

  async function disable() {
    if (busy || !gid) return
    setBusy(true)
    try {
      for (const id of rem?.ids || []) await schedule.cancel(id).catch(() => {})
      await db.upsertShared(CFG_COLL, { reminders: null }, CFG_ID, { groupId: gid, writableBy: 'admins' })
      toast(tr('تم إيقاف التذكيرات'), 'info')
    } catch (e) {
      toast(e?.message || tr('حدث خطأ، حاول مرة أخرى'), 'err')
    } finally {
      setBusy(false)
    }
  }

  async function enablePush() {
    try {
      if (!diag.canSchedule) {
        toast(diag.hint || tr('الإشعارات لا تعمل في المعاينة — جرّبها من التطبيق المنشور'), 'info')
        return
      }
      const p = await push.requestPermission()
      if (p !== 'granted') {
        toast(tr('لم يتم السماح بالإشعارات'), 'err')
        return
      }
      await push.subscribe()
      const res = await push.send(null, { title: '✅ ALEGDALY TECH', body: tr('الإشعارات تعمل على هذا الجهاز'), url: '#/sales' })
      toast(res?.sent > 0 ? tr('تم تفعيل الإشعارات على هذا الجهاز') : tr('تم السماح، لكن لم يصل إشعار التجربة'), res?.sent > 0 ? undefined : 'info')
    } catch (e) {
      toast(e?.message || tr('حدث خطأ، حاول مرة أخرى'), 'err')
    }
  }

  return (
    <Card className="p-5">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <BellRing size={18} className="text-amber-300" />
          <h3 className="font-display text-[16px] font-extrabold text-white">{tr('تذكير قبل انتهاء الاشتراك')}</h3>
        </div>
        <span className={`flex items-center gap-2 rounded-full px-3 py-1.5 text-[12px] font-extrabold ${on ? 'bg-emerald-500/20 text-emerald-200' : 'bg-white/[0.06] text-slate-400'}`}>
          <span className={`h-2 w-2 rounded-full ${on ? 'bg-emerald-400' : 'bg-slate-500'}`} />
          {on ? tr('مفعّلة') : tr('متوقفة')}
        </span>
      </div>

      <div className="mt-4 space-y-2.5 text-[12.5px] leading-relaxed text-slate-300">
        <p className="flex items-start gap-2"><Mail size={15} className="mt-0.5 shrink-0 text-emerald-300" />{tr('بريد تلقائي لصاحب المكتب قبل الانتهاء بـ 7 أيام ثم 3 أيام ثم يوم واحد، فيه رابط التجديد.')}</p>
        <p className="flex items-start gap-2"><BellRing size={15} className="mt-0.5 shrink-0 text-amber-300" />{tr('إشعار لك كل صباح 9:00 بالمكاتب التي تنتهي خلال أسبوع أو انتهت حديثاً.')}</p>
        <p className="flex items-start gap-2"><MessageCircle size={15} className="mt-0.5 shrink-0 text-emerald-300" />{tr('وفي قائمة المكاتب زر واتساب جاهز لتذكير أي مكتب بنفسك.')}</p>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        {on ? (
          <GhostBtn onClick={disable} disabled={busy}>
            <span className="inline-flex items-center gap-1.5"><BellOff size={15} />{busy ? tr('جارٍ الإيقاف...') : tr('إيقاف التذكيرات')}</span>
          </GhostBtn>
        ) : (
          <PrimaryBtn onClick={enable} disabled={busy}>
            {busy ? tr('جارٍ التفعيل...') : tr('تفعيل التذكيرات التلقائية')}
          </PrimaryBtn>
        )}
        <button
          type="button"
          onClick={enablePush}
          className="inline-flex items-center gap-1.5 rounded-xl border border-white/12 bg-white/[0.04] px-3.5 py-2.5 text-[12.5px] font-bold text-slate-200 hover:bg-white/[0.08]"
        >
          <Smartphone size={15} /> {tr('استقبال الإشعارات على هذا الجهاز')}
        </button>
      </div>
      {on && rem?.since ? (
        <p className="mt-3 text-[11px] text-slate-500">{tr('تعمل لمدة سنة من {date} — بعدها أوقفها وفعّلها مرة أخرى.', { date: fmtDate(rem.since, lang) })}</p>
      ) : null}
      <p className="mt-1.5 text-[11px] text-slate-500">{tr('الإشعار يصلك فقط على هاتف فتحت فيه التطبيق المنشور وسمحت بالإشعارات.')}</p>
    </Card>
  )
}

function Stat({ icon: Icon, label, value, tone }) {
  return (
    <Card className="p-4">
      <span className={`flex h-9 w-9 items-center justify-center rounded-xl ${tone}`}>
        <Icon size={17} />
      </span>
      <p className="mt-3 text-[11.5px] font-bold text-slate-400">{label}</p>
      <p className="font-display mt-0.5 text-[21px] font-black tabular-nums text-white">{value}</p>
    </Card>
  )
}

/** شريط واضح أعلى الصفحة: فتح/إغلاق الاشتراكات بضغطة واحدة (يُحفظ فوراً) */
function OpenSwitch({ cfg, gid }) {
  const toast = useToast()
  const [busy, setBusy] = useState(false)
  const isOpen = !!cfg?.open

  async function flip() {
    if (busy || !gid) return
    const next = !isOpen
    if (next) {
      if (!PLANS.some((p) => Number(cfg?.[p.priceField]) > 0)) {
        toast(tr('اكتب سعر باقة واحدة على الأقل في «إعدادات البيع» واحفظ أولاً'), 'err')
        return
      }
      if (!cfg?.nitaNumber && !cfg?.amanaNumber) {
        toast(tr('أضف رقم استلام NITA أو AMANA في «إعدادات البيع» واحفظ أولاً'), 'err')
        return
      }
    }
    setBusy(true)
    try {
      await db.upsertShared(CFG_COLL, { open: next }, CFG_ID, { groupId: gid, writableBy: 'admins' })
      toast(next ? tr('تم فتح الاشتراكات — المكاتب ترى الباقات الآن') : tr('تم إغلاق الاشتراكات'))
    } catch (e) {
      toast(e?.message || tr('حدث خطأ، حاول مرة أخرى'), 'err')
    } finally {
      setBusy(false)
    }
  }

  return (
    <Card
      className={`flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between ${
        isOpen ? 'border-emerald-400/30 bg-emerald-500/[0.07]' : 'border-amber-400/40 bg-amber-500/[0.08]'
      }`}
    >
      <div className="flex items-start gap-3">
        <span className={`mt-1 h-3 w-3 shrink-0 rounded-full ${isOpen ? 'bg-emerald-400' : 'bg-amber-400'}`} />
        <div>
          <p className={`font-display text-[15px] font-extrabold ${isOpen ? 'text-emerald-200' : 'text-amber-200'}`}>
            {isOpen ? tr('الاشتراكات مفتوحة') : tr('الاشتراكات مغلقة')}
          </p>
          <p className="mt-0.5 text-[12px] leading-relaxed text-slate-400">
            {isOpen
              ? tr('المكاتب ترى الباقات والأسعار وتستطيع الدفع وإرسال الطلب.')
              : tr('المكاتب ترى «الاشتراكات ستُفتح قريباً» فقط، ولا ترى الباقات. اضغط الزر لفتحها.')}
          </p>
        </div>
      </div>
      <button
        type="button"
        onClick={flip}
        disabled={busy}
        className={`inline-flex min-h-[44px] shrink-0 items-center justify-center gap-2 rounded-2xl px-5 text-[13.5px] font-extrabold transition disabled:opacity-60 ${
          isOpen
            ? 'border border-white/15 bg-white/[0.05] text-slate-200 hover:bg-white/[0.1]'
            : 'bg-gradient-to-br from-emerald-400 to-emerald-600 text-[#03140c] hover:brightness-110'
        }`}
      >
        {isOpen ? <Pause size={16} /> : <Play size={16} />}
        {busy ? tr('جارٍ الحفظ...') : isOpen ? tr('إغلاق الاشتراكات') : tr('افتح الاشتراكات الآن')}
      </button>
    </Card>
  )
}

/** إعدادات البيع: الأسعار وأرقام الاستلام */
function SettingsCard({ cfg, gid }) {
  const toast = useToast()
  const [f, setF] = useState(null)
  const [busy, setBusy] = useState(false)
  const [expanded, setExpanded] = useState(false)

  useEffect(() => {
    setF({
      price1: cfg?.price1 ? String(cfg.price1) : '',
      price3: cfg?.price3 ? String(cfg.price3) : '',
      price12: cfg?.price12 ? String(cfg.price12) : '',
      nitaNumber: cfg?.nitaNumber || '',
      nitaName: cfg?.nitaName || '',
      amanaNumber: cfg?.amanaNumber || '',
      amanaName: cfg?.amanaName || '',
      whatsapp: cfg?.whatsapp || '',
    })
  }, [cfg])

  if (!f) return null
  const set = (k) => (e) => setF((x) => ({ ...x, [k]: e.target.value }))

  async function save() {
    if (busy || !gid) return
    const isOpen = !!cfg?.open
    if (isOpen && !(Number(f.price1) || Number(f.price3) || Number(f.price12))) {
      toast(tr('حدّد سعر باقة واحدة على الأقل'), 'err')
      return
    }
    if (isOpen && !f.nitaNumber.trim() && !f.amanaNumber.trim()) {
      toast(tr('أضف رقم استلام NITA أو AMANA'), 'err')
      return
    }
    setBusy(true)
    try {
      await db.upsertShared(
        CFG_COLL,
        {
          price1: Number(f.price1) || 0,
          price3: Number(f.price3) || 0,
          price12: Number(f.price12) || 0,
          nitaNumber: f.nitaNumber.trim(),
          nitaName: f.nitaName.trim(),
          amanaNumber: f.amanaNumber.trim(),
          amanaName: f.amanaName.trim(),
          whatsapp: f.whatsapp.trim(),
        },
        CFG_ID,
        { groupId: gid, writableBy: 'admins' },
      )
      toast(tr('تم حفظ الإعدادات'))
      setExpanded(false)
    } catch (e) {
      toast(e?.message || tr('حدث خطأ، حاول مرة أخرى'), 'err')
    } finally {
      setBusy(false)
    }
  }

  return (
    <Card className="p-5">
      <button
        type="button"
        onClick={() => setExpanded((v) => !v)}
        aria-expanded={expanded}
        className="flex w-full items-center gap-2 text-start"
      >
        <Settings2 size={18} className="shrink-0 text-amber-300" />
        <span className="min-w-0 flex-1">
          <span className="font-display block text-[16px] font-extrabold text-white">{tr('إعدادات البيع')}</span>
          {!expanded ? (
            <span className="mt-0.5 block truncate text-[11.5px] text-slate-500">
              {[
                ...PLANS.filter((p) => Number(cfg?.[p.priceField])).map((p) => `${tr(p.label)}: ${Number(cfg[p.priceField]).toLocaleString('en-US')}`),
                cfg?.nitaNumber ? `NITA ${cfg.nitaNumber}` : null,
                cfg?.amanaNumber ? `AMANA ${cfg.amanaNumber}` : null,
              ].filter(Boolean).join(' · ') || tr('اضغط لتحديد الأسعار وأرقام الاستلام')}
            </span>
          ) : null}
        </span>
        <span className="flex shrink-0 items-center gap-1 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5 text-[11.5px] font-bold text-slate-300">
          {expanded ? tr('إخفاء') : tr('تعديل')}
          <ChevronDown size={14} className={`transition ${expanded ? 'rotate-180' : ''}`} />
        </span>
      </button>

      {expanded ? (
      <>
      <p className="mt-4 text-[12px] font-extrabold tracking-wider text-amber-300/90">{tr('الأسعار (FCFA)')}</p>
      <div className="mt-2 grid grid-cols-3 gap-2.5">
        {PLANS.map((p) => (
          <Field key={p.key} label={tr(p.label)}>
            <MoneyInput value={f[p.priceField]} onChange={(v) => setF((x) => ({ ...x, [p.priceField]: v }))} className={fieldCls} placeholder="0" />
          </Field>
        ))}
      </div>
      <p className="mt-1.5 text-[11px] text-slate-500">{tr('اترك السعر فارغاً لإخفاء الباقة.')}</p>

      <p className="mt-5 text-[12px] font-extrabold tracking-wider text-amber-300/90">{tr('أرقام استلام الدفع')}</p>
      <div className="mt-2 grid grid-cols-1 gap-2.5 sm:grid-cols-2">
        <Field label={tr('رقم NITA')}>
          <input value={f.nitaNumber} onChange={set('nitaNumber')} dir="ltr" inputMode="tel" className={`${fieldCls} text-start`} />
        </Field>
        <Field label={tr('الاسم على NITA')}>
          <input value={f.nitaName} onChange={set('nitaName')} className={fieldCls} />
        </Field>
        <Field label={tr('رقم AMANA')}>
          <input value={f.amanaNumber} onChange={set('amanaNumber')} dir="ltr" inputMode="tel" className={`${fieldCls} text-start`} />
        </Field>
        <Field label={tr('الاسم على AMANA')}>
          <input value={f.amanaName} onChange={set('amanaName')} className={fieldCls} />
        </Field>
        <Field label={tr('واتساب للتواصل')} hint={tr('مع رمز الدولة، مثال: 227XXXXXXXX')}>
          <input value={f.whatsapp} onChange={set('whatsapp')} dir="ltr" inputMode="tel" className={`${fieldCls} text-start`} />
        </Field>
      </div>

      <PrimaryBtn className="mt-5" onClick={save} disabled={busy}>
        {busy ? tr('جارٍ الحفظ...') : tr('حفظ الإعدادات')}
      </PrimaryBtn>
      </>
      ) : null}
    </Card>
  )
}

const LINK_FOLD_KEY = 'alegdaly-linkcard-folded'

function LinkCard() {
  const [copied, setCopied] = useState(false)
  const [folded, setFolded] = useState(() => {
    try { return localStorage.getItem(LINK_FOLD_KEY) === '1' } catch { return false }
  })
  const setFold = (v) => {
    setFolded(v)
    try { localStorage.setItem(LINK_FOLD_KEY, v ? '1' : '0') } catch { /* ignore */ }
  }
  if (folded) {
    return (
      <button
        type="button"
        onClick={() => setFold(false)}
        className="skin-gold flex w-full items-center justify-between gap-2 rounded-2xl border border-amber-300/20 bg-gradient-to-br from-[#14203a] to-[#0a1222] px-4 py-3 text-start transition hover:border-amber-300/40"
      >
        <span className="text-[12px] font-extrabold text-amber-300/90">{tr('صفحة الاشتراك للمكاتب')}</span>
        <ChevronDown size={16} className="text-amber-200/80" />
      </button>
    )
  }
  return (
    <Card className="skin-gold relative flex flex-col gap-3 border-amber-300/20 bg-gradient-to-br from-[#14203a] to-[#0a1222] p-5 sm:flex-row sm:items-center sm:justify-between">
      <button
        type="button"
        onClick={() => setFold(true)}
        aria-label="close"
        className="absolute end-3 top-3 flex h-8 w-8 items-center justify-center rounded-full border border-white/10 bg-white/[0.05] text-slate-300 transition hover:bg-white/[0.12] hover:text-white"
      >
        <X size={15} />
      </button>
      <div className="min-w-0 pe-9">
        <p className="text-[11px] font-extrabold tracking-wider text-amber-300/90">{tr('صفحة الاشتراك للمكاتب')}</p>
        <p dir="ltr" className="lux-latin mt-1 truncate text-[13px] font-bold text-amber-100">{OFFICES_LINK.replace('https://', '')}</p>
      </div>
      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          onClick={async () => {
            if ((await copyText(OFFICES_LINK)) !== false) {
              setCopied(true)
              setTimeout(() => setCopied(false), 1600)
            }
          }}
          className="inline-flex items-center gap-1.5 rounded-full border border-white/12 bg-white/[0.04] px-3.5 py-2 text-[12px] font-bold text-slate-200"
        >
          {copied ? <Check size={14} /> : <Copy size={14} />}
          {copied ? tr('تم النسخ') : tr('نسخ الرابط')}
        </button>
        <button
          type="button"
          onClick={() => share.whatsapp('', `${tr('اشترك في ALEGDALY TECH لإدارة مكتب التحويل:')} ${OFFICES_LINK}`)}
          className="inline-flex items-center gap-1.5 rounded-full border border-emerald-400/30 bg-emerald-500/10 px-3.5 py-2 text-[12px] font-bold text-emerald-200"
        >
          <MessageCircle size={14} /> {tr('واتساب')}
        </button>
        <a
          href="#/offices"
          className="inline-flex items-center gap-1.5 rounded-full border border-white/12 bg-white/[0.04] px-3.5 py-2 text-[12px] font-bold text-slate-200"
        >
          <ExternalLink size={14} /> {tr('معاينة')}
        </a>
      </div>
    </Card>
  )
}

/**
 * مساحة المكتب الخاصة: مجموعة مستقلة يملكها مالك المنصة، وصاحب المكتب مديرها.
 * تُنشأ مرة واحدة (مفتاح ثابت) — التجديد يعيد استخدامها.
 */
async function ensureOfficeSpace(officeUserId, officeName) {
  const g = await social.getOrCreateGroup({ name: `office: ${officeName}`, key: `office-${officeUserId}` })
  try {
    await social.inviteToGroup(g.id, officeUserId)
  } catch {
    /* عضو من قبل */
  }
  try {
    await social.appointAdmin(g.id, officeUserId)
  } catch (e) {
    const members = await social.getGroupMembers(g.id).catch(() => [])
    const m = members.find((x) => (x.userId || x.id) === officeUserId)
    if (!m || !['admin', 'owner'].includes(m.role)) throw e
  }
  return g.id
}

/** الترخيص الرسمي داخل إعداداتك — المصدر الوحيد الذي يفتح مساحة أي مكتب */
async function setLicense(officeId, lic, gid) {
  const fresh = await db.getShared(CFG_COLL, CFG_ID).catch(() => null)
  const licenses = { ...(fresh?.licenses || {}), [officeId]: lic }
  await db.upsertShared(CFG_COLL, { licenses }, CFG_ID, { groupId: gid, writableBy: 'admins' })
}

/** نسخة عامة مختصرة من حالة الاشتراك (الاسم + الانتهاء) يقرؤها وكلاء المكتب — لا يعدّلها إلا أنت */
async function syncStatus(officeId, data, gid) {
  await db.upsertShared(STATUS_COLL, data, officeId, { groupId: gid, writableBy: 'admins' })
}

function RequestCard({ r, offices, gid, lang }) {
  const toast = useToast()
  const [busy, setBusy] = useState(null)
  const [rejecting, setRejecting] = useState(false)
  const [reason, setReason] = useState('')
  const existing = offices.find((o) => o.userId === r.userId)

  async function approve() {
    if (busy) return
    setBusy('ok')
    try {
      const now = new Date().toISOString()
      const fresh = await db.getShared(OFFICE_COLL, r.userId)
      // مكتب حذفته سابقاً يبدأ من جديد (بلا مدة قديمة ولا مدفوعات سابقة)
      const live = fresh && fresh.status !== 'deleted' ? fresh : null
      const base = live?.expiresAt && new Date(live.expiresAt) > new Date() ? live.expiresAt : now
      const expiresAt = addMonths(base, Number(r.months) || 1)
      const groupId = fresh?.groupId || (await ensureOfficeSpace(r.userId, r.officeName))
      const info = {
        groupId,
        officeName: r.officeName,
        ownerName: r.ownerName,
        phone: r.phone,
        city: r.city || '',
        email: r.email || '',
        expiresAt,
        expiresDay: dayOf(expiresAt),
        status: 'active',
        lastPlan: r.plan,
      }
      if (fresh) {
        await db.updateShared(OFFICE_COLL, r.userId, {
          ...info,
          ...(live ? {} : { since: now, deletedAt: null }),
          totalPaid: (Number(live?.totalPaid) || 0) + (Number(r.amount) || 0),
        })
      } else {
        await db.insertShared(
          OFFICE_COLL,
          { ...info, userId: r.userId, since: now, totalPaid: Number(r.amount) || 0 },
          r.userId,
          { groupId: gid, visibleTo: `user:${r.userId}`, writableBy: 'admins' },
        )
      }
      await syncStatus(r.userId, { officeName: r.officeName, groupId, expiresAt, status: 'active' }, gid)
      await setLicense(r.userId, { expiresAt, status: 'active' }, gid)
      await db.updateShared(REQ_COLL, r.id, { status: 'approved', decidedAt: now, expiresAt })
      toast(tr('تم تفعيل اشتراك {name}', { name: r.officeName }))
    } catch (e) {
      toast(e?.message || tr('حدث خطأ، حاول مرة أخرى'), 'err')
    } finally {
      setBusy(null)
    }
  }

  async function reject() {
    if (busy) return
    setBusy('no')
    try {
      await db.updateShared(REQ_COLL, r.id, { status: 'rejected', note: reason.trim(), decidedAt: new Date().toISOString() })
      setRejecting(false)
      toast(tr('تم رفض الطلب'), 'info')
    } catch (e) {
      toast(e?.message || tr('حدث خطأ، حاول مرة أخرى'), 'err')
    } finally {
      setBusy(null)
    }
  }

  return (
    <Card className="p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <p className="font-display truncate text-[16px] font-extrabold text-white">{r.officeName}</p>
            <span className={`rounded-full px-2 py-0.5 text-[10.5px] font-extrabold ${r.kind === 'renew' || existing ? 'bg-blue-500/20 text-blue-200' : 'bg-amber-400/15 text-amber-200'}`}>
              {r.kind === 'renew' || existing ? tr('تجديد') : tr('جديد')}
            </span>
          </div>
          <p className="mt-0.5 text-[12px] text-slate-400">{r.ownerName}{r.email ? ` · ${r.email}` : ''}</p>
        </div>
        <div className="text-end">
          <p className="font-display text-[17px] font-black tabular-nums text-amber-200">{fmtNum(r.amount)}</p>
          <p className="text-[10.5px] font-bold text-slate-500">FCFA · {tr(planOf(r.plan).label)}</p>
        </div>
      </div>

      <div className="mt-3 grid grid-cols-2 gap-2 text-[12px]">
        <div className="rounded-xl bg-black/25 px-3 py-2">
          <p className="text-[10.5px] font-bold text-slate-500">{tr('كود الحوالة')}</p>
          <p dir="ltr" className={`text-start font-black tracking-wider ${r.method === 'NITA' ? 'text-orange-300' : 'text-emerald-300'}`}>
            {r.method} · {r.code}
          </p>
        </div>
        <div className="rounded-xl bg-black/25 px-3 py-2">
          <p className="text-[10.5px] font-bold text-slate-500">{tr('التاريخ')}</p>
          <p className="font-bold text-slate-200">{fmtDate(r.createdAt, lang)}</p>
        </div>
      </div>

      <div className="mt-2.5 flex flex-wrap gap-x-4 gap-y-1 text-[11.5px] text-slate-400">
        <span dir="ltr" className="inline-flex items-center gap-1"><Phone size={12} />{r.phone}</span>
        {r.city ? <span className="inline-flex items-center gap-1"><MapPin size={12} />{r.city}</span> : null}
        {r.agents ? <span className="inline-flex items-center gap-1"><Users size={12} />{tr('{n} وكيل', { n: r.agents })}</span> : null}
      </div>

      {rejecting ? (
        <div className="mt-3 space-y-2">
          <input value={reason} onChange={(e) => setReason(e.target.value)} placeholder={tr('سبب الرفض (يظهر للمشترك)')} className={fieldCls} />
          <div className="flex gap-2">
            <button type="button" onClick={reject} disabled={!!busy} className="flex-1 rounded-xl bg-rose-500/20 py-2.5 text-[13px] font-extrabold text-rose-200 disabled:opacity-50">
              {tr('تأكيد الرفض')}
            </button>
            <GhostBtn onClick={() => setRejecting(false)}>{tr('إلغاء')}</GhostBtn>
          </div>
        </div>
      ) : (
        <div className="mt-3 flex gap-2">
          <button
            type="button"
            onClick={approve}
            disabled={!!busy}
            className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gradient-to-l from-emerald-500 to-emerald-400 py-2.5 text-[13px] font-extrabold text-emerald-950 disabled:opacity-50"
          >
            <CheckCircle2 size={15} />
            {busy === 'ok' ? tr('جارٍ التفعيل...') : tr('وصل المبلغ · فعّل')}
          </button>
          <button
            type="button"
            onClick={() => setRejecting(true)}
            disabled={!!busy}
            className="flex items-center gap-1.5 rounded-xl border border-rose-400/30 px-3.5 text-[13px] font-bold text-rose-200 disabled:opacity-50"
          >
            <XCircle size={15} /> {tr('رفض')}
          </button>
        </div>
      )}
    </Card>
  )
}

function OfficeRow({ o, lang, gid, cfg }) {
  const toast = useToast()
  const [busy, setBusy] = useState(false)
  const [confirmDel, setConfirmDel] = useState(false)
  const state = officeState(o)
  const badge = {
    active: ['bg-emerald-500/20 text-emerald-200', tr('فعّال')],
    ending: ['bg-amber-500/20 text-amber-200', tr('ينتهي قريباً')],
    expired: ['bg-rose-500/20 text-rose-200', tr('منتهي')],
    suspended: ['bg-rose-500/20 text-rose-200', tr('موقوف')],
  }[state]

  async function toggleSuspend() {
    if (busy) return
    setBusy(true)
    try {
      const next = o.status === 'suspended' ? 'active' : 'suspended'
      await db.updateShared(OFFICE_COLL, o.id, { status: next })
      await syncStatus(o.id, { officeName: o.officeName, groupId: o.groupId || '', expiresAt: o.expiresAt, status: next }, gid)
      await setLicense(o.id, { expiresAt: o.expiresAt, status: next }, gid)
    } catch (e) {
      toast(e?.message || tr('حدث خطأ، حاول مرة أخرى'), 'err')
    } finally {
      setBusy(false)
    }
  }

  async function remove() {
    if (busy) return
    // تأكيد داخل التطبيق (نوافذ التأكيد الافتراضية لا تعمل في تطبيق الأندرويد)
    if (!confirmDel) {
      setConfirmDel(true)
      setTimeout(() => setConfirmDel(false), 5000)
      return
    }
    setConfirmDel(false)
    setBusy(true)
    try {
      // ① إلغاء الترخيص الرسمي — هذا وحده يقفل المساحة
      const fresh = await db.getShared(CFG_COLL, CFG_ID).catch(() => null)
      const licenses = { ...(fresh?.licenses || {}) }
      delete licenses[o.id]
      await db.upsertShared(CFG_COLL, { licenses }, CFG_ID, { groupId: gid, writableBy: 'admins' })
      // ② الحالة العامة + سجل المكتب: يُعلَّم كمحذوف (ولا تصله تذكيرات الانتهاء)
      await syncStatus(o.id, { officeName: o.officeName, groupId: o.groupId || '', expiresAt: o.expiresAt, status: 'deleted' }, gid)
      await db.updateShared(OFFICE_COLL, o.id, { status: 'deleted', expiresDay: '', deletedAt: new Date().toISOString() })
      toast(tr('تم حذف المكتب'), 'info')
    } catch (e) {
      toast(e?.message || tr('تعذّر الحذف'), 'err')
    } finally {
      setBusy(false)
    }
  }

  const d = daysLeft(o.expiresAt)
  return (
    <div className="flex flex-wrap items-center gap-3 border-b border-white/[0.06] py-3 last:border-0">
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-400/10 text-amber-300">
        <Building2 size={18} />
      </span>
      <div className="min-w-0 flex-1">
        <p className="truncate text-[14px] font-extrabold text-white">{o.officeName}</p>
        <p className="truncate text-[11.5px] text-slate-400">
          {o.ownerName} · <span dir="ltr">{o.phone}</span>
        </p>
      </div>
      <div className="text-end">
        <span className={`rounded-full px-2.5 py-0.5 text-[11px] font-extrabold ${badge[0]}`}>{badge[1]}</span>
        <p className="mt-1 text-[11px] font-bold text-slate-400">
          {d > 0 ? tr('باقي {n} يوم', { n: d }) : fmtDate(o.expiresAt, lang)}
        </p>
      </div>
      {(state === 'ending' || state === 'expired') && o.phone ? (
        <button
          type="button"
          onClick={() => share.whatsapp(String(o.phone).replace(/[^\d]/g, ''), renewText(o, cfg))}
          aria-label={tr('تذكير عبر واتساب')}
          className="flex h-10 w-10 items-center justify-center rounded-xl border border-emerald-400/30 bg-emerald-500/10 text-emerald-200 hover:bg-emerald-500/20"
        >
          <MessageCircle size={15} />
        </button>
      ) : null}
      <button
        type="button"
        onClick={toggleSuspend}
        disabled={busy}
        aria-label={o.status === 'suspended' ? tr('إعادة التفعيل') : tr('إيقاف')}
        className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 text-slate-300 hover:bg-white/[0.06] disabled:opacity-50"
      >
        {o.status === 'suspended' ? <Play size={15} /> : <Pause size={15} />}
      </button>
      <button
        type="button"
        onClick={remove}
        disabled={busy}
        aria-label={tr('حذف')}
        className={`flex h-10 items-center justify-center gap-1.5 rounded-xl border border-rose-500/40 disabled:opacity-50 ${
          confirmDel ? 'bg-rose-600 px-3 text-[12px] font-extrabold text-white' : 'w-10 bg-rose-500/10 text-rose-300 hover:bg-rose-500/20'
        }`}
      >
        <Trash2 size={15} />
        {confirmDel ? tr('تأكيد الحذف') : null}
      </button>
    </div>
  )
}

function LogRow({ r, lang }) {
  const toast = useToast()
  const [busy, setBusy] = useState(false)
  const [confirmDel, setConfirmDel] = useState(false)

  async function remove() {
    if (busy) return
    // تأكيد داخل التطبيق بضغطتين
    if (!confirmDel) {
      setConfirmDel(true)
      setTimeout(() => setConfirmDel(false), 5000)
      return
    }
    setConfirmDel(false)
    setBusy(true)
    try {
      await db.deleteShared(REQ_COLL, r.id)
      toast(tr('تم حذف السجل'), 'info')
    } catch (e) {
      toast(e?.message || tr('تعذّر الحذف'), 'err')
      setBusy(false)
    }
  }

  return (
    <div className="flex items-center gap-3 border-b border-white/[0.06] py-3 last:border-0">
      {r.status === 'approved' ? <CheckCircle2 size={17} className="shrink-0 text-emerald-400" /> : <XCircle size={17} className="shrink-0 text-rose-400" />}
      <div className="min-w-0 flex-1">
        <p className="truncate text-[13.5px] font-bold text-white">{r.officeName}</p>
        <p className="text-[11px] text-slate-500">
          {fmtDate(r.decidedAt || r.createdAt, lang)} · {r.method} · <span dir="ltr">{r.code}</span>
        </p>
      </div>
      <p className={`font-display text-[14px] font-black tabular-nums ${r.status === 'approved' ? 'text-emerald-300' : 'text-slate-500 line-through'}`}>
        {fmtNum(r.amount)}
      </p>
      <button
        type="button"
        onClick={remove}
        disabled={busy}
        aria-label={tr('حذف')}
        className={`flex h-10 shrink-0 items-center justify-center gap-1.5 rounded-xl border border-rose-500/40 disabled:opacity-50 ${
          confirmDel ? 'bg-rose-600 px-3 text-[12px] font-extrabold text-white' : 'w-10 bg-rose-500/10 text-rose-300 hover:bg-rose-500/20'
        }`}
      >
        <Trash2 size={15} />
        {confirmDel ? tr('تأكيد الحذف') : null}
      </button>
    </div>
  )
}

let reqTriggerBusy = false

export default function Sales() {
  const { gid } = useSession()
  const { lang } = useLang()
  const { data: cfgRows } = useLiveShared(CFG_COLL)
  const cfg = useMemo(() => (cfgRows || []).find((r) => r.id === CFG_ID) || null, [cfgRows])
  const { data: requests, loading } = useLiveShared(REQ_COLL, { order: '-createdAt', limit: 200 })
  const { data: offices, loading: officesLoading } = useLiveShared(OFFICE_COLL)
  const [revenue, setRevenue] = useState(0)
  const [view, setView] = useState('pending')

  const pending = (requests || []).filter((r) => r.status === 'pending')
  const decided = (requests || []).filter((r) => r.status !== 'pending')
  const officeList = useMemo(
    () => [...(offices || [])].filter((o) => o.status !== 'deleted').sort((a, b) => new Date(a.expiresAt) - new Date(b.expiresAt)),
    [offices],
  )
  const activeCount = officeList.filter((o) => ['active', 'ending'].includes(officeState(o))).length
  const endingList = officeList.filter((o) => ['ending', 'expired'].includes(officeState(o)) && daysLeft(o.expiresAt) > -30)

  // مرة واحدة: نقل المكاتب المفعّلة سابقاً إلى سجل التراخيص الرسمي (المكاتب التي فعّلتها أنت فقط)
  useEffect(() => {
    if (!gid || !cfg || cfg.licenses || !offices || officesLoading) return
    const licenses = {}
    for (const o of offices) {
      if (o.expiresAt && o.status !== 'deleted' && o._createdBy !== o.id) licenses[o.id] = { expiresAt: o.expiresAt, status: o.status || 'active' }
    }
    db.upsertShared(CFG_COLL, { licenses }, CFG_ID, { groupId: gid, writableBy: 'admins' }).catch(() => {})
  }, [gid, cfg, offices, officesLoading])

  // مرة واحدة: إشعار فوري لك (من السيرفر) عند كل طلب اشتراك أو تجديد مكتب جديد
  useEffect(() => {
    if (!gid || !cfg || cfg.reqTrigger || reqTriggerBusy) return
    const me = auth.getCurrentUser()
    if (!me?.id || !auth.isAppOwner()) return
    let alive = true
    reqTriggerBusy = true
    ;(async () => {
      try {
        const list = await triggers.list().catch(() => [])
        let t = (list || []).find((x) => x.collection === REQ_COLL && x.action === 'push')
        if (!t) {
          t = await triggers.create({
            collection: REQ_COLL,
            on: ['insert'],
            action: 'push',
            title: '🏢 طلب اشتراك مكتب',
            body: '{{officeName}} — {{ownerName}} ({{phone}}) · {{amount}}',
            url: '#/sales',
            target: { userId: me.id },
          })
        }
        if (alive && t?.id) await db.upsertShared(CFG_COLL, { reqTrigger: t.id }, CFG_ID, { groupId: gid, writableBy: 'admins' })
      } catch { /* يُعاد المحاولة في المرة القادمة */ } finally { reqTriggerBusy = false }
    })()
    return () => { alive = false }
  }, [gid, cfg])

  // إجمالي الإيرادات من السيرفر — صحيح مهما كبر العدد
  useEffect(() => {
    let alive = true
    db.sumShared(REQ_COLL, 'amount', { status: 'approved' })
      .then((v) => alive && setRevenue(Number(v) || 0))
      .catch(() => {})
    return () => { alive = false }
  }, [requests])

  return (
    <div className="space-y-5">
      <div>
        <p className="text-[11px] font-extrabold tracking-wider text-amber-300/90">{tr('ALEGDALY TECH للمكاتب')}</p>
        <h1 className="font-display mt-1 text-[24px] font-black text-white md:text-[28px]">{tr('اشتراكات المكاتب')}</h1>
        <p className="mt-1 text-[12.5px] text-slate-400">{tr('بيع التطبيق لمكاتب التحويل الأخرى باشتراك مدفوع.')}</p>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <Stat icon={Clock} label={tr('طلبات جديدة')} value={pending.length} tone="bg-amber-400/15 text-amber-300" />
        <Stat icon={Building2} label={tr('مكاتب فعّالة')} value={activeCount} tone="bg-emerald-500/15 text-emerald-300" />
        <Stat icon={Coins} label={tr('الإيرادات')} value={fmtNum(revenue)} tone="bg-blue-500/15 text-blue-300" />
      </div>

      <OpenSwitch cfg={cfg} gid={gid} />

      <LinkCard />

      {endingList.length ? (
        <Card className="border-amber-400/25 bg-amber-500/[0.06] p-4">
          <p className="flex items-center gap-2 text-[13px] font-extrabold text-amber-200">
            <BellRing size={16} /> {tr('{n} مكتب يحتاج تجديداً', { n: endingList.length })}
          </p>
          <div className="mt-2 flex flex-wrap gap-2">
            {endingList.map((o) => (
              <button
                key={o.id}
                type="button"
                onClick={() => o.phone && share.whatsapp(String(o.phone).replace(/[^\d]/g, ''), renewText(o, cfg))}
                className="inline-flex items-center gap-1.5 rounded-full border border-amber-300/25 bg-black/20 px-3 py-1.5 text-[12px] font-bold text-amber-100 hover:bg-black/30"
              >
                <MessageCircle size={13} />
                {o.officeName} · {daysLeft(o.expiresAt) > 0 ? tr('باقي {n} يوم', { n: daysLeft(o.expiresAt) }) : tr('منتهي')}
              </button>
            ))}
          </div>
        </Card>
      ) : null}

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-[1.15fr_1fr]">
        <div className="space-y-3">
          <div className="flex gap-1.5 rounded-2xl border border-white/[0.07] bg-black/25 p-1.5">
            {[
              { v: 'pending', label: `${tr('الطلبات')} (${pending.length})` },
              { v: 'offices', label: `${tr('المكاتب')} (${officeList.length})` },
              { v: 'log', label: tr('السجل') },
            ].map((o) => (
              <button
                key={o.v}
                type="button"
                onClick={() => setView(o.v)}
                className={`flex-1 rounded-xl py-2 text-[12.5px] font-bold transition ${
                  view === o.v ? 'bg-emerald-500/20 text-emerald-200' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {o.label}
              </button>
            ))}
          </div>

          {loading ? (
            <Spinner />
          ) : view === 'pending' ? (
            pending.length ? (
              pending.map((r) => <RequestCard key={r.id} r={r} offices={offices || []} gid={gid} lang={lang} />)
            ) : (
              <EmptyState icon={Clock} title={tr('لا توجد طلبات جديدة')} text={tr('عندما يرسل مكتب طلب اشتراك يظهر هنا لتأكيده.')} />
            )
          ) : view === 'offices' ? (
            officeList.length ? (
              <Card className="px-4">{officeList.map((o) => <OfficeRow key={o.id} o={o} lang={lang} gid={gid} cfg={cfg} />)}</Card>
            ) : (
              <EmptyState icon={Building2} title={tr('لا توجد مكاتب بعد')} />
            )
          ) : decided.length ? (
            <Card className="px-4">
              {decided.map((r) => <LogRow key={r.id} r={r} lang={lang} />)}
            </Card>
          ) : (
            <EmptyState icon={Clock} title={tr('السجل فارغ')} />
          )}
        </div>

        <div className="space-y-5">
          <SettingsCard cfg={cfg} gid={gid} />
          <RemindersCard cfg={cfg} gid={gid} />
        </div>
      </div>

      <SectionTitle>{tr('ما الذي يحصل عليه المكتب؟')}</SectionTitle>
      <Card className="p-4 text-[12.5px] leading-relaxed text-slate-400">
        {tr('عند التفعيل يحصل المكتب على مساحة خاصة به: وكلاؤه وحوالاته وأرباحه منفصلة تماماً عن بياناتك وعن أي مكتب آخر. يدخل صاحب المكتب بنفس حسابه الذي اشترك به، ويرسل لوكلائه رابط انضمام. إذا انتهى الاشتراك أو أوقفته تُقفل مساحته ومساحات وكلائه حتى يجدّد.')}
      </Card>
    </div>
  )
}
