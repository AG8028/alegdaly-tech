import { useEffect, useMemo, useState } from 'react'
import {
  ArrowRight, ArrowLeft, Building2, Users, Calculator, Wallet, TrendingUp, ShieldCheck,
  Copy, Check, Clock, CheckCircle2, XCircle, LogIn, Crown, MessageCircle, Send,
} from 'lucide-react'
import { auth } from '../lib/auth'
import { db } from '../lib/db'
import { team } from '../lib/team'
import { share } from '../lib/share'
import { useLiveShared } from '../lib/useLive'
import Logo from '../components/Logo'
import { useToast } from '../components/ui'
import { LangSwitcher, tr, useLang } from '../components/i18n'
import { useMode, ThemeToggle, ModeScope } from '../components/theme'
import { copyText } from '../components/credentials'
import {
  CFG_COLL, CFG_ID, REQ_COLL, OFFICE_COLL, CODE_COLL, PLANS, planOf, priceOf, salesOpen,
  daysLeft, officeState, fmtNum, fmtDate, waNumber,
} from '../components/saas'

const INPUT =
  'w-full rounded-[0.9rem] border border-white/10 bg-white/[0.035] px-3.5 py-3 text-[15px] text-slate-50 outline-none transition placeholder:text-slate-500 focus:border-amber-300/60 focus:bg-white/[0.06] focus:ring-4 focus:ring-amber-300/10'

const METHOD_TONE = {
  NITA: 'text-orange-300 border-orange-400/50 bg-orange-500/10',
  AMANA: 'text-emerald-300 border-emerald-400/50 bg-emerald-500/10',
}

function CopyChip({ value }) {
  const [ok, setOk] = useState(false)
  return (
    <button
      type="button"
      onClick={async () => {
        if ((await copyText(value)) !== false) {
          setOk(true)
          setTimeout(() => setOk(false), 1600)
        }
      }}
      className="inline-flex items-center gap-1 rounded-full border border-white/12 bg-white/[0.05] px-2.5 py-1 text-[11px] font-bold text-slate-200 hover:border-amber-300/50"
    >
      {ok ? <Check size={12} /> : <Copy size={12} />}
      {ok ? tr('تم النسخ') : tr('نسخ')}
    </button>
  )
}

function Feature({ icon: Icon, title, text, delay }) {
  return (
    <div className={`rise rounded-2xl border border-white/[0.08] bg-white/[0.03] p-4 backdrop-blur-sm ${delay}`}>
      <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-amber-300/25 to-amber-500/5 text-amber-300">
        <Icon size={19} />
      </span>
      <p className="font-display mt-3 text-[15px] font-extrabold text-white">{title}</p>
      <p className="mt-1 text-[12.5px] leading-relaxed text-slate-400">{text}</p>
    </div>
  )
}

/** حالة اشتراك المكتب للمشترك نفسه */
function MyStatus({ office, requests, lang }) {
  const state = officeState(office)
  const pending = requests.filter((r) => r.status === 'pending')
  const lastRejected = requests.find((r) => r.status === 'rejected')
  if (!office && !requests.length) return null

  const tone = {
    active: 'border-emerald-400/40 from-emerald-500/15',
    ending: 'border-amber-400/50 from-amber-500/15',
    expired: 'border-rose-400/40 from-rose-500/15',
    suspended: 'border-rose-400/40 from-rose-500/15',
    none: 'border-white/10 from-white/[0.04]',
  }[state]

  return (
    <div className={`rise rounded-3xl border bg-gradient-to-br to-transparent p-5 ${tone}`}>
      <p className="text-[11px] font-extrabold tracking-wider text-amber-300/90">{tr('اشتراك مكتبك')}</p>
      {office ? (
        <>
          <h3 className="font-display mt-1 text-[20px] font-black text-white">{office.officeName}</h3>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            {state === 'active' && (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/20 px-3 py-1 text-[12px] font-extrabold text-emerald-200">
                <CheckCircle2 size={14} /> {tr('فعّال')}
              </span>
            )}
            {state === 'ending' && (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-500/20 px-3 py-1 text-[12px] font-extrabold text-amber-200">
                <Clock size={14} /> {tr('ينتهي قريباً')}
              </span>
            )}
            {(state === 'expired' || state === 'suspended') && (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-rose-500/20 px-3 py-1 text-[12px] font-extrabold text-rose-200">
                <XCircle size={14} /> {state === 'expired' ? tr('منتهي') : tr('موقوف')}
              </span>
            )}
            {(state === 'active' || state === 'ending') && (
              <span className="text-[12.5px] font-bold text-slate-300">
                {tr('باقي {n} يوم', { n: daysLeft(office.expiresAt) })} · {tr('حتى {d}', { d: fmtDate(office.expiresAt, lang) })}
              </span>
            )}
          </div>
          {(state === 'active' || state === 'ending') && (
            <a
              href="#/"
              className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600 py-3 text-[14px] font-extrabold text-emerald-950 shadow-[0_14px_32px_-14px_rgba(16,185,129,.8)]"
            >
              <Building2 size={16} /> {tr('ادخل إلى مكتبك')}
            </a>
          )}
        </>
      ) : null}
      {pending.length > 0 && (
        <p className="mt-3 flex items-center gap-2 rounded-xl border border-amber-400/30 bg-amber-500/10 px-3 py-2.5 text-[12.5px] font-bold text-amber-100">
          <Clock size={15} className="shrink-0" />
          {tr('طلبك قيد المراجعة — يتفعّل بعد تأكيد وصول المبلغ.')}
        </p>
      )}
      {!pending.length && lastRejected && (!office || new Date(lastRejected.createdAt) > new Date(office.updatedAt || 0)) && (
        <p className="mt-3 rounded-xl border border-rose-400/30 bg-rose-500/10 px-3 py-2.5 text-[12.5px] font-bold leading-relaxed text-rose-100">
          {tr('رُفض طلبك الأخير.')} {lastRejected.note ? `${tr('السبب:')} ${lastRejected.note}` : ''}
        </p>
      )}
    </div>
  )
}

export default function Offices() {
  const toast = useToast()
  const { lang } = useLang()
  const { mode, toggle } = useMode('dark')
  const rtl = lang === 'ar'
  const Back = rtl ? ArrowRight : ArrowLeft

  const [user, setUser] = useState(() => auth.getCurrentUser())
  useEffect(() => auth.onAuthChange((u) => setUser(u)), [])
  const signedIn = !!user && auth.isAuthenticated()

  const { data: cfgRows, loading: cfgLoading } = useLiveShared(CFG_COLL)
  const cfg = useMemo(() => (cfgRows || []).find((r) => r.id === CFG_ID) || null, [cfgRows])
  const open = salesOpen(cfg)

  const { data: reqRows } = useLiveShared(REQ_COLL, { order: '-createdAt', filters: signedIn ? { userId: user.id } : { userId: '__none__' } })
  const { data: officeRows } = useLiveShared(OFFICE_COLL, { filters: signedIn ? { userId: user.id } : { userId: '__none__' } })
  const myRequests = signedIn ? reqRows || [] : []
  const myOffice = signedIn ? (officeRows || []).find((o) => o.status !== 'deleted') || null : null
  const hasPending = myRequests.some((r) => r.status === 'pending')

  const firstPlan = PLANS.find((p) => priceOf(cfg, p.key) > 0)?.key || 'm1'
  const [plan, setPlan] = useState(null)
  const planKey = plan && priceOf(cfg, plan) > 0 ? plan : firstPlan
  const methods = ['NITA', 'AMANA'].filter((m) => (m === 'NITA' ? cfg?.nitaNumber : cfg?.amanaNumber))
  const [method, setMethod] = useState(null)
  const methodKey = method && methods.includes(method) ? method : methods[0] || null

  const [form, setForm] = useState({ officeName: '', ownerName: '', phone: '', city: '', agents: '', code: '' })
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }))
  const [busy, setBusy] = useState(false)
  const [signing, setSigning] = useState(false)

  // تعبئة بيانات المكتب تلقائياً عند التجديد
  useEffect(() => {
    if (!myOffice) return
    setForm((f) => ({
      ...f,
      officeName: f.officeName || myOffice.officeName || '',
      ownerName: f.ownerName || myOffice.ownerName || '',
      phone: f.phone || myOffice.phone || '',
      city: f.city || myOffice.city || '',
    }))
  }, [myOffice])

  async function signIn() {
    if (signing) return
    setSigning(true)
    try {
      await auth.signIn()
    } finally {
      setSigning(false)
    }
  }

  async function submit(e) {
    e.preventDefault()
    if (busy || !signedIn || !methodKey) return
    const code = form.code.trim().toUpperCase().replace(/\s+/g, '')
    if (!form.officeName.trim() || !form.ownerName.trim() || !form.phone.trim() || !code) {
      toast(tr('أكمل كل الخانات المطلوبة'), 'err')
      return
    }
    setBusy(true)
    try {
      const gid = await team.groupId()
      const opts = { groupId: gid, visibleTo: 'creator-and-admin', writableBy: 'admins' }
      const p = planOf(planKey)
      // كود الحوالة يُستخدم مرة واحدة فقط — يمنع تكرار نفس الدفعة
      const codeId = `${methodKey}-${code.replace(/[^A-Z0-9]/g, '')}`
      try {
        await db.insertShared(CODE_COLL, { method: methodKey, code, userId: user.id }, codeId, opts)
      } catch (err) {
        if (err?.status === 409) {
          toast(tr('كود الحوالة هذا مستخدم من قبل'), 'err')
          return
        }
        throw err
      }
      await db.insertShared(
        REQ_COLL,
        {
          userId: user.id,
          email: user.email || '',
          officeName: form.officeName.trim(),
          ownerName: form.ownerName.trim(),
          phone: form.phone.trim(),
          city: form.city.trim(),
          agents: Number(form.agents) || 0,
          plan: p.key,
          months: p.months,
          amount: priceOf(cfg, p.key),
          method: methodKey,
          code,
          kind: myOffice ? 'renew' : 'new',
          status: 'pending',
          note: '',
        },
        undefined,
        opts,
      )
      setForm((f) => ({ ...f, code: '' }))
      toast(tr('تم إرسال طلبك — سيتفعّل بعد تأكيد وصول المبلغ'))
    } catch (err) {
      toast(err?.message || tr('حدث خطأ، حاول مرة أخرى'), 'err')
    } finally {
      setBusy(false)
    }
  }

  const price = priceOf(cfg, planKey)
  const receiver = methodKey === 'NITA'
    ? { number: cfg?.nitaNumber, name: cfg?.nitaName }
    : { number: cfg?.amanaNumber, name: cfg?.amanaName }

  return (
    <ModeScope mode={mode}>
      <div className="lux-gate skin-dark relative h-full overflow-y-auto bg-[#050a16]" data-dir={rtl ? 'rtl' : 'ltr'} data-mode={mode}>
        <div aria-hidden="true" className="pointer-events-none fixed inset-0 overflow-hidden">
          <div className="lux-orb absolute -top-40 start-[-10%] h-[480px] w-[480px] rounded-full bg-emerald-500/15 blur-[120px]" />
          <div className="lux-orb lux-orb-2 absolute bottom-[-160px] end-[-8%] h-[520px] w-[520px] rounded-full bg-amber-400/12 blur-[130px]" />
          <div className="lux-grid absolute inset-0" />
        </div>

        <div className="relative z-10 mx-auto w-full max-w-6xl px-5 pb-[calc(env(safe-area-inset-bottom,0px)+32px)] pt-[calc(env(safe-area-inset-top,0px)+16px)] md:px-10">
          <header dir={rtl ? 'ltr' : 'rtl'} className="rise flex items-center justify-between gap-3">
            <a href="#/" dir={rtl ? 'rtl' : 'ltr'} className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-3 py-2 text-[12px] font-bold text-slate-300 hover:text-white">
              {tr('الدخول')}
              {rtl ? <ArrowLeft size={15} /> : <ArrowRight size={15} />}
            </a>
            <div dir={rtl ? 'rtl' : 'ltr'} className="flex items-center gap-1.5">
              <ThemeToggle mode={mode} onToggle={toggle} />
              <LangSwitcher compact />
            </div>
          </header>

          {/* البطل */}
          <section className="mt-8 flex flex-col items-center text-center">
            <Logo className="rise h-20 w-20" />
            <span className="rise mt-5 inline-flex items-center gap-1.5 rounded-full border border-amber-300/30 bg-amber-400/10 px-3 py-1 text-[11px] font-extrabold tracking-wider text-amber-200 [animation-delay:60ms]">
              <Building2 size={13} /> {tr('ALEGDALY TECH للمكاتب')}
            </span>
            <h1 className="rise mt-4 pt-2 font-display text-[30px] font-black leading-[1.35] text-white [animation-delay:120ms] md:text-[46px]">
              {tr('أدِر مكتب التحويل كاملاً')}
              <br />
              <span className="lux-gold-text">{tr('من هاتفك')}</span>
            </h1>
            <p className="rise mt-3 max-w-xl text-[14px] leading-relaxed text-slate-400 [animation-delay:180ms] md:text-[15px]">
              {tr('مساحة خاصة لمكتبك: وكلاؤك وحساباتك وأرباحك منفصلة تماماً عن أي مكتب آخر.')}
            </p>
          </section>

          <section className="mt-8 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Feature icon={Users} title={tr('وكلاء بحسابات خاصة')} text={tr('كل وكيل يدخل برمزه ويرى عملياته فقط.')} delay="[animation-delay:200ms]" />
            <Feature icon={Calculator} title={tr('عمولات تلقائية')} text={tr('الرسوم والعمولات تُحسب مع كل حوالة.')} delay="[animation-delay:250ms]" />
            <Feature icon={Wallet} title={tr('أرصدة وتصفيات')} text={tr('رصيد كل وكيل يتحدّث لحظياً.')} delay="[animation-delay:300ms]" />
            <Feature icon={TrendingUp} title={tr('مركز الأرباح')} text={tr('أرباح اليوم والأسبوع وكل شبكة.')} delay="[animation-delay:350ms]" />
          </section>

          <div className="mt-10 grid grid-cols-1 gap-6 lg:grid-cols-[1fr_1.1fr]">
            {/* العمود الأول: الحالة + الباقات */}
            <div className="space-y-5">
              {signedIn && <MyStatus office={myOffice} requests={myRequests} lang={lang} />}

              {cfgLoading ? (
                <div className="flex justify-center py-10">
                  <div className="h-7 w-7 animate-spin rounded-full border-2 border-white/15 border-t-amber-300" />
                </div>
              ) : !open ? (
                <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-6 text-center">
                  <Clock className="mx-auto text-amber-300" size={28} />
                  <p className="font-display mt-3 text-[18px] font-extrabold text-white">{tr('الاشتراكات ستُفتح قريباً')}</p>
                  {cfg?.whatsapp ? (
                    <button
                      type="button"
                      onClick={() => share.whatsapp(waNumber(cfg.whatsapp), tr('مرحباً، أريد الاشتراك في ALEGDALY TECH لمكتبي'))}
                      className="mt-4 inline-flex items-center gap-1.5 rounded-full border border-emerald-400/30 bg-emerald-500/10 px-4 py-2.5 text-[13px] font-bold text-emerald-200"
                    >
                      <MessageCircle size={15} /> {tr('تواصل معنا')}
                    </button>
                  ) : null}
                </div>
              ) : (
                <div>
                  <p className="mb-3 text-[12px] font-extrabold tracking-wider text-amber-300/90">{tr('اختر الباقة')}</p>
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-3 lg:grid-cols-1 xl:grid-cols-3">
                    {PLANS.filter((p) => priceOf(cfg, p.key) > 0).map((p) => {
                      const active = p.key === planKey
                      const monthly = Math.round(priceOf(cfg, p.key) / p.months)
                      return (
                        <button
                          key={p.key}
                          type="button"
                          onClick={() => setPlan(p.key)}
                          className={`relative rounded-2xl border p-4 text-start transition ${
                            active
                              ? 'border-amber-300/70 bg-gradient-to-br from-amber-400/15 to-transparent shadow-[0_18px_40px_-20px_rgba(240,184,71,.7)]'
                              : 'border-white/10 bg-white/[0.03] hover:border-white/25'
                          }`}
                        >
                          {p.key === 'm12' && (
                            <span className="absolute -top-2.5 end-3 rounded-full bg-gradient-to-br from-[#fbe3a1] to-[#c98a22] px-2 py-0.5 text-[10px] font-black text-[#1a1206]">
                              {tr('الأوفر')}
                            </span>
                          )}
                          <p className="text-[12.5px] font-bold text-slate-300">{tr(p.label)}</p>
                          <p className="font-display mt-1 text-[22px] font-black tabular-nums text-white">
                            {fmtNum(priceOf(cfg, p.key))} <span className="text-[11px] font-bold text-slate-400">FCFA</span>
                          </p>
                          {p.months > 1 && (
                            <p className="mt-0.5 text-[11px] font-bold text-emerald-300/80">
                              {tr('≈ {n} شهرياً', { n: fmtNum(monthly) })}
                            </p>
                          )}
                        </button>
                      )
                    })}
                  </div>
                  <p className="mt-3 flex items-center gap-1.5 text-[11.5px] text-slate-500">
                    <ShieldCheck size={13} className="text-emerald-400" />
                    {tr('كود الحوالة يُقبل مرة واحدة فقط، ويُراجع يدوياً قبل التفعيل.')}
                  </p>
                </div>
              )}
            </div>

            {/* العمود الثاني: الدفع والطلب */}
            {open && (
              <div className="relative">
                <div className="absolute -inset-px rounded-[1.6rem] bg-gradient-to-b from-amber-300/40 via-white/5 to-emerald-400/30" />
                <div className="relative rounded-[1.55rem] bg-gradient-to-b from-[#101a30]/95 to-[#080e1c]/95 p-5 md:p-6">
                  <h2 className="font-display text-[20px] font-black text-white">{tr('اشترك الآن')}</h2>

                  <ol className="mt-4 space-y-2.5 text-[12.5px] text-slate-300">
                    {[
                      tr('اختر الباقة وطريقة الدفع'),
                      tr('أرسل المبلغ إلى الرقم الظاهر'),
                      tr('اكتب كود الحوالة وأرسل الطلب'),
                      tr('يتفعّل اشتراكك بعد تأكيد وصول المبلغ'),
                    ].map((s, i) => (
                      <li key={i} className="flex items-center gap-2.5">
                        <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-amber-400/15 text-[11px] font-black text-amber-200">{i + 1}</span>
                        {s}
                      </li>
                    ))}
                  </ol>

                  {methods.length > 0 && (
                    <div className="mt-5 grid grid-cols-2 gap-2">
                      {methods.map((m) => (
                        <button
                          key={m}
                          type="button"
                          onClick={() => setMethod(m)}
                          className={`rounded-xl border py-3 text-[14px] font-black tracking-wider transition ${
                            m === methodKey ? METHOD_TONE[m] : 'border-white/10 text-slate-400 hover:border-white/25'
                          }`}
                        >
                          {m}
                        </button>
                      ))}
                    </div>
                  )}

                  {methodKey && (
                    <div className="mt-3 rounded-2xl border border-white/10 bg-black/25 p-4">
                      <p className="text-[11.5px] font-bold text-slate-400">{tr('أرسل المبلغ إلى')}</p>
                      <div className="mt-1 flex flex-wrap items-center justify-between gap-2">
                        <p dir="ltr" className="font-display text-[20px] font-black tabular-nums tracking-wide text-white">{receiver.number}</p>
                        <CopyChip value={receiver.number} />
                      </div>
                      {receiver.name ? <p className="mt-0.5 text-[12px] text-slate-400">{receiver.name}</p> : null}
                      <div className="mt-3 flex items-center justify-between border-t border-white/10 pt-3">
                        <span className="text-[12px] font-bold text-slate-400">{tr('المبلغ')} · {tr(planOf(planKey).label)}</span>
                        <span className="font-display text-[18px] font-black tabular-nums text-amber-200">{fmtNum(price)} FCFA</span>
                      </div>
                    </div>
                  )}

                  {!signedIn ? (
                    <div className="mt-5 rounded-2xl border border-white/10 bg-white/[0.03] p-4 text-center">
                      <p className="text-[12.5px] leading-relaxed text-slate-300">
                        {tr('سجّل دخولك بحسابك أولاً حتى يرتبط الاشتراك بك ولا يضيع إذا غيّرت هاتفك.')}
                      </p>
                      <button
                        type="button"
                        onClick={signIn}
                        disabled={signing}
                        className="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-br from-[#fbe3a1] via-[#f0b847] to-[#c98a22] py-3.5 text-[15px] font-extrabold text-[#1a1206] disabled:opacity-60"
                      >
                        <LogIn size={17} /> {tr('تسجيل الدخول للمتابعة')}
                      </button>
                    </div>
                  ) : hasPending ? (
                    <p className="mt-5 flex items-center gap-2 rounded-xl border border-amber-400/30 bg-amber-500/10 px-3.5 py-3 text-[13px] font-bold text-amber-100">
                      <Clock size={16} className="shrink-0" />
                      {tr('طلبك قيد المراجعة — يتفعّل بعد تأكيد وصول المبلغ.')}
                    </p>
                  ) : (
                    <form onSubmit={submit} className="mt-5 space-y-3.5">
                      <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2">
                        <label className="block">
                          <span className="mb-1.5 block text-[12px] font-bold text-slate-300">{tr('اسم المكتب')} *</span>
                          <input value={form.officeName} onChange={set('officeName')} className={INPUT} placeholder={tr('مثال: مكتب النور للتحويلات')} required />
                        </label>
                        <label className="block">
                          <span className="mb-1.5 block text-[12px] font-bold text-slate-300">{tr('اسم صاحب المكتب')} *</span>
                          <input value={form.ownerName} onChange={set('ownerName')} className={INPUT} required />
                        </label>
                        <label className="block">
                          <span className="mb-1.5 block text-[12px] font-bold text-slate-300">{tr('رقم الهاتف')} *</span>
                          <input value={form.phone} onChange={set('phone')} dir="ltr" inputMode="tel" className={`${INPUT} text-start`} required />
                        </label>
                        <label className="block">
                          <span className="mb-1.5 block text-[12px] font-bold text-slate-300">{tr('المدينة')}</span>
                          <input value={form.city} onChange={set('city')} className={INPUT} />
                        </label>
                        <label className="block">
                          <span className="mb-1.5 block text-[12px] font-bold text-slate-300">{tr('عدد الوكلاء تقريباً')}</span>
                          <input value={form.agents} onChange={(e) => setForm((f) => ({ ...f, agents: e.target.value.replace(/[^\d]/g, '').slice(0, 4) }))} inputMode="numeric" className={INPUT} />
                        </label>
                        <label className="block">
                          <span className="mb-1.5 block text-[12px] font-bold text-slate-300">{tr('كود الحوالة')} ({methodKey}) *</span>
                          <input value={form.code} onChange={set('code')} dir="ltr" autoCapitalize="characters" className={`${INPUT} text-start uppercase`} required />
                        </label>
                      </div>
                      <button
                        type="submit"
                        disabled={busy || !methodKey}
                        className="flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-br from-[#fbe3a1] via-[#f0b847] to-[#c98a22] py-3.5 text-[15px] font-extrabold text-[#1a1206] shadow-[0_14px_32px_-12px_rgba(240,184,71,.6)] disabled:opacity-60"
                      >
                        {busy ? <span className="h-4 w-4 animate-spin rounded-full border-2 border-[#1a1206]/40 border-t-[#1a1206]" /> : myOffice ? <Crown size={17} /> : <Send size={17} />}
                        {myOffice ? tr('إرسال طلب التجديد') : tr('إرسال طلب الاشتراك')}
                      </button>
                      <p className="text-center text-[11px] text-slate-500">
                        {tr('مسجّل باسم {email}', { email: user.email || user.displayName || '—' })}
                      </p>
                    </form>
                  )}
                </div>
              </div>
            )}
          </div>

          <footer className="mt-12 text-center text-[11px] text-slate-500">
            <span className="lux-latin tracking-[0.2em] text-slate-400">© {new Date().getFullYear()} ALEGDALY TECH</span>
          </footer>
        </div>
      </div>
    </ModeScope>
  )
}
