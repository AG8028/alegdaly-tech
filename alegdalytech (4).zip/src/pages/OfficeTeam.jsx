import { useState } from 'react'
import { QRCodeSVG } from 'qrcode.react'
import {
  UserPlus, Copy, Check, MessageCircle, CheckCircle2, XCircle, Users, Phone, Mail,
  Pencil, UserX, UserCheck, Clock, Link2, Trash2, ChevronDown,
} from 'lucide-react'
import { db } from '../lib/db'
import { share } from '../lib/share'
import { useSession } from '../components/Session'
import { Card, SectionTitle, Field, fieldCls, PrimaryBtn, GhostBtn, EmptyState, useToast, useConfirm } from '../components/ui'
import MoneyInput from '../components/MoneyInput'
import { tr } from '../components/i18n'
import { copyText } from '../components/credentials'
import { fmt } from '../components/fees'
import { MEMBER_COLL, joinLink, officeCode } from '../components/saas'

const INVITE_KEY = 'alg_invite_open'

function InviteCard({ officeId, officeName }) {
  const [copied, setCopied] = useState(false)
  const [open, setOpenState] = useState(() => {
    try { return localStorage.getItem(INVITE_KEY) !== '0' } catch { return true }
  })
  const link = joinLink(officeId)
  const code = officeCode(officeId)
  const [codeCopied, setCodeCopied] = useState(false)
  function setOpen(v) {
    setOpenState(v)
    try { localStorage.setItem(INVITE_KEY, v ? '1' : '0') } catch { /* ignore */ }
  }
  // بعد النسخ أو الإرسال تنطوي البطاقة وحدها
  const foldSoon = () => setTimeout(() => setOpen(false), 1400)

  if (!open) {
    return (
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="skin-gold flex w-full items-center justify-between gap-3 rounded-[1.25rem] border border-amber-300/20 bg-gradient-to-br from-[#14203a] to-[#0a1222] px-4 py-3.5 text-start transition hover:border-amber-300/40"
      >
        <span className="flex min-w-0 items-center gap-2.5">
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-amber-400/15 text-amber-300">
            <Link2 size={16} />
          </span>
          <span className="min-w-0">
            <span className="block text-[13px] font-extrabold text-white">{tr('رابط انضمام الوكلاء')}</span>
            <span className="block text-[11px] font-bold text-slate-400">{tr('اضغط لعرض الرابط والرمز')}</span>
          </span>
        </span>
        <ChevronDown size={18} className="shrink-0 text-amber-300" />
      </button>
    )
  }

  return (
    <Card className="skin-gold relative overflow-hidden border-amber-300/20 bg-gradient-to-br from-[#14203a] to-[#0a1222] p-5">
      <button
        type="button"
        onClick={() => setOpen(false)}
        className="absolute end-3 top-3 z-10 inline-flex items-center gap-1 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5 text-[11px] font-bold text-slate-300 hover:bg-white/[0.08]"
      >
        {tr('إخفاء')}
        <ChevronDown size={14} className="rotate-180" />
      </button>
      <div className="flex flex-col gap-5 pt-6 sm:flex-row sm:items-center sm:pt-0">
        <div className="mx-auto shrink-0 rounded-2xl bg-white p-3 sm:mx-0">
          <QRCodeSVG value={link} size={128} level="M" />
        </div>
        <div className="min-w-0 flex-1">
          <p className="flex items-center gap-1.5 text-[11px] font-extrabold tracking-wider text-amber-300/90">
            <Link2 size={13} /> {tr('رابط انضمام الوكلاء')}
          </p>
          <p className="font-display mt-1 text-[17px] font-black text-white">{tr('ادعُ وكلاءك إلى مكتبك')}</p>
          <p className="mt-1 text-[12px] leading-relaxed text-slate-400">
            {tr('الوكيل يفتح الرابط أو يمسح الرمز، يسجّل دخوله بحسابه، ثم يرسل طلب الانضمام. تظهر الطلبات هنا لتوافق عليها.')}
          </p>
          <div className="mt-3 flex items-center gap-2">
            <span className="text-[11.5px] font-bold text-slate-400">{tr('كود المكتب')}</span>
            <button
              type="button"
              onClick={async () => {
                if ((await copyText(code)) !== false) {
                  setCodeCopied(true)
                  setTimeout(() => setCodeCopied(false), 1600)
                }
              }}
              dir="ltr"
              className="lux-latin inline-flex items-center gap-1.5 rounded-xl border border-amber-300/30 bg-amber-400/10 px-3 py-1.5 text-[16px] font-black tracking-[0.25em] text-amber-100 hover:bg-amber-400/20"
            >
              {code}
              {codeCopied ? <Check size={14} /> : <Copy size={13} className="opacity-70" />}
            </button>
          </div>
          <p dir="ltr" className="lux-latin mt-2 truncate text-[12px] font-bold text-amber-100/90">{link.replace('https://', '')}</p>
          <div className="mt-3 flex flex-wrap gap-2">
            <button
              type="button"
              onClick={async () => {
                if ((await copyText(link)) !== false) {
                  setCopied(true)
                  setTimeout(() => setCopied(false), 1600)
                  foldSoon()
                }
              }}
              className="inline-flex items-center gap-1.5 rounded-full border border-white/12 bg-white/[0.04] px-3.5 py-2 text-[12px] font-bold text-slate-200 hover:bg-white/[0.08]"
            >
              {copied ? <Check size={14} /> : <Copy size={14} />}
              {copied ? tr('تم النسخ') : tr('نسخ الرابط')}
            </button>
            <button
              type="button"
              onClick={() => {
                share.whatsapp('', `${tr('انضم إلى {office} على ALEGDALY TECH:', { office: officeName })} ${link}\n${tr('كود المكتب')}: ${code}`)
                foldSoon()
              }}
              className="inline-flex items-center gap-1.5 rounded-full border border-emerald-400/30 bg-emerald-500/10 px-3.5 py-2 text-[12px] font-bold text-emerald-200 hover:bg-emerald-500/20"
            >
              <MessageCircle size={14} /> {tr('إرسال عبر واتساب')}
            </button>
          </div>
        </div>
      </div>
    </Card>
  )
}

function PendingRow({ p }) {
  const toast = useToast()
  const [busy, setBusy] = useState(null)
  async function decide(status) {
    if (busy) return
    setBusy(status)
    try {
      await db.updateShared(MEMBER_COLL, p.id, { status, decidedAt: new Date().toISOString() })
      toast(status === 'approved' ? tr('تمت إضافة {name}', { name: p.name }) : tr('تم رفض الطلب'), status === 'approved' ? 'ok' : 'info')
    } catch (e) {
      toast(e?.message || tr('حدث خطأ، حاول مرة أخرى'), 'err')
    } finally {
      setBusy(null)
    }
  }
  return (
    <div className="flex flex-wrap items-center gap-3 border-b border-white/[0.06] py-3 last:border-0">
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-400/10 font-display text-[16px] font-black text-amber-200">
        {(p.name || '؟').trim().charAt(0)}
      </span>
      <div className="min-w-0 flex-1">
        <p className="truncate text-[14px] font-extrabold text-white">{p.name}</p>
        <p className="truncate text-[11.5px] text-slate-400">
          <span dir="ltr">{p.phone}</span>
          {p.email ? ` · ${p.email}` : ''}
        </p>
      </div>
      <div className="flex gap-2">
        <button
          type="button"
          onClick={() => decide('approved')}
          disabled={!!busy}
          className="flex items-center gap-1.5 rounded-xl bg-gradient-to-l from-emerald-500 to-emerald-400 px-3.5 py-2.5 text-[12.5px] font-extrabold text-emerald-950 disabled:opacity-50"
        >
          <CheckCircle2 size={15} /> {tr('موافقة')}
        </button>
        <button
          type="button"
          onClick={() => decide('rejected')}
          disabled={!!busy}
          aria-label={tr('رفض')}
          className="flex h-10 w-10 items-center justify-center rounded-xl border border-rose-400/30 text-rose-300 hover:bg-rose-500/10 disabled:opacity-50"
        >
          <XCircle size={16} />
        </button>
      </div>
    </div>
  )
}

function EditSheet({ agent, onClose }) {
  const toast = useToast()
  const [f, setF] = useState({ name: agent.name, phone: agent.phone, salary: agent.salary ? String(agent.salary) : '', note: agent.note })
  const [busy, setBusy] = useState(false)
  async function save() {
    if (busy) return
    if (!f.name.trim()) return toast(tr('أدخل اسم الوكيل'), 'err')
    setBusy(true)
    try {
      await db.updateShared(MEMBER_COLL, agent.memberId, {
        name: f.name.trim(),
        phone: f.phone.trim(),
        salary: Number(f.salary) || 0,
        note: f.note.trim(),
      })
      toast(tr('تم حفظ بيانات الوكيل'))
      onClose()
    } catch (e) {
      toast(e?.message || tr('حدث خطأ، حاول مرة أخرى'), 'err')
    } finally {
      setBusy(false)
    }
  }
  return (
    <div
      className="fixed inset-0 z-30 flex items-end justify-center bg-black/60 backdrop-blur-sm md:items-center md:p-6"
      style={{ height: 'var(--visual-height, 100dvh)' }}
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md overflow-y-auto rounded-t-3xl border border-white/10 bg-[#0b1424] p-5 pb-[calc(env(safe-area-inset-bottom,0px)+20px)] md:rounded-3xl md:pb-5"
        style={{ maxHeight: 'calc(var(--visual-height, 100dvh) - 2rem)' }}
      >
        <p className="font-display text-[18px] font-black text-white">{tr('بيانات الوكيل')}</p>
        <div className="mt-4 space-y-3">
          <Field label={tr('الاسم')}>
            <input value={f.name} onChange={(e) => setF((x) => ({ ...x, name: e.target.value }))} className={fieldCls} />
          </Field>
          <Field label={tr('رقم الهاتف')}>
            <input value={f.phone} onChange={(e) => setF((x) => ({ ...x, phone: e.target.value }))} dir="ltr" inputMode="tel" className={`${fieldCls} text-start`} />
          </Field>
          <Field label={tr('الراتب الشهري (FCFA)')}>
            <MoneyInput value={f.salary} onChange={(v) => setF((x) => ({ ...x, salary: v }))} placeholder="0" className={fieldCls} />
          </Field>
          <Field label={tr('ملاحظة')}>
            <input value={f.note} onChange={(e) => setF((x) => ({ ...x, note: e.target.value }))} className={fieldCls} />
          </Field>
        </div>
        <div className="mt-5 flex gap-2">
          <PrimaryBtn onClick={save} disabled={busy}>{busy ? tr('جارٍ الحفظ...') : tr('حفظ')}</PrimaryBtn>
          <GhostBtn onClick={onClose}>{tr('إلغاء')}</GhostBtn>
        </div>
      </div>
    </div>
  )
}

function AgentRow({ a, onEdit, gid }) {
  const toast = useToast()
  const [busy, setBusy] = useState(false)
  const ask = useConfirm()
  const confirmDel = false
  async function remove() {
    if (busy) return
    const ok = await ask({
      title: tr('حذف الوكيل «{name}» نهائياً؟', { name: a.name }),
      text: tr('يُقفل دخوله فوراً، وتبقى حركاته في السجل.'),
      confirmLabel: tr('حذف الوكيل'),
    })
    if (!ok) return
    // تأكيد داخل التطبيق (نوافذ التأكيد الافتراضية لا تعمل في تطبيق الأندرويد)
    setBusy(true)
    try {
      // يُعلَّم كمحذوف: يختفي من قائمتك فوراً ويُقفل دخوله، وتبقى حركاته في السجل
      const res = await db.updateShared(MEMBER_COLL, a.memberId, { status: 'deleted', deletedAt: new Date().toISOString() })
      if (!res) throw new Error(tr('هذا الوكيل محذوف من قبل — أعد فتح الصفحة'))
      toast(tr('تم حذف الوكيل'), 'info')
    } catch (e) {
      toast(e?.message || tr('تعذّر الحذف'), 'err')
    } finally {
      setBusy(false)
    }
  }
  async function setStatus(status) {
    if (busy) return
    setBusy(true)
    try {
      await db.updateShared(MEMBER_COLL, a.memberId, { status })
      toast(status === 'removed' ? tr('تم إيقاف الوكيل') : tr('تمت إعادة تفعيل الوكيل'), 'info')
    } catch (e) {
      toast(e?.message || tr('حدث خطأ، حاول مرة أخرى'), 'err')
    } finally {
      setBusy(false)
    }
  }
  return (
    <div className={`flex flex-wrap items-center gap-3 border-b border-white/[0.06] py-3 last:border-0 ${a.active ? '' : 'opacity-60'}`}>
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-emerald-500/15 font-display text-[16px] font-black text-emerald-200">
        {(a.name || '؟').trim().charAt(0)}
      </span>
      <div className="min-w-0 flex-1">
        <p className="truncate text-[14px] font-extrabold text-white">
          {a.name}
          {!a.active ? <span className="ms-2 rounded-full bg-rose-500/20 px-2 py-0.5 text-[10px] font-extrabold text-rose-200">{tr('موقوف')}</span> : null}
        </p>
        <p className="flex flex-wrap gap-x-3 text-[11.5px] text-slate-400">
          {a.phone ? <span dir="ltr" className="inline-flex items-center gap-1"><Phone size={11} />{a.phone}</span> : null}
          {a.email ? <span className="inline-flex min-w-0 items-center gap-1 truncate"><Mail size={11} />{a.email}</span> : null}
          {a.salary ? <span>{tr('الراتب')}: {fmt(a.salary)}</span> : null}
        </p>
      </div>
      <div className="flex gap-1.5">
        <button
          type="button"
          onClick={() => onEdit(a)}
          aria-label={tr('تعديل')}
          className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 text-slate-300 hover:bg-white/[0.06]"
        >
          <Pencil size={15} />
        </button>
        <button
          type="button"
          onClick={() => setStatus(a.active ? 'removed' : 'approved')}
          disabled={busy}
          aria-label={a.active ? tr('إيقاف') : tr('إعادة التفعيل')}
          className={`flex h-10 w-10 items-center justify-center rounded-xl border disabled:opacity-50 ${
            a.active ? 'border-rose-400/30 text-rose-300 hover:bg-rose-500/10' : 'border-emerald-400/30 text-emerald-300 hover:bg-emerald-500/10'
          }`}
        >
          {a.active ? <UserX size={15} /> : <UserCheck size={15} />}
        </button>
        <button
          type="button"
          onClick={remove}
          disabled={busy}
          aria-label={tr('حذف')}
          className={`flex h-10 items-center justify-center gap-1.5 rounded-xl border border-rose-500/40 disabled:opacity-50 ${
            confirmDel ? 'bg-rose-600 px-3 text-[12px] font-extrabold text-white' : 'w-10 bg-rose-500/10 text-rose-300 hover:bg-rose-500/20'
          }`}
        >
          <Trash2 size={15} />
          {confirmDel ? tr('تأكيد الحذف') : null}
        </button>
      </div>
    </div>
  )
}

/** وكلاء المكتب المشترك: رابط الانضمام + الطلبات + الإدارة */
export default function OfficeTeam() {
  const { officeId, officeName, pendingMembers, roster, inactive, gid } = useSession()
  const [editing, setEditing] = useState(null)

  return (
    <div className="space-y-5">
      <div className="rise">
        <p className="text-[11px] font-bold tracking-[0.18em] text-emerald-400/80">{officeName}</p>
        <h1 className="font-display text-[24px] font-extrabold tracking-tight text-white md:text-[28px]">{tr('وكلاء المكتب')}</h1>
      </div>

      <InviteCard officeId={officeId} officeName={officeName} />

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
        <div>
          <SectionTitle hint={pendingMembers.length ? String(pendingMembers.length) : null}>
            <span className="inline-flex items-center gap-2"><Clock size={16} className="text-amber-300" />{tr('طلبات الانضمام')}</span>
          </SectionTitle>
          {pendingMembers.length ? (
            <Card className="px-4">{pendingMembers.map((p) => <PendingRow key={p.id} p={p} />)}</Card>
          ) : (
            <EmptyState icon={UserPlus} title={tr('لا توجد طلبات جديدة')} text={tr('أرسل رابط الانضمام لوكلائك لتظهر طلباتهم هنا.')} />
          )}
        </div>

        <div>
          <SectionTitle hint={String(roster.length + inactive.length)}>
            <span className="inline-flex items-center gap-2"><Users size={16} className="text-emerald-300" />{tr('الوكلاء')}</span>
          </SectionTitle>
          {roster.length || inactive.length ? (
            <Card className="px-4">
              {[...roster, ...inactive].map((a) => <AgentRow key={a.userId} a={a} onEdit={setEditing} gid={gid} />)}
            </Card>
          ) : (
            <EmptyState icon={Users} title={tr('لا يوجد وكلاء بعد')} />
          )}
        </div>
      </div>

      {editing ? <EditSheet agent={editing} onClose={() => setEditing(null)} /> : null}
    </div>
  )
}
