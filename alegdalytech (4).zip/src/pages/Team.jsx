import { useEffect, useMemo, useState } from 'react'
import {
  Users,
  Plus,
  Copy,
  Lock,
  RefreshCw,
  Pencil,
  Trash2,
  MessageCircle,
  Power,
  Phone,
  KeyRound,
  X,
  Wallet,
  Check,
  UserPlus,
  ArrowLeft,
} from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { db } from '../lib/db'
import { team } from '../lib/team'
import { share } from '../lib/share'
import { useLiveShared } from '../lib/useLive'
import { useSession } from '../components/Session'
import { Card, Field, PrimaryBtn, GhostBtn, fieldCls, useToast, useConfirm, EmptyState, SectionTitle } from '../components/ui'
import { generatePin, suggestHandle, handleOk, copyText, credentialsMessage } from '../components/credentials'
import { ROLES } from '../components/roles'
import OwnerAccess from '../components/OwnerAccess'
import AppQR from '../components/AppQR'
import { fmt } from '../components/fees'
import MoneyInput from '../components/MoneyInput'
import { tr } from '../components/i18n'

const APP_TITLE = 'الأقدالي للتقنية'

function Sheet({ open, onClose, children }) {
  if (!open) return null
  return (
    <div
      className="fixed inset-0 z-40 flex items-end justify-center bg-black/70 md:items-center"
      style={{ height: 'var(--visual-height, 100dvh)' }}
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg overflow-y-auto rounded-t-3xl border border-white/10 bg-[#0b1424] p-5 md:rounded-3xl"
        style={{ maxHeight: 'calc(var(--visual-height, 100dvh) - 2rem)' }}
        onClick={(e) => e.stopPropagation()}
      >
        {children}
      </div>
    </div>
  )
}

export default function Team() {
  const session = useSession()
  const toast = useToast()
  const ask = useConfirm()
  const navigate = useNavigate()
  const { canManage, roster, inactive, gid, openTeamAdmin, refresh, setSelectedAgentId, dropMember } = session

  const { data: live } = useLiveShared('transactions', { order: '-createdAt', limit: 100 })
  const version = useMemo(() => (live || []).map((r) => `${r.id}:${r.updatedAt || ''}`).join('|'), [live])

  const [balances, setBalances] = useState({})
  const [sheet, setSheet] = useState(null)
  const [createOpen, setCreateOpen] = useState(false)
  const [created, setCreated] = useState(null)
  const [editing, setEditing] = useState(false)
  const [edit, setEdit] = useState({ name: '', phone: '', salary: '' })
  const [busy, setBusy] = useState(false)
  const [draft, setDraft] = useState({ name: '', handle: '', phone: '', salary: '' })

  useEffect(() => {
    if (!canManage) return
    let alive = true
    Promise.all([
      db.groupByShared('transactions', 'agentUserId', { agg: 'sum', field: 'cashInHand', filters: { kind: 'tx' } }),
      db.groupByShared('transactions', 'agentUserId', { agg: 'sum', field: 'amount', filters: { kind: 'cash' } }),
      db.groupByShared('transactions', 'agentUserId', { agg: 'sum', field: 'myProfit', filters: { kind: 'tx' } }),
    ])
      .then(([inc, handed, profit]) => {
        if (!alive) return
        const map = {}
        for (const r of inc || []) map[r.key] = { in: Number(r.value) || 0 }
        for (const r of handed || []) map[r.key] = { ...(map[r.key] || { in: 0 }), handed: Number(r.value) || 0 }
        for (const r of profit || []) map[r.key] = { ...(map[r.key] || { in: 0 }), profit: Number(r.value) || 0 }
        setBalances(map)
      })
      .catch(() => {})
    return () => {
      alive = false
    }
  }, [canManage, version])

  const totalInHands = useMemo(
    () => roster.reduce((s, a) => {
      const b = balances[a.userId] || {}
      return s + ((b.in || 0) - (b.handed || 0))
    }, 0),
    [roster, balances],
  )

  const handles = useMemo(() => [...(roster || []), ...(inactive || [])].map((a) => a.handle), [roster, inactive])

  function openCreate() {
    setDraft({ name: '', handle: '', phone: '', salary: '' })
    setCreateOpen(true)
  }

  async function createAgent() {
    const name = draft.name.trim()
    if (!name) return toast(tr('أدخل اسم الوكيل'), 'err')
    const handle = (draft.handle.trim() || suggestHandle(name, handles)).toLowerCase()
    if (!handleOk(handle)) return toast(tr('اسم الدخول: أحرف إنجليزية أو أرقام، 3 خانات على الأقل'), 'err')
    if (!gid) return toast(tr('تعذّر تجهيز الجلسة، أعد المحاولة'), 'err')

    setBusy(true)
    try {
      const cfg = await team.config().catch(() => null)
      if (!cfg?.loginConfig?.pin) await team.setLoginConfig({ pin: true })

      const pin = generatePin()
      const res = await team.createMember({ handle, password: pin, role: 'agent', displayName: name })
      const userId = res?.userId
      if (!userId) throw new Error('تعذّر إنشاء الحساب')

      await db.upsertShared(
        'agents',
        // الرمز لا يُحفظ في البيانات — يبقى على الخادم فقط ويظهر للمالك مرة واحدة
        { name, phone: draft.phone.trim(), salary: Number(draft.salary) || 0, handle },
        userId,
        { groupId: gid, visibleTo: `user:${userId}`, writableBy: 'admins' },
      )

      setCreated({ userId, name, handle, pin, phone: draft.phone.trim() })
      setCreateOpen(false)
      await refresh()
    } catch (e) {
      toast(e?.message || tr('تعذّر إنشاء الوكيل'), 'err')
    } finally {
      setBusy(false)
    }
  }

  async function resetPin(agent) {
    if (!gid) return
    setBusy(true)
    try {
      const pin = generatePin()
      await team.resetPassword(agent.userId, pin)
      await db.upsertShared('agents', { pin: null, handle: agent.handle, name: agent.name }, agent.userId, {
        groupId: gid,
        visibleTo: `user:${agent.userId}`,
        writableBy: 'admins',
      })
      setCreated({ userId: agent.userId, name: agent.name, handle: agent.handle, pin, phone: agent.phone })
      toast(tr('تم إنشاء رمز جديد'))
    } catch (e) {
      toast(e?.message || tr('تعذّر تغيير الرمز'), 'err')
    } finally {
      setBusy(false)
    }
  }

  function startEdit(agent) {
    setEdit({ name: agent.name || '', phone: agent.phone || '', salary: agent.salary ? String(agent.salary) : '' })
    setEditing(true)
  }

  async function saveEdit(agent) {
    if (!gid) return
    if (!edit.name.trim()) return toast(tr('الاسم مطلوب'), 'err')
    setBusy(true)
    try {
      await db.upsertShared(
        'agents',
        { name: edit.name.trim(), phone: edit.phone.trim(), salary: Number(edit.salary) || 0, handle: agent.handle, pin: null },
        agent.userId,
        { groupId: gid, visibleTo: `user:${agent.userId}`, writableBy: 'admins' },
      )
      await refresh()
      setSheet((s) => (s ? { ...s, name: edit.name.trim(), phone: edit.phone.trim(), salary: Number(edit.salary) || 0 } : s))
      setEditing(false)
      toast(tr('تم حفظ بيانات الوكيل'))
    } catch (e) {
      toast(e?.message || tr('تعذّر الحفظ'), 'err')
    } finally {
      setBusy(false)
    }
  }

  async function toggleActive(agent) {
    setBusy(true)
    try {
      if (agent.active) {
        await team.disableMember(agent.userId)
        toast(tr('تم إيقاف الوكيل'))
      } else {
        await team.enableMember(agent.userId)
        toast(tr('تم إعادة تفعيل الوكيل'))
      }
      setSheet(null)
      await refresh()
    } catch (e) {
      toast(e?.message || tr('تعذّرت العملية'), 'err')
    } finally {
      setBusy(false)
    }
  }

  async function deleteAgent(agent) {
    const ok = await ask({
      title: tr('حذف الوكيل «{name}» نهائياً؟', { name: agent.name }),
      text: tr('سيُغلق حسابه ولا يستطيع الدخول مرة أخرى.'),
      confirmLabel: tr('حذف الوكيل'),
    })
    if (!ok) return
    setBusy(true)
    try {
      // حذف الحساب والملف معاً — وإذا كان الحساب محذوفاً من قبل نكمل حذف الملف بدل أن يبقى عالقاً
      const [acc] = await Promise.allSettled([
        team.deleteMember(agent.userId),
        gid ? db.deleteShared('agents', agent.userId, gid) : Promise.resolve(),
      ])
      const gone = acc.status === 'fulfilled' || /not.?found|no.?such|404/i.test(String(acc.reason?.message || acc.reason?.status || ''))
      if (!gone) throw acc.reason || new Error(tr('تعذّر الحذف'))
      dropMember?.(agent.userId)
      setSheet(null)
      toast(tr('تم حذف الوكيل'))
      refresh()
    } catch (e) {
      toast(e?.message || tr('تعذّر الحذف'), 'err')
      refresh()
    } finally {
      setBusy(false)
    }
  }

  async function clearMovements(agent) {
    const msg = agent
      ? tr('حذف كل حركات «{name}» نهائياً؟ لا يمكن التراجع.', { name: agent.name })
      : tr('حذف كل حركات جميع الوكلاء نهائياً؟ لا يمكن التراجع.')
    const ok = await ask({ title: msg, confirmLabel: tr('حذف الحركات') })
    if (!ok) return
    setBusy(true)
    try {
      const rows = await db.selectAllShared('transactions', agent ? { agentUserId: agent.userId } : {})
      // على دفعات متوازية بدل واحدة واحدة — أسرع بكثير
      const list = rows || []
      for (let i = 0; i < list.length; i += 8) {
        await Promise.all(list.slice(i, i + 8).map((r) => db.deleteShared('transactions', r.id, gid || undefined).catch(() => null)))
      }
      toast(tr('تم حذف الحركات'))
    } catch (e) {
      toast(e?.message || tr('تعذّر الحذف'), 'err')
    } finally {
      setBusy(false)
    }
  }

  function sendCredentials(agent, pin) {
    if (!agent.phone) return toast(tr('أضف رقم هاتف الوكيل أولاً'), 'err')
    share.whatsapp(agent.phone, credentialsMessage({ appName: APP_TITLE, name: agent.name, handle: agent.handle, pin }))
  }

  async function copy(text, label) {
    if (!text) return toast(tr('لا يوجد رمز محفوظ — اضغط «رمز جديد» لإنشاء واحد'), 'err')
    const ok = await copyText(text)
    toast(ok ? `${tr('تم النسخ')} — ${tr(label)}` : tr('تعذّر النسخ'), ok ? 'ok' : 'err')
  }

  if (!canManage) {
    return (
      <Card className="p-4">
        <EmptyState icon={Users} title={tr('هذه الشاشة للإدارة')} />
      </Card>
    )
  }

  return (
    <div className="space-y-5">
      <div className="rise flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-[11px] font-bold tracking-[0.18em] text-emerald-400/80">{tr('الإدارة')}</p>
          <h1 className="font-display text-[24px] font-extrabold tracking-tight text-white md:text-[28px]">{tr('الوكلاء والحسابات')}</h1>
        </div>
        <div className="flex gap-2">
          <GhostBtn onClick={openCreate}>
            <span className="inline-flex items-center gap-1.5">
              <Plus size={14} />
              {tr('وكيل جديد')}
            </span>
          </GhostBtn>
          <GhostBtn onClick={() => openTeamAdmin({ roles: ROLES })}>
            <span className="inline-flex items-center gap-1.5">
              <UserPlus size={14} />
              {tr('خيارات متقدمة')}
            </span>
          </GhostBtn>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="rounded-2xl border border-white/[0.08] bg-white/[0.035] px-4 py-3">
          <p className="text-[10.5px] font-bold text-slate-500">{tr('الوكلاء النشطون')}</p>
          <p className="font-display mt-1 text-[20px] font-black text-white">{fmt(roster.length)}</p>
        </div>
        <div className="rounded-2xl border border-emerald-400/15 bg-emerald-500/[0.08] px-4 py-3">
          <p className="text-[10.5px] font-bold text-emerald-200/70">{tr('الكاش في أيديهم')}</p>
          <p className="font-display mt-1 text-[20px] font-black text-emerald-300">{fmt(totalInHands)}</p>
        </div>
      </div>

      <OwnerAccess />

      <AppQR />

      {roster.length === 0 ? (
        <Card className="p-4">
          <EmptyState
            icon={Users}
            title={tr('لا يوجد وكلاء بعد')}
            text={tr('أضف وكلاءك من شاشة الوكلاء — يتولّد لكل واحد اسم دخول ورمز تلقائياً.')}
            action={<GhostBtn onClick={openCreate}>{tr('وكيل جديد')}</GhostBtn>}
          />
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
          {roster.map((a) => {
            const bal = balances[a.userId] || {}
            const balance = (bal.in || 0) - (bal.handed || 0)
            return (
              <Card key={a.userId} className="rise p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="font-display truncate text-[15px] font-extrabold text-slate-100">{a.name}</p>
                    <p className="mt-0.5 flex items-center gap-1 truncate text-[11px] font-bold text-emerald-300/70">
                      <KeyRound size={10} />
                      @{a.handle || '—'}
                    </p>
                    <p className="mt-0.5 flex items-center gap-1 truncate text-[10.5px] text-slate-500">
                      <Phone size={10} />
                      {a.phone || tr('لا يوجد رقم')}
                    </p>
                  </div>
                  <span className="shrink-0 rounded-full border border-white/10 bg-white/[0.04] px-2.5 py-1 text-[10px] font-bold text-slate-400">
                    {a.salary ? `${tr('الراتب')} ${fmt(a.salary)}` : tr('بدون راتب')}
                  </span>
                </div>

                <div className="mt-3 rounded-2xl border border-white/[0.06] bg-black/20 px-3 py-2.5">
                  <p className="text-[10.5px] font-bold text-slate-500">{tr('الكاش في يده')}</p>
                  <p className="font-display mt-0.5 text-[19px] font-black leading-none text-white">
                    {fmt(balance)}
                    <span className="ms-1 text-[10px] font-bold text-emerald-300/70">FCFA</span>
                  </p>
                  <p className="mt-1 text-[10.5px] text-slate-500">{tr('إجمالي المسلَّم')} {fmt(bal.handed || 0)} · {tr('مكسب المكتب')} {fmt(bal.profit || 0)}</p>
                </div>

                <div className="mt-3 flex gap-2">
                  <GhostBtn className="flex-1 !px-2 !text-[12px]" onClick={() => { setSheet(a); setEditing(false) }}>
                    <span className="inline-flex items-center justify-center gap-1.5">
                      {tr('التفاصيل والدخول')}
                      <ArrowLeft size={13} className="ltr:rotate-180" />
                    </span>
                  </GhostBtn>
                  <GhostBtn
                    className="!px-2.5 !text-[12px]"
                    onClick={() => {
                      setSelectedAgentId(a.userId)
                      navigate('/')
                    }}
                  >
                    <Wallet size={13} />
                  </GhostBtn>
                </div>
              </Card>
            )
          })}
        </div>
      )}

      {inactive.length > 0 ? (
        <div className="space-y-2">
          <SectionTitle hint={`${inactive.length}`}>{tr('وكلاء موقوفون')}</SectionTitle>
          <div className="grid grid-cols-1 gap-2 md:grid-cols-2">
            {inactive.map((a) => (
              <Card key={a.userId} className="flex items-center justify-between gap-3 p-3">
                <div className="min-w-0">
                  <p className="truncate text-[13px] font-bold text-slate-300">{a.name}</p>
                  <p className="text-[10.5px] text-slate-500">@{a.handle}</p>
                </div>
                <div className="flex gap-1.5">
                  <button
                    onClick={() => toggleActive(a)}
                    className="rounded-lg bg-emerald-500/15 px-2.5 py-1.5 text-[11px] font-bold text-emerald-200"
                  >
                    {tr('تفعيل')}
                  </button>
                  <button
                    onClick={() => deleteAgent(a)}
                    className="rounded-lg bg-rose-500/15 px-2.5 py-1.5 text-[11px] font-bold text-rose-200"
                  >
                    {tr('حذف')}
                  </button>
                </div>
              </Card>
            ))}
          </div>
        </div>
      ) : null}

      <div className="flex justify-center pb-2">
        <button
          onClick={() => clearMovements(null)}
          disabled={busy}
          className="rounded-xl border border-rose-400/25 bg-rose-500/10 px-4 py-2.5 text-[12px] font-bold text-rose-200 transition hover:bg-rose-500/20 disabled:opacity-50"
        >
          <span className="inline-flex items-center gap-1.5">
            <Trash2 size={13} />
            {tr('حذف كل حركات جميع الوكلاء')}
          </span>
        </button>
      </div>

      {/* ── نافذة: إنشاء وكيل ── */}
      <Sheet open={createOpen} onClose={() => setCreateOpen(false)}>
        <div className="mb-4 flex items-center justify-between">
          <h3 className="font-display text-[17px] font-extrabold text-white">{tr('وكيل جديد')}</h3>
          <button onClick={() => setCreateOpen(false)} className="text-slate-500 hover:text-slate-300">
            <X size={18} />
          </button>
        </div>
        <div className="space-y-3">
          <Field label={tr('اسم الوكيل')}>
            <input
              value={draft.name}
              onChange={(e) => setDraft({ ...draft, name: e.target.value })}
              placeholder="Alhassane"
              className={fieldCls}
            />
          </Field>
          <Field label={tr('اسم الدخول (بالإنجليزية)')} hint={tr('إن تركته فارغاً سيُقترح تلقائياً')}>
            <input
              value={draft.handle}
              onChange={(e) => setDraft({ ...draft, handle: e.target.value })}
              placeholder="alhassane"
              dir="ltr"
              className={fieldCls}
            />
          </Field>
          <Field label={tr('رقم الهاتف (واتساب)')}>
            <input
              value={draft.phone}
              onChange={(e) => setDraft({ ...draft, phone: e.target.value })}
              inputMode="tel"
              placeholder="22790123456"
              dir="ltr"
              className={fieldCls}
            />
          </Field>
          <Field label={tr('الراتب الشهري (FCFA)')} hint={tr('اختياري — يظهر للوكيل في حسابه')}>
            <MoneyInput
              value={draft.salary}
              onChange={(v) => setDraft({ ...draft, salary: v })}
              placeholder="50,000"
              className={fieldCls}
            />
          </Field>
          <p className="rounded-xl border border-amber-400/25 bg-amber-500/10 px-3 py-2.5 text-[11px] leading-relaxed text-amber-100">
            {tr('سيُولَّد رمز سري من 6 أرقام تلقائياً ويظهر لك بعد الحفظ — أعطه للوكيل ليدخل.')}
          </p>
          <PrimaryBtn onClick={createAgent} disabled={busy}>
            {tr(busy ? 'جارٍ الإنشاء...' : 'إنشاء حساب الوكيل')}
          </PrimaryBtn>
        </div>
      </Sheet>

      {/* ── نافذة: بيانات الدخول الجديدة ── */}
      <Sheet open={!!created} onClose={() => setCreated(null)}>
        {created ? (
          <div>
            <div className="mb-4 flex items-center gap-2 text-emerald-300">
              <Check size={18} />
              <h3 className="font-display text-[17px] font-extrabold">{tr('بيانات الدخول')} — {created.name}</h3>
            </div>
            <div className="space-y-2 rounded-2xl border border-white/10 bg-black/25 p-4">
              <div className="flex items-center justify-between">
                <span className="text-[11.5px] font-bold text-slate-400">{tr('اسم المستخدم')}</span>
                <span dir="ltr" className="font-display text-[15px] font-extrabold text-white">{created.handle}</span>
              </div>
              <div className="flex items-center justify-between border-t border-white/[0.07] pt-2">
                <span className="text-[11.5px] font-bold text-slate-400">{tr('الرمز السري')}</span>
                <span dir="ltr" className="font-display text-[19px] font-black tracking-[0.18em] text-emerald-300">
                  {created.pin}
                </span>
              </div>
            </div>
            <p className="mt-2 rounded-xl border border-amber-400/25 bg-amber-500/10 px-3 py-2 text-[11.5px] font-bold leading-relaxed text-amber-200">
              {tr('احفظ هذا الرمز أو أرسله الآن — لن يظهر مرة أخرى.')}
            </p>
            <div className="mt-3 flex gap-2">
              <GhostBtn className="flex-1" onClick={() => copy(`${created.handle} / ${created.pin}`, 'بيانات الدخول')}>
                <span className="inline-flex items-center gap-1.5">
                  <Copy size={13} />
                  {tr('نسخ')}
                </span>
              </GhostBtn>
              <GhostBtn className="flex-1" onClick={() => sendCredentials(created, created.pin)}>
                <span className="inline-flex items-center gap-1.5">
                  <MessageCircle size={13} />
                  {tr('إرسال بالواتساب')}
                </span>
              </GhostBtn>
            </div>
            <PrimaryBtn className="mt-3" onClick={() => setCreated(null)}>
              {tr('تم')}
            </PrimaryBtn>
          </div>
        ) : null}
      </Sheet>

      {/* ── نافذة: تفاصيل الوكيل ── */}
      <Sheet open={!!sheet} onClose={() => setSheet(null)}>
        {sheet ? (
          <div className="space-y-4">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-display text-[18px] font-extrabold text-white">{sheet.name}</h3>
                <p className="mt-0.5 text-[11px] font-bold text-emerald-300/70" dir="ltr">@{sheet.handle}</p>
              </div>
              <button onClick={() => setSheet(null)} className="text-slate-500 hover:text-slate-300">
                <X size={18} />
              </button>
            </div>

            {/* بيانات الدخول */}
            <div className="rounded-2xl border border-emerald-400/20 bg-emerald-500/[0.07] p-4">
              <p className="mb-2 flex items-center gap-1.5 text-[11.5px] font-extrabold text-emerald-200">
                <KeyRound size={13} />
                {tr('بيانات الدخول')}
              </p>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11.5px] font-bold text-slate-400">{tr('اسم المستخدم')}</span>
                  <span dir="ltr" className="text-[14px] font-extrabold text-white">{sheet.handle || '—'}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[11.5px] font-bold text-slate-400">{tr('الرمز السري')}</span>
                  <span className="flex items-center gap-1.5 text-[12px] font-extrabold text-slate-400">
                    <Lock size={12} />
                    {tr('مخفي للأمان')}
                  </span>
                </div>
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                <button
                  onClick={() => resetPin(sheet)}
                  disabled={busy}
                  className="flex items-center gap-1.5 rounded-lg bg-emerald-500/15 px-3 py-2 text-[12px] font-bold text-emerald-200 disabled:opacity-50"
                >
                  <RefreshCw size={13} />
                  {tr('رمز جديد')}
                </button>
                <button
                  onClick={() => copy(sheet.handle, 'اسم المستخدم')}
                  className="flex items-center gap-1.5 rounded-lg bg-white/[0.06] px-3 py-2 text-[12px] font-bold text-slate-200"
                >
                  <Copy size={13} />
                  {tr('نسخ')}
                </button>
              </div>
              <p className="mt-2.5 text-[10.5px] leading-relaxed text-slate-500">
                {tr('لأمان أعلى، الرمز السري لا يُحفظ في التطبيق ويظهر لك مرة واحدة فقط عند إنشائه. إذا نسيه الوكيل اضغط «رمز جديد» وأرسله له.')}
              </p>
            </div>

            {/* البيانات */}
            <div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] p-4">
              <div className="mb-2 flex items-center justify-between">
                <p className="text-[11.5px] font-extrabold text-slate-300">{tr('بيانات الوكيل')}</p>
                {!editing ? (
                  <button
                    onClick={() => startEdit(sheet)}
                    className="flex items-center gap-1 rounded-lg bg-white/[0.06] px-2 py-1 text-[11px] font-bold text-slate-200"
                  >
                    <Pencil size={11} />
                    {tr('تعديل')}
                  </button>
                ) : null}
              </div>

              {editing ? (
                <div className="space-y-2.5">
                  <Field label={tr('الاسم')}>
                    <input value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} className={fieldCls} />
                  </Field>
                  <Field label={tr('الهاتف')}>
                    <input
                      value={edit.phone}
                      onChange={(e) => setEdit({ ...edit, phone: e.target.value })}
                      dir="ltr"
                      inputMode="tel"
                      className={fieldCls}
                    />
                  </Field>
                  <Field label={tr('الراتب الشهري (FCFA)')}>
                    <MoneyInput
                      value={edit.salary}
                      onChange={(v) => setEdit({ ...edit, salary: v })}
                      className={fieldCls}
                    />
                  </Field>
                  <div className="flex gap-2 pt-1">
                    <PrimaryBtn className="!py-2.5 !text-[13px]" onClick={() => saveEdit(sheet)} disabled={busy}>
                      {tr('حفظ')}
                    </PrimaryBtn>
                    <GhostBtn className="!py-2.5" onClick={() => setEditing(false)}>
                      {tr('إلغاء')}
                    </GhostBtn>
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[11.5px] font-bold text-slate-400">{tr('الهاتف')}</span>
                    <span dir="ltr" className="text-[13px] font-bold text-slate-100">{sheet.phone || '—'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[11.5px] font-bold text-slate-400">{tr('الراتب')}</span>
                    <span className="text-[13px] font-bold text-slate-100">{sheet.salary ? `${fmt(sheet.salary)} FCFA` : '—'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[11.5px] font-bold text-slate-400">{tr('الكاش في يده')}</span>
                    <span className="font-display text-[14px] font-black text-emerald-300">
                      {fmt((balances[sheet.userId]?.in || 0) - (balances[sheet.userId]?.handed || 0))}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[11.5px] font-bold text-slate-400">{tr('إجمالي المسلَّم')}</span>
                    <span className="font-display text-[14px] font-black text-sky-300">{fmt(balances[sheet.userId]?.handed || 0)}</span>
                  </div>
                </div>
              )}
            </div>

            {/* إجراءات */}
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => toggleActive(sheet)}
                disabled={busy}
                className="flex flex-1 items-center justify-center gap-1.5 rounded-xl border border-white/12 bg-white/[0.04] px-3 py-2.5 text-[12px] font-bold text-slate-200 disabled:opacity-50"
              >
                <Power size={13} />
                {tr(sheet.active ? 'إيقاف الوكيل' : 'إعادة تفعيل')}
              </button>
              <button
                onClick={() => clearMovements(sheet)}
                disabled={busy}
                className="flex flex-1 items-center justify-center gap-1.5 rounded-xl border border-amber-400/25 bg-amber-500/10 px-3 py-2.5 text-[12px] font-bold text-amber-200 disabled:opacity-50"
              >
                <Trash2 size={13} />
                {tr('حذف حركاته')}
              </button>
              <button
                onClick={() => deleteAgent(sheet)}
                disabled={busy}
                className="flex w-full items-center justify-center gap-1.5 rounded-xl border border-rose-400/25 bg-rose-500/10 px-3 py-2.5 text-[12px] font-bold text-rose-200 disabled:opacity-50"
              >
                <Trash2 size={13} />
                {tr('حذف الوكيل نهائياً')}
              </button>
            </div>
          </div>
        ) : null}
      </Sheet>
    </div>
  )
}
