import { useEffect, useState } from 'react'
import { ArrowRight, ArrowLeft, Building2, LogIn, Clock, CheckCircle2, XCircle, Send, ShieldCheck } from 'lucide-react'
import { auth } from '../lib/auth'
import { db } from '../lib/db'
import { useLiveShared } from '../lib/useLive'
import Logo from '../components/Logo'
import { useToast } from '../components/ui'
import { LangSwitcher, tr, useLang } from '../components/i18n'
import { useMode, ThemeToggle, ModeScope } from '../components/theme'
import { STATUS_COLL, MEMBER_COLL, officeState } from '../components/saas'
import { push } from '../lib/push'
import { getNotifyPrefs } from '../components/notifyPrefs'

const INPUT =
  'w-full rounded-[0.9rem] border border-white/10 bg-white/[0.035] px-3.5 py-3 text-[15px] text-slate-50 outline-none transition placeholder:text-slate-500 focus:border-amber-300/60 focus:bg-white/[0.06] focus:ring-4 focus:ring-amber-300/10'

export function joinIdFromHash() {
  try {
    const m = window.location.hash.match(/^#\/join\/([^/?#]+)/)
    return m ? decodeURIComponent(m[1]) : null
  } catch {
    return null
  }
}

/** صفحة انضمام وكيل إلى مكتب مشترك — تُفتح من رابط صاحب المكتب */
export default function OfficeJoin({ officeId }) {
  const toast = useToast()
  const { lang } = useLang()
  const { mode, toggle } = useMode('dark')
  const rtl = lang === 'ar'
  const Back = rtl ? ArrowRight : ArrowLeft

  const [user, setUser] = useState(() => auth.getCurrentUser())
  useEffect(() => auth.onAuthChange((u) => setUser(u)), [])
  const signedIn = !!user && auth.isAuthenticated()

  const [office, setOffice] = useState(undefined)
  useEffect(() => {
    let alive = true
    db.getShared(STATUS_COLL, officeId)
      .then((r) => alive && setOffice(r || null))
      .catch(() => alive && setOffice(null))
    return () => { alive = false }
  }, [officeId])

  const { data: mine } = useLiveShared(MEMBER_COLL, { filters: { userId: signedIn ? user.id : '__none__', ws: officeId } })
  // طلب حذفه صاحب المكتب لا يُحسب — يستطيع الوكيل إرسال طلب جديد
  const myReq = signedIn ? (mine || []).find((r) => r.status !== 'deleted') || null : null
  const hadDeleted = signedIn && (mine || []).some((r) => r.status === 'deleted')

  const [form, setForm] = useState({ name: '', phone: '' })
  const [busy, setBusy] = useState(false)
  const [signing, setSigning] = useState(false)

  useEffect(() => {
    if (user?.displayName) setForm((f) => (f.name ? f : { ...f, name: user.displayName }))
  }, [user])

  async function signIn() {
    if (signing) return
    setSigning(true)
    try {
      await auth.signIn()
    } finally {
      setSigning(false)
    }
  }

  async function submit(e) {
    e.preventDefault()
    if (busy || !signedIn || !office?.groupId) return
    if (!form.name.trim() || !form.phone.trim()) return toast(tr('أكمل كل الخانات المطلوبة'), 'err')
    setBusy(true)
    try {
      await db.insertShared(
        MEMBER_COLL,
        {
          ws: officeId,
          userId: user.id,
          email: user.email || '',
          name: form.name.trim(),
          phone: form.phone.trim(),
          officeName: office.officeName || '',
          groupId: office.groupId,
          salary: 0,
          note: '',
          status: 'pending',
        },
        hadDeleted ? `${officeId}:${user.id}:${Date.now()}` : `${officeId}:${user.id}`,
        { groupId: office.groupId, visibleTo: 'creator-and-admin', writableBy: 'admins' },
      )
      // إشعار فوري لصاحب المكتب (معرّف المكتب = معرّفه) — لا يوقف الطلب إذا فشل
      getNotifyPrefs(officeId)
        .then((p) => (p.ops === false ? null : push.send(officeId, {
          title: '👤 طلب انضمام وكيل',
          body: `${form.name.trim()} (${form.phone.trim()}) يطلب الانضمام إلى مكتبك.`,
          url: '#/team',
        })))
        .catch(() => null)
      toast(tr('تم إرسال طلب الانضمام'))
    } catch (err) {
      if (err?.status === 409) toast(tr('أرسلت طلباً لهذا المكتب من قبل'), 'info')
      else toast(err?.message || tr('حدث خطأ، حاول مرة أخرى'), 'err')
    } finally {
      setBusy(false)
    }
  }

  const state = officeState(office)
  const closed = office && (state === 'expired' || state === 'suspended')
  const isOwner = signedIn && user.id === officeId

  let body
  if (office === undefined) {
    body = (
      <div className="flex justify-center py-12">
        <div className="h-7 w-7 animate-spin rounded-full border-2 border-white/15 border-t-amber-300" />
      </div>
    )
  } else if (!office || !office.groupId) {
    body = (
      <div className="py-6 text-center">
        <XCircle className="mx-auto text-rose-300" size={30} />
        <p className="font-display mt-3 text-[18px] font-black text-white">{tr('رابط الانضمام غير صالح')}</p>
        <p className="mt-1 text-[12.5px] text-slate-400">{tr('اطلب من صاحب المكتب رابطاً جديداً.')}</p>
      </div>
    )
  } else if (!signedIn) {
    body = (
      <div className="text-center">
        <p className="text-[13px] leading-relaxed text-slate-300">
          {tr('سجّل دخولك بحسابك (Google أو البريد الإلكتروني) ثم أرسل طلب الانضمام.')}
        </p>
        <button
          type="button"
          onClick={signIn}
          disabled={signing}
          className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-br from-[#fbe3a1] via-[#f0b847] to-[#c98a22] py-3.5 text-[15px] font-extrabold text-[#1a1206] disabled:opacity-60"
        >
          <LogIn size={17} /> {tr('تسجيل الدخول للمتابعة')}
        </button>
      </div>
    )
  } else if (isOwner) {
    body = (
      <div className="text-center">
        <p className="text-[13px] leading-relaxed text-slate-300">{tr('هذا رابط مكتبك — أرسله لوكلائك.')}</p>
        <a href="#/" className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-br from-[#fbe3a1] via-[#f0b847] to-[#c98a22] py-3.5 text-[15px] font-extrabold text-[#1a1206]">
          <Building2 size={17} /> {tr('ادخل إلى مكتبك')}
        </a>
      </div>
    )
  } else if (myReq) {
    const st = myReq.status
    body = (
      <div className="text-center">
        {st === 'approved' ? (
          <>
            <CheckCircle2 className="mx-auto text-emerald-300" size={32} />
            <p className="font-display mt-3 text-[18px] font-black text-white">{tr('تمت الموافقة على انضمامك')}</p>
            <a href="#/" className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600 py-3.5 text-[15px] font-extrabold text-emerald-950">
              <LogIn size={17} /> {tr('ادخل إلى مساحتك')}
            </a>
          </>
        ) : st === 'pending' ? (
          <>
            <Clock className="mx-auto text-amber-300" size={32} />
            <p className="font-display mt-3 text-[18px] font-black text-white">{tr('طلبك بانتظار موافقة صاحب المكتب')}</p>
            <p className="mt-1 text-[12.5px] text-slate-400">{tr('ستتحوّل هذه الصفحة تلقائياً عند الموافقة.')}</p>
          </>
        ) : (
          <>
            <XCircle className="mx-auto text-rose-300" size={32} />
            <p className="font-display mt-3 text-[18px] font-black text-white">{tr('لا يمكنك الانضمام حالياً')}</p>
            <p className="mt-1 text-[12.5px] text-slate-400">{tr('تواصل مع صاحب المكتب.')}</p>
          </>
        )}
      </div>
    )
  } else if (closed) {
    body = (
      <p className="rounded-xl border border-rose-400/30 bg-rose-500/10 px-3.5 py-3 text-center text-[13px] font-bold text-rose-100">
        {tr('اشتراك هذا المكتب متوقف حالياً.')}
      </p>
    )
  } else {
    body = (
      <form onSubmit={submit} className="space-y-3.5">
        <label className="block">
          <span className="mb-1.5 block text-[12px] font-bold text-slate-300">{tr('اسمك الكامل')} *</span>
          <input value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} className={INPUT} required />
        </label>
        <label className="block">
          <span className="mb-1.5 block text-[12px] font-bold text-slate-300">{tr('رقم الهاتف')} *</span>
          <input value={form.phone} onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))} dir="ltr" inputMode="tel" className={`${INPUT} text-start`} required />
        </label>
        <button
          type="submit"
          disabled={busy}
          className="flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-br from-[#fbe3a1] via-[#f0b847] to-[#c98a22] py-3.5 text-[15px] font-extrabold text-[#1a1206] disabled:opacity-60"
        >
          {busy ? <span className="h-4 w-4 animate-spin rounded-full border-2 border-[#1a1206]/40 border-t-[#1a1206]" /> : <Send size={17} />}
          {tr('إرسال طلب الانضمام')}
        </button>
        <p className="text-center text-[11px] text-slate-500">{tr('مسجّل باسم {email}', { email: user.email || user.displayName || '—' })}</p>
      </form>
    )
  }

  return (
    <ModeScope mode={mode}>
      <div className="lux-gate skin-dark relative h-full overflow-y-auto bg-[#050a16]" data-dir={rtl ? 'rtl' : 'ltr'} data-mode={mode}>
        <div aria-hidden="true" className="pointer-events-none fixed inset-0 overflow-hidden">
          <div className="lux-orb absolute -top-40 start-[-10%] h-[480px] w-[480px] rounded-full bg-emerald-500/15 blur-[120px]" />
          <div className="lux-orb lux-orb-2 absolute bottom-[-160px] end-[-8%] h-[520px] w-[520px] rounded-full bg-amber-400/12 blur-[130px]" />
          <div className="lux-grid absolute inset-0" />
        </div>

        <div className="relative z-10 mx-auto w-full max-w-lg px-5 pb-[calc(env(safe-area-inset-bottom,0px)+32px)] pt-[calc(env(safe-area-inset-top,0px)+16px)]">
          <header className="rise flex items-center justify-between gap-3">
            <a href="#/" className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-3 py-2 text-[12px] font-bold text-slate-300 hover:text-white">
              <Back size={15} />
              {tr('الدخول')}
            </a>
            <div className="flex items-center gap-1.5">
              <ThemeToggle mode={mode} onToggle={toggle} />
              <LangSwitcher compact />
            </div>
          </header>

          <section className="mt-8 flex flex-col items-center text-center">
            <Logo className="rise h-20 w-20" />
            <span className="rise mt-5 inline-flex items-center gap-1.5 rounded-full border border-amber-300/30 bg-amber-400/10 px-3 py-1 text-[11px] font-extrabold tracking-wider text-amber-200">
              <Building2 size={13} /> {tr('دعوة انضمام')}
            </span>
            <h1 className="rise mt-4 pt-2 font-display text-[28px] font-black leading-[1.35] text-white">
              {office?.officeName ? <span className="lux-gold-text">{office.officeName}</span> : tr('انضم إلى مكتب')}
            </h1>
            <p className="rise mt-2 max-w-sm text-[13.5px] leading-relaxed text-slate-400">
              {tr('انضم كوكيل لتسجّل حوالاتك وتتابع رصيدك، ويراها صاحب المكتب مباشرة.')}
            </p>
          </section>

          <div className="relative mt-8">
            <div className="absolute -inset-px rounded-[1.6rem] bg-gradient-to-b from-amber-300/40 via-white/5 to-emerald-400/30" />
            <div className="relative rounded-[1.55rem] bg-gradient-to-b from-[#101a30]/95 to-[#080e1c]/95 p-5 md:p-6">{body}</div>
          </div>

          <p className="mt-4 flex items-center justify-center gap-1.5 text-[11.5px] text-slate-500">
            <ShieldCheck size={13} className="text-emerald-400" />
            {tr('لا تظهر حركاتك إلا لك ولصاحب المكتب.')}
          </p>
        </div>
      </div>
    </ModeScope>
  )
}
