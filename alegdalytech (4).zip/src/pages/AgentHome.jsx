import { useMemo } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Send, HandCoins, ArrowLeft, Wallet, CalendarDays, Banknote, ReceiptText } from 'lucide-react'
import { useLiveShared } from '../lib/useLive'
import { useSession } from '../components/Session'
import { useAgentStats } from '../hooks/useAgentStats'
import { ACard, AStat } from '../components/agent-ui'
import { fmt, dateLabel, todayKey, moveView, signed } from '../components/fees'
import { AppTag, AppSummaryCard, useAppTotals } from '../components/brands'
import { tr } from '../components/i18n'
import { scopeFilter } from '../components/scope'

export default function AgentHome() {
  const session = useSession()
  const { user, roster } = session
  const me = roster[0] || null
  const agentId = user?.id || null

  const { data: live, loading } = useLiveShared(session.txColl, {
    order: '-createdAt',
    limit: 60,
    filters: scopeFilter(session, agentId || '__none__'),
  })
  const version = useMemo(() => (live || []).map((r) => `${r.id}:${r.updatedAt || ''}`).join('|'), [live])
  const stats = useAgentStats(agentId, version)
  const appTotals = useAppTotals(agentId, version)
  const navigate = useNavigate()

  const today = todayKey()
  const todayRows = (live || []).filter((r) => r.day === today)
  const todayTx = todayRows.filter((r) => r.kind === 'tx')
  const todayCash = todayTx.reduce((s, r) => s + (Number(r.cashInHand) || 0), 0)
  const todayHanded = todayRows
    .filter((r) => r.kind === 'cash')
    .reduce((s, r) => s + (Number(r.amount) || 0), 0)

  const recent = (live || []).slice(0, 5)
  const hour = new Date().getHours()
  const greet = tr(hour < 12 ? 'صباح الخير' : hour < 17 ? 'مرحباً' : 'مساء الخير')

  return (
    <div className="space-y-4">
      <div className="rise">
        <p className="text-[12px] font-extrabold text-[#8b9a93]">{greet}</p>
        <h1 className="font-display text-[22px] font-black tracking-tight text-[#0b1a17]">{me?.name || tr('وكيل')}</h1>
      </div>

      {/* الرصيد */}
      <div className="rise relative overflow-hidden rounded-[28px] bg-gradient-to-bl from-[#0f766e] via-[#0d6a63] to-[#0a4f4a] p-5 shadow-[0_24px_50px_-30px_rgba(10,79,74,0.9)] md:p-7">
        <div className="pointer-events-none absolute -left-10 -top-16 h-44 w-44 rounded-full bg-white/10 blur-2xl" />
        <div className="relative">
          <div className="flex items-center gap-2 text-[11.5px] font-extrabold text-white/80">
            <Wallet size={14} />
            {tr('الكاش الموجود في يدك')}
          </div>
          <p className="font-display mt-2 text-[40px] font-black leading-none tracking-tight text-white md:text-[48px]">
            {stats ? fmt(stats.balance) : '—'}
            <span className="ms-2 align-middle text-[13px] font-extrabold text-white/60">FCFA</span>
          </p>
          <p className="mt-2 text-[11.5px] leading-relaxed text-white/60">
            {tr('مجموع الحوالات والعمولات التي استلمتها نقداً، بعد خصم ما سلّمته للمكتب')}
          </p>

          <div className="mt-4 grid grid-cols-2 gap-2">
            <div className="rounded-2xl bg-white/10 px-3 py-2.5 backdrop-blur">
              <p className="text-[10px] font-extrabold text-white/60">{tr('حوالات اليوم')}</p>
              <p className="font-display mt-0.5 text-[16px] font-black text-white">{fmt(todayTx.length)}</p>
            </div>
            <div className="rounded-2xl bg-white/10 px-3 py-2.5 backdrop-blur">
              <p className="text-[10px] font-extrabold text-white/60">{tr('كاش اليوم')}</p>
              <p className="font-display mt-0.5 text-[16px] font-black text-white">{fmt(todayCash)}</p>
            </div>
          </div>
        </div>
      </div>

      {/* NITA / AMANA */}
      <div className="rise grid grid-cols-2 gap-3">
        <AppSummaryCard app="NITA" t={appTotals.NITA} theme="light" onClick={() => navigate('/history?app=NITA')} />
        <AppSummaryCard app="AMANA" t={appTotals.AMANA} theme="light" onClick={() => navigate('/history?app=AMANA')} />
      </div>

      {/* اختصارات */}
      <div className="rise grid grid-cols-2 gap-3">
        <Link
          to="/new"
          className="flex flex-col items-start gap-2 rounded-[24px] border border-[#e6ece7] bg-white p-4 shadow-[0_10px_30px_-26px_rgba(6,40,32,0.6)] transition hover:border-[#0f766e]/40"
        >
          <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#0f766e]/10 text-[#0f766e]">
            <Send size={19} />
          </span>
          <span className="font-display text-[14px] font-extrabold text-[#0b1a17]">{tr('تسجيل حوالة')}</span>
          <span className="text-[11px] text-[#8b9a93]">{tr('سجّل حوالة زبون جديد')}</span>
        </Link>
        <Link
          to="/cash"
          className="flex flex-col items-start gap-2 rounded-[24px] border border-[#e6ece7] bg-white p-4 shadow-[0_10px_30px_-26px_rgba(6,40,32,0.6)] transition hover:border-[#f59e0b]/50"
        >
          <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#f59e0b]/15 text-[#b45309]">
            <HandCoins size={19} />
          </span>
          <span className="font-display text-[14px] font-extrabold text-[#0b1a17]">{tr('تسليم كاش')}</span>
          <span className="text-[11px] text-[#8b9a93]">{tr('سلّم النقد للمكتب')}</span>
        </Link>
      </div>

      {/* إحصاءات */}
      <div className="rise grid grid-cols-3 gap-2">
        <AStat label={tr('إجمالي الحوالات')} value={fmt(stats?.cashIn || 0)} sub="FCFA" />
        <AStat label={tr('كاش مسلَّم')} value={fmt(stats?.handed || 0)} tone="text-[#b45309]" sub="FCFA" />
        <AStat label={tr('حركات مسجلة')} value={fmt(stats?.count || 0)} />
      </div>

      {todayHanded > 0 ? (
        <div className="rise flex items-center gap-2.5 rounded-2xl border border-[#fde9c8] bg-[#fffaf0] px-4 py-3">
          <Banknote size={16} className="shrink-0 text-[#b45309]" />
          <p className="text-[12px] font-extrabold text-[#8a5a10]">
            {tr('سلّمت للمكتب اليوم')}: <span className="font-display">{fmt(todayHanded)}</span> FCFA
          </p>
        </div>
      ) : null}

      {me?.salary ? (
        <div className="rise flex items-center gap-2.5 rounded-2xl border border-[#e6ece7] bg-white px-4 py-3">
          <CalendarDays size={16} className="shrink-0 text-[#0f766e]" />
          <p className="text-[12px] font-extrabold text-[#42544c]">
            {tr('راتبك الشهري')}: <span className="font-display text-[#0b1a17]">{fmt(me.salary)}</span> FCFA
          </p>
        </div>
      ) : null}

      {/* آخر الحركات */}
      <ACard className="overflow-hidden">
        <div className="flex items-center justify-between border-b border-[#eef2ee] px-4 py-3">
          <div className="flex items-center gap-2">
            <ReceiptText size={15} className="text-[#0f766e]" />
            <span className="font-display text-[14px] font-extrabold text-[#0b1a17]">{tr('آخر حركاتي')}</span>
          </div>
          <Link to="/history" className="flex items-center gap-1 text-[11.5px] font-extrabold text-[#0f766e]">
            {tr('الكل')}
            <ArrowLeft size={12} className="ltr:rotate-180" />
          </Link>
        </div>
        {loading ? (
          <p className="py-8 text-center text-[12px] text-[#9aa8a1]">{tr('جارٍ التحميل...')}</p>
        ) : recent.length === 0 ? (
          <p className="py-8 text-center text-[12.5px] text-[#9aa8a1]">{tr('لم تسجّل أي حركة بعد')}</p>
        ) : (
          <ul className="divide-y divide-[#f1f5f2]">
            {recent.map((t) => {
              const mv = moveView(t)
              return (
                <li key={t.id} className="flex items-center justify-between gap-3 px-4 py-3">
                  <div className="min-w-0">
                    <p className="truncate text-[13px] font-extrabold text-[#0b1a17]">
                      <span className={`me-1.5 rounded-md px-1.5 py-0.5 text-[10px] ${mv.dir === 'in' ? 'bg-[#0369a1]/10 text-[#0369a1]' : mv.dir === 'out' ? 'bg-[#be123c]/10 text-[#be123c]' : 'bg-[#f59e0b]/15 text-[#b45309]'}`}>{mv.tag}</span>
                      <AppTag app={mv.app} theme="light" className="me-1.5" />
                      {mv.title}
                    </p>
                    <p className="mt-0.5 text-[10.5px] text-[#9aa8a1]">{dateLabel(t.date)}</p>
                  </div>
                  <p className={`font-display shrink-0 text-[13.5px] font-black ${mv.value >= 0 ? 'text-[#0f766e]' : 'text-[#be123c]'}`}>
                    {signed(mv.value)}
                  </p>
                </li>
              )
            })}
          </ul>
        )}
      </ACard>
      <div className="h-2" />
    </div>
  )
}
