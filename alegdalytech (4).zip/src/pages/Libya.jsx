import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react'
import { useLocation, useNavigate, useParams } from 'react-router-dom'
import {
  Landmark, Plus, ArrowDownLeft, ArrowUpRight, CheckCircle2, Clock, XCircle, Copy, MessageCircle,
  Scale, Building2, Trash2, KeyRound, TrendingUp, ListChecks, Link2, Inbox, Zap, ChevronDown,
  Handshake, Send, X, RotateCcw, ChevronLeft, BellRing, Search, FileText, Wallet, ShieldCheck, AlertTriangle, QrCode, UserPlus,
} from 'lucide-react'
import { QRCodeSVG } from 'qrcode.react'
import { APP_LINK } from '../components/AppQR'
import { db } from '../lib/db'
import { auth } from '../lib/auth'
import { push } from '../lib/push'
import { useLiveShared } from '../lib/useLive'
import { share } from '../lib/share'
import { useSession } from '../components/Session'
import { Card, Field, PrimaryBtn, GhostBtn, fieldCls, useToast, useConfirm, Segmented, EmptyState } from '../components/ui'
import MoneyInput from '../components/MoneyInput'
import { tr } from '../components/i18n'
import { getNotifyPrefs, useNotifyPrefs } from '../components/notifyPrefs'

// مجموعات مستقلة تماماً عن حوالات الفرنك — لا تُقرأ ولا تُكتب في أي مكان آخر
const TX = 'ly_transfers'
const OFF = 'ly_offices'
const SET = 'ly_settlements'
// ربط المكاتب داخل التطبيق: دليل الأكواد (عام: الاسم فقط) + الحوالات بين مكتبين شريكين + طلبات الشراكة
const NODES = 'ly_nodes'
const LINK = 'ly_links'
const PART = 'ly_partners'
// دفعات المقاصة بين مكتبين شريكين — يسجّلها طرف ويؤكدها الطرف الآخر (القواعد في rules.json على السيرفر)
const PSET = 'ly_psettle'
const codeOf = (uid) => String(uid || '').replace(/-/g, '').slice(0, 6).toUpperCase()
const isExpect = (e) => e?.code === 'EXPECT_FAILED' || String(e?.message || '').includes('EXPECT_FAILED')
const ageDays = (iso) => {
  const t = new Date(iso).getTime()
  return Number.isFinite(t) ? Math.floor((Date.now() - t) / 86400000) : 0
}

/** رسالة دعوة مكتب للتطبيق — تُرسل عبر واتساب */
function inviteText(myCode) {
  return [
    tr('السلام عليكم، أتعامل في الحوالات عبر تطبيق الأقدالي للتقنية ALEGDALY TECH.'),
    tr('الحوالة تصلك فوراً داخل التطبيق برقم سري، والمقاصة بيننا تُحسب تلقائياً ويرى الطرفان نفس الأرقام.'),
    `1) ${tr('سجّل مكتبك')}: ${APP_LINK}/#/offices`,
    `2) ${tr('أرسل لي طلب شراكة بكود مكتبي')}: ${myCode}`,
    `${tr('إذا كان مكتبك مسجّلاً، افتح هذا الرابط مباشرة')}: ${APP_LINK}/#/ly/offices?partner=${myCode}`,
  ].join('\n')
}
const rid = (p) => `${p}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`
const isAttempts = (e) => e?.code === 'SECRET_ATTEMPTS' || String(e?.message || '').includes('SECRET_ATTEMPTS')
const normCode = (raw) => String(raw || '').replace(/[^0-9a-z]/gi, '').toUpperCase()
const normName = (s) => String(s || '').trim().toLowerCase()

const fmt = (n) => Math.round(Number(n) || 0).toLocaleString('en-US')
const cur = () => tr('د.ل')

function newCode() {
  // مولّد عشوائي آمن فقط — لا رجوع إلى Math.random
  const a = new Uint32Array(1)
  const limit = Math.floor(0x100000000 / 900000) * 900000
  do { crypto.getRandomValues(a) } while (a[0] >= limit)
  return String(100000 + (a[0] % 900000))
}

/** رقم ليبي بالصيغة الدولية لواتساب */
function lyPhone(p) {
  let d = String(p || '').replace(/[^\d]/g, '')
  if (!d) return ''
  if (d.startsWith('00')) d = d.slice(2)
  if (d.startsWith('218')) return d
  if (d.startsWith('0')) d = d.slice(1)
  return d.length === 9 ? `218${d}` : d
}

function dayStartISO(offsetDays = 0) {
  const d = new Date()
  d.setHours(0, 0, 0, 0)
  d.setDate(d.getDate() - offsetDays)
  return d.toISOString()
}
function monthStartISO() {
  const d = new Date()
  return new Date(d.getFullYear(), d.getMonth(), 1).toISOString()
}

function useLy() {
  const s = useSession()
  const ws = s.isOffice ? s.officeId || '__none__' : 'main'
  const writeOpts = { groupId: s.gid, visibleTo: 'creator-and-admin', writableBy: 'admins' }
  const userId = s.user?.id || null
  const myCode = String(userId || '').replace(/-/g, '').slice(0, 6).toUpperCase()
  const baseName = s.isOffice ? s.officeName || tr('مكتب') : 'ALEGDALY TECH'
  // الاسم الذي اختاره صاحب المكتب بنفسه (إن وُجد) — يظهر للمكاتب الشريكة في الحوالات والطلبات
  const ctx = useContext(LyCtx)
  const myName = ctx?.myName || baseName
  return { ws, gid: s.gid, writeOpts, userId, myCode, myName, baseName }
}

const when = (iso) => { try { return new Date(iso).toLocaleString('en-GB', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) } catch { return '' } }

function receiptText(t) {
  const lines = [
    tr('إيصال حوالة'),
    `${tr('المستلم')}: ${t.recvName}`,
    `${tr('المبلغ المستلم')}: ${fmt(t.deliver)} ${cur()}`,
    `${tr('مكتب التسليم')}: ${t.officeName}${t.officeCity ? ` - ${t.officeCity}` : ''}`,
    `${tr('الرقم السري')}: ${t.code}`,
    tr('لا تعطِ الرقم السري إلا لمكتب التسليم.'),
    '—',
    `${tr('حوالة مسجّلة عبر تطبيق الأقدالي للتقنية')}: ${APP_LINK}`,
  ]
  return lines.join('\n')
}

/** رسالة جاهزة لصاحب مكتب التسليم — بدل كتابة الحوالة مرتين (في التطبيق وفي واتساب) */
function officeNoticeText(t, fromName, myCode) {
  const lines = [
    `${tr('حوالة جديدة من')} ${fromName}`,
    `${tr('المستلم')}: ${t.recvName}${t.recvPhone ? ` - ${t.recvPhone}` : ''}`,
    `${tr('المبلغ المطلوب تسليمه')}: ${fmt(t.deliver)} ${cur()}`,
  ]
  if (t.senderName) lines.push(`${tr('المرسل')}: ${t.senderName}${t.senderPhone ? ` - ${t.senderPhone}` : ''}`)
  if (t.linkId) {
    // المكتب الشريك يتحقق من الرقم السري داخل التطبيق — لا نرسله في واتساب
    lines.push(tr('الحوالة موجودة عندك في التطبيق (الواردة). سلّم فقط بعد التحقق من الرقم السري داخل التطبيق.'))
  } else {
    lines.push(`${tr('الرقم السري')}: ${t.code}`)
    lines.push(tr('لا تسلّم إلا لمن يذكر الرقم السري صحيحاً.'))
  }
  lines.push(`${tr('التاريخ')}: ${when(t.date)}`)
  if (!t.linkId && myCode) {
    // دعوة المكتب للتطبيق: تصله الحوالات القادمة مباشرة وتُحسب المقاصة تلقائياً
    lines.push('—')
    lines.push(`${tr('استلم حوالاتي القادمة مباشرة في التطبيق: سجّل مكتبك هنا')} ${APP_LINK}/#/offices ${tr('ثم أرسل لي طلب شراكة بالكود')} ${myCode}`)
  }
  return lines.join('\n')
}

/** إشعار فوري لهاتف المكتب الآخر (يصل حتى والتطبيق مغلق إذا فعّل الإشعارات) — لا يوقف العملية إذا فشل */
// kind: 'ops' = حوالات وشراكات، 'sec' = تنبيهات أمنية — يُحترم اختيار المستلم (تشغيل/إيقاف)
function notify(userId, title, body, url, kind = 'ops') {
  if (!userId) return
  getNotifyPrefs(userId)
    .then((p) => (p[kind] === false ? null : push.send(userId, { title, body, url })))
    .catch(() => null)
}

/** يضيف المكتب الشريك إلى دليل هذا المكتب (أو يربط مدخلاً موجوداً) — بدون تكرار */
async function linkOffice(ws, offices, peer, writeOpts, preferId) {
  const fields = { linkedCode: peer.code || '', linkedUserId: peer.userId, linkedWs: peer.ws || '' }
  const already = (offices || []).find((o) => o.linkedUserId && o.linkedUserId === peer.userId)
  if (already) {
    // مكتب أخفاه المستخدم ثم عاد التعامل معه → يظهر من جديد
    if (already.hidden) await db.updateShared(OFF, already.id, { hidden: false })
    return { ...already, hidden: false }
  }
  const target =
    (preferId && (offices || []).find((o) => o.id === preferId && !o.linkedUserId)) ||
    (offices || []).find((o) => !o.linkedUserId && normName(o.name) && normName(o.name) === normName(peer.name)) ||
    null
  if (target) {
    await db.updateShared(OFF, target.id, fields)
    return { ...target, ...fields }
  }
  const id = `${ws}_${peer.code || rid('o')}`
  await db.upsertShared(OFF, { ws, name: peer.name || tr('مكتب'), city: '', phone: '', ...fields }, id, writeOpts)
  return { id, ws, name: peer.name, city: '', ...fields }
}

/* ───────────────────────── بيانات القسم (تُحمَّل فقط داخل قسم ليبيا) ───────────────────────── */
const LyCtx = createContext(null)
export const useLyData = () => useContext(LyCtx)

export function LyProvider({ children }) {
  const { ws, gid, userId, myCode, baseName, writeOpts } = useLy()
  const me = userId || '__none__'
  // الحوالات المعلّقة كلها (حتى لا تضيع حوالة قديمة لم تُسلَّم) + آخر 300 حوالة منتهية
  const { data: txPend, loading, refetch: refetchPend } = useLiveShared(TX, { filters: { ws, status: 'pending' }, order: '-createdAt' })
  const { data: txDone, refetch: refetchDone } = useLiveShared(TX, { filters: { ws, status: { in: ['delivered', 'cancelled'] } }, order: '-createdAt', limit: 300 })
  const txs = useMemo(() => {
    const m = new Map()
    for (const r of [...(txPend || []), ...(txDone || [])]) m.set(r.id, r)
    return [...m.values()].sort((a, b) => String(b.createdAt || b.date || '').localeCompare(String(a.createdAt || a.date || '')))
  }, [txPend, txDone])
  const refetchTx = useCallback(() => { refetchPend(); refetchDone() }, [refetchPend, refetchDone])
  const { data: offs, loading: offLoading } = useLiveShared(OFF, { filters: { ws }, order: 'name' })
  const { data: sets } = useLiveShared(SET, { filters: { ws }, order: '-createdAt', limit: 50 })
  const { data: outLinksLive, refetch: refetchOut } = useLiveShared(LINK, { filters: { fromWs: ws }, order: '-createdAt', limit: 300 })
  const { data: inLinksLive, loading: inLoading, refetch: refetchIn } = useLiveShared(LINK, { filters: { toUserId: me }, order: '-createdAt', limit: 300 })

  // ما يكتبه هذا الجهاز يظهر فوراً على الشاشة، بدون انتظار وصول التحديث من السيرفر
  // (إذا انقطع الاتصال اللحظي لحظةً كانت الحوالة تتأخر في الظهور). يُمسح تلقائياً عندما تصل النسخة الحقيقية.
  const [localAdds, setLocalAdds] = useState({})
  const [txPatches, setTxPatches] = useState({})
  const [linkPatches, setLinkPatches] = useState({})
  // حوالات حذفها المستخدم من هذا الجهاز — تختفي فوراً بدون انتظار السيرفر
  const [removed, setRemoved] = useState({})
  const matches = (row, patch) => row && Object.keys(patch).every((k) => row[k] === patch[k])
  const allTx = useMemo(() => {
    const live = txs || []
    const ids = new Set(live.map((r) => r.id))
    const extra = Object.values(localAdds).filter((r) => !ids.has(r.id))
    return [...extra, ...live].map((r) => (txPatches[r.id] ? { ...r, ...txPatches[r.id] } : r))
  }, [txs, localAdds, txPatches])
  // المؤرشفة تختفي من القائمة فقط — تبقى محسوبة في المقاصة والأرباح
  const txsMerged = useMemo(() => allTx.filter((r) => !removed[r.id] && !r.archived), [allTx, removed])
  const applyLinkPatches = (list) => (list || []).map((l) => (linkPatches[l.id] ? { ...l, ...linkPatches[l.id] } : l))
  const outLinks = useMemo(() => applyLinkPatches(outLinksLive), [outLinksLive, linkPatches])
  const inLinks = useMemo(() => applyLinkPatches(inLinksLive), [inLinksLive, linkPatches])

  // تنظيف: ما وصل من السيرفر لا يحتاج النسخة المحلية
  useEffect(() => {
    const live = txs || []
    const byId = Object.fromEntries(live.map((r) => [r.id, r]))
    setLocalAdds((m) => {
      const keys = Object.keys(m).filter((id) => byId[id])
      if (!keys.length) return m
      const n = { ...m }
      keys.forEach((k) => delete n[k])
      return n
    })
    setTxPatches((m) => {
      const keys = Object.keys(m).filter((id) => matches(byId[id], m[id]))
      if (!keys.length) return m
      const n = { ...m }
      keys.forEach((k) => delete n[k])
      return n
    })
  }, [txs])
  useEffect(() => {
    const byId = Object.fromEntries([...(outLinksLive || []), ...(inLinksLive || [])].map((l) => [l.id, l]))
    setLinkPatches((m) => {
      const keys = Object.keys(m).filter((id) => matches(byId[id], m[id]))
      if (!keys.length) return m
      const n = { ...m }
      keys.forEach((k) => delete n[k])
      return n
    })
  }, [outLinksLive, inLinksLive])

  const addTx = useCallback((row) => {
    setLocalAdds((m) => ({ ...m, [row.id]: { createdAt: new Date().toISOString(), ...row } }))
    refetchTx()
  }, [refetchTx])
  const patchTx = useCallback((id, fields) => {
    setTxPatches((m) => ({ ...m, [id]: { ...(m[id] || {}), ...fields } }))
    refetchTx()
  }, [refetchTx])
  const removeTx = useCallback((ids) => {
    setRemoved((m) => {
      const n = { ...m }
      ids.forEach((id) => { n[id] = true })
      return n
    })
    setLocalAdds((m) => {
      if (!ids.some((id) => m[id])) return m
      const n = { ...m }
      ids.forEach((id) => delete n[id])
      return n
    })
    refetchTx()
  }, [refetchTx])
  const patchLink = useCallback((id, fields) => {
    setLinkPatches((m) => ({ ...m, [id]: { ...(m[id] || {}), ...fields } }))
    refetchOut()
    refetchIn()
  }, [refetchOut, refetchIn])
  // قراءة جديدة للحوالات عند التنقل بين صفحات القسم — احتياط إذا انقطع الاتصال اللحظي
  const refreshAll = useCallback(() => {
    refetchTx()
    refetchOut()
    refetchIn()
  }, [refetchTx, refetchOut, refetchIn])
  const { data: reqInRaw } = useLiveShared(PART, { filters: { toUserId: me }, order: '-createdAt', limit: 100 })
  const { data: reqOutRaw } = useLiveShared(PART, { filters: { fromUserId: me }, order: '-createdAt', limit: 100 })
  const { data: psOutRaw } = useLiveShared(PSET, { filters: { fromUserId: me }, order: '-createdAt', limit: 300 })
  const { data: psInRaw } = useLiveShared(PSET, { filters: { toUserId: me }, order: '-createdAt', limit: 300 })

  const rows = txsMerged
  // المكاتب المحذوفة من الدليل تبقى مخفية (لا تُحذف) حتى لا يعيدها الربط التلقائي ولا يضيع اسمها في المقاصة
  const allOffices = offs || []
  const offices = allOffices.filter((o) => !o.hidden)
  const incoming = (inLinks || []).filter((l) => l.toUserId === userId)
  const reqIn = (reqInRaw || []).filter((r) => r.toUserId === userId)
  const reqOut = (reqOutRaw || []).filter((r) => r.fromUserId === userId)
  const linkMap = useMemo(() => {
    const m = {}
    for (const l of outLinks || []) m[l.id] = l
    return m
  }, [outLinks])

  // اسم مكتبي: محفوظ في سجل كودي بالدليل — لا يعدّله إلا صاحبه (السجل ملك من أنشأه)
  const { data: myNodeRows, refetch: refetchNode } = useLiveShared(NODES, { filters: { userId: me }, limit: 5 })
  const myNode = (myNodeRows || []).find((n) => n.id === myCode && n.userId === userId) || null
  const customName = String(myNode?.customName || '').trim()
  const myName = customName || baseName
  const renameMe = useCallback(async (raw) => {
    const v = String(raw || '').trim().slice(0, 60)
    if (!userId || !myCode) throw new Error(tr('تعذّر تجهيز الجلسة، أعد المحاولة'))
    const n = await db.getShared(NODES, myCode)
    if (n && n.userId !== userId) throw new Error(tr('تعذّر تسجيل العملية'))
    if (!n) await db.upsertShared(NODES, { userId, ws, name: v || baseName, customName: v }, myCode)
    else await db.updateShared(NODES, myCode, { customName: v, name: v || baseName })
    refetchNode()
  }, [userId, myCode, ws, baseName, refetchNode])

  // تسجيل كود هذا المكتب في الدليل (الاسم فقط) حتى تستطيع المكاتب الأخرى إرسال طلب شراكة
  useEffect(() => {
    if (!userId || !gid || !myCode) return
    let off = false
    db.getShared(NODES, myCode)
      .then((n) => {
        if (off) return null
        if (!n) return db.upsertShared(NODES, { userId, ws, name: baseName }, myCode)
        if (n.userId !== userId) return null
        const want = String(n.customName || '').trim() || baseName
        if (n.name !== want || n.ws !== ws) return db.updateShared(NODES, myCode, { name: want, ws })
        return null
      })
      .catch(() => null)
    return () => { off = true }
  }, [userId, gid, myCode, baseName, ws])

  // عندما يؤكد المكتب الشريك التسليم، تتحدّث حوالتك عندك (للأرباح والمقاصة)
  const synced = useRef(new Set())
  useEffect(() => {
    for (const t of allTx) {
      if (!t.linkId || t.status !== 'pending' || synced.current.has(t.id)) continue
      const l = linkMap[t.linkId]
      if (l?.status === 'delivered') {
        synced.current.add(t.id)
        db.updateShared(TX, t.id, { status: 'delivered', deliveredAt: l.deliveredAt || new Date().toISOString() }, { expect: { status: 'pending' } }).catch(() => synced.current.delete(t.id))
      }
    }
  }, [allTx, linkMap])

  // عندما يقبل المكتب الآخر طلب الشراكة، يُربط عندك تلقائياً في دليل المكاتب
  const partSynced = useRef(new Set())
  useEffect(() => {
    if (offLoading || !gid) return
    for (const r of reqOut) {
      if (r.status !== 'accepted' || partSynced.current.has(r.id)) continue
      partSynced.current.add(r.id)
      if (allOffices.some((o) => o.linkedUserId === r.toUserId)) continue
      linkOffice(ws, allOffices, { code: r.toCode, userId: r.toUserId, ws: r.toWs, name: r.toName }, writeOpts, r.fromOfficeId)
        .catch(() => partSynced.current.delete(r.id))
    }
  }, [reqOut, allOffices, offLoading, gid, ws, writeOpts])

  const version = useMemo(() => allTx.map((r) => `${r.id}:${r.status}`).join('|'), [allTx])
  const setsVersion = useMemo(() => (sets || []).map((r) => r.id).join('|'), [sets])
  const linkVersion = useMemo(() => [...(outLinks || []), ...(inLinks || [])].map((l) => `${l.id}:${l.status}`).join('|'), [outLinks, inLinks])
  const psOut = useMemo(() => (psOutRaw || []).filter((s) => s.fromUserId === userId), [psOutRaw, userId])
  const psIn = useMemo(() => (psInRaw || []).filter((s) => s.toUserId === userId), [psInRaw, userId])
  const psVersion = useMemo(() => [...psOut, ...psIn].map((s) => `${s.id}:${s.status}`).join('|'), [psOut, psIn])

  const value = {
    rows,
    loading,
    offices,
    allOffices,
    offLoading,
    linkMap,
    incoming,
    inLoading,
    inPending: incoming.filter((l) => l.status === 'pending').length,
    reqIn,
    reqOut,
    reqPending: reqIn.filter((r) => r.status === 'pending').length,
    myName,
    customName,
    renameMe,
    psOut,
    psIn,
    psPending: psIn.filter((s) => s.status === 'pending').length,
    psVersion,
    linkVersion,
    version,
    setsVersion,
    addTx,
    patchTx,
    removeTx,
    patchLink,
    refreshAll,
  }
  return <LyCtx.Provider value={value}>{children}</LyCtx.Provider>
}

/* ───────────────────────── الشراكة بين المكاتب ───────────────────────── */
function usePartner() {
  const ly = useLy()
  const d = useLyData()

  async function accept(r) {
    await db.updateShared(PART, r.id, { status: 'accepted', respondedAt: new Date().toISOString() })
    await linkOffice(ly.ws, d.allOffices, { code: r.fromCode, userId: r.fromUserId, ws: r.fromWs, name: r.fromName }, ly.writeOpts)
    notify(r.fromUserId, '🤝 تم قبول طلب الشراكة', `${ly.myName} قبل طلبك. تقدر ترسل له حوالات الآن.`, '#/ly/offices')
  }
  async function reject(r) {
    await db.updateShared(PART, r.id, { status: 'rejected', respondedAt: new Date().toISOString() })
    notify(r.fromUserId, 'طلب الشراكة مرفوض', `${ly.myName} رفض طلب الشراكة.`, '#/ly/offices')
  }
  async function send(raw, fromOfficeId) {
    const code = normCode(raw)
    if (!code) throw new Error(tr('اكتب كود المكتب'))
    if (code === ly.myCode) throw new Error(tr('هذا كود مكتبك أنت'))
    if (!ly.gid || !ly.userId) throw new Error(tr('تعذّر تجهيز الجلسة، أعد المحاولة'))
    const node = await db.getShared(NODES, code).catch(() => null)
    if (!node?.userId) throw new Error(tr('لم يُعثر على مكتب بهذا الكود. تأكد أن المكتب فتح قسم ليبيا مرة واحدة على الأقل.'))
    if (node.userId === ly.userId) throw new Error(tr('هذا كود مكتبك أنت'))
    const hid = d.allOffices.find((o) => o.linkedUserId === node.userId && o.hidden)
    if (hid) {
      await db.updateShared(OFF, hid.id, { hidden: false })
      return { accepted: true, name: hid.name }
    }
    if (d.offices.some((o) => o.linkedUserId === node.userId)) throw new Error(tr('هذا المكتب شريك لك من قبل'))
    // إذا كان هو أرسل لك طلباً من قبل → قبوله مباشرة
    const rev = d.reqIn.find((r) => r.fromUserId === node.userId && r.status === 'pending')
    if (rev) {
      await accept(rev)
      return { accepted: true, name: node.name || rev.fromName }
    }
    await db.upsertShared(
      PART,
      {
        fromCode: ly.myCode, fromUserId: ly.userId, fromWs: ly.ws, fromName: ly.myName, fromOfficeId: fromOfficeId || '',
        toCode: code, toUserId: node.userId, toWs: node.ws || '', toName: node.name || '',
        status: 'pending', date: new Date().toISOString(), respondedAt: '',
      },
      `${ly.myCode}_${code}`,
      { groupId: ly.gid, visibleTo: `user:${node.userId}`, writableBy: `user:${node.userId}`, writableFields: ['status', 'respondedAt'] },
    )
    notify(node.userId, '🤝 طلب شراكة جديد', `${ly.myName} (${ly.myCode}) يطلب الشراكة معك. افتح التطبيق للقبول أو الرفض.`, '#/ly/offices')
    return { sent: true, name: node.name || code }
  }
  async function resend(r) {
    await db.updateShared(PART, r.id, { status: 'pending', date: new Date().toISOString(), respondedAt: '' })
    notify(r.toUserId, '🤝 طلب شراكة جديد', `${ly.myName} (${ly.myCode}) يطلب الشراكة معك من جديد.`, '#/ly/offices')
  }
  async function withdraw(r) {
    await db.deleteShared(PART, r.id)
  }
  return { accept, reject, send, resend, withdraw }
}

function PartnerForm({ onClose, fromOfficeId, compact = false, initialCode = '' }) {
  const toast = useToast()
  const { send } = usePartner()
  const [code, setCode] = useState(initialCode)
  const [busy, setBusy] = useState(false)
  async function go() {
    setBusy(true)
    try {
      const r = await send(code, fromOfficeId)
      toast(r.accepted ? tr('أصبح {name} شريكاً لك', { name: r.name }) : tr('تم إرسال طلب الشراكة إلى {name}', { name: r.name }))
      setCode('')
      onClose?.()
    } catch (e) {
      toast(e?.message || tr('تعذّر تسجيل العملية'), 'err')
    } finally {
      setBusy(false)
    }
  }
  return (
    <div className={compact ? 'w-full space-y-2 pt-2' : 'space-y-3'}>
      {!compact ? (
        <p className="text-[12px] leading-relaxed text-slate-400">
          {tr('اطلب من المكتب كوده في التطبيق واكتبه هنا. يصله الطلب، وعندما يقبله تصبحان شريكين وتظهر حوالاتك عنده مباشرة.')}
        </p>
      ) : null}
      <div className="flex items-end gap-2">
        <label className="flex-1">
          <span className="mb-1 block text-[11px] font-bold text-slate-400">{tr('كود المكتب في التطبيق')}</span>
          <input value={code} onChange={(e) => setCode(normCode(e.target.value).slice(0, 8))} dir="ltr" className={`${fieldCls} tracking-[0.25em]`} placeholder="A1B2C3" />
        </label>
        <button type="button" disabled={busy || !code} onClick={go} className="inline-flex min-h-[50px] items-center gap-1.5 rounded-xl bg-sky-500 px-4 text-[13px] font-extrabold text-sky-950 transition hover:bg-sky-400 disabled:opacity-50">
          <Send size={15} />{busy ? tr('جارٍ...') : tr('إرسال')}
        </button>
        {compact ? (
          <button type="button" onClick={onClose} aria-label="close" className="flex h-[50px] w-11 items-center justify-center rounded-xl border border-white/10 text-slate-400 hover:bg-white/[0.05]"><X size={16} /></button>
        ) : null}
      </div>
    </div>
  )
}

function PartnerRequests() {
  const d = useLyData()
  const toast = useToast()
  const ask = useConfirm()
  const { accept, reject, resend, withdraw } = usePartner()
  const [busy, setBusy] = useState(null)
  const inc = d.reqIn.filter((r) => r.status === 'pending')
  const out = d.reqOut.filter((r) => r.status === 'pending' || r.status === 'rejected')
  if (!inc.length && !out.length) return null

  async function run(id, fn, okMsg) {
    setBusy(id)
    try {
      await fn()
      if (okMsg) toast(okMsg)
    } catch (e) {
      toast(e?.message || tr('تعذّر تسجيل العملية'), 'err')
    } finally {
      setBusy(null)
    }
  }

  return (
    <div className="space-y-3">
      {inc.length ? (
        <div className="space-y-2">
          <p className="flex items-center gap-1.5 text-[12px] font-extrabold text-amber-200"><Handshake size={15} />{tr('طلبات شراكة واردة')}</p>
          {inc.map((r) => (
            <Card key={r.id} className="rise border-amber-300/30 bg-amber-400/[0.06] p-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="font-display truncate text-[15px] font-extrabold text-white">{r.fromName || r.fromCode}</p>
                  <p className="text-[11.5px] text-slate-400">{tr('يطلب الشراكة معك')} · <span dir="ltr" className="tracking-widest">{r.fromCode}</span> · {when(r.date)}</p>
                </div>
                <div className="flex shrink-0 gap-2">
                  <button
                    type="button"
                    disabled={busy === r.id}
                    onClick={() => run(r.id, async () => {
                      if (!(await ask({ title: tr('رفض طلب الشراكة؟'), text: r.fromName, confirmLabel: tr('رفض'), icon: XCircle }))) throw Object.assign(new Error(''), { silent: true })
                      await reject(r)
                    }, tr('تم رفض الطلب')).catch(() => null)}
                    className="min-h-[42px] rounded-xl border border-white/12 bg-white/[0.04] px-3.5 text-[12.5px] font-extrabold text-slate-300 hover:bg-white/[0.08] disabled:opacity-50"
                  >
                    {tr('رفض')}
                  </button>
                  <button
                    type="button"
                    disabled={busy === r.id}
                    onClick={() => run(r.id, () => accept(r), tr('أصبح {name} شريكاً لك', { name: r.fromName || r.fromCode }))}
                    className="inline-flex min-h-[42px] items-center gap-1.5 rounded-xl bg-emerald-500 px-4 text-[12.5px] font-extrabold text-emerald-950 hover:bg-emerald-400 disabled:opacity-50"
                  >
                    <CheckCircle2 size={15} />{tr('قبول')}
                  </button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      ) : null}
      {out.length ? (
        <div className="space-y-2">
          <p className="flex items-center gap-1.5 text-[12px] font-extrabold text-slate-400"><Send size={13} />{tr('طلبات أرسلتها')}</p>
          {out.map((r) => (
            <Card key={r.id} className="flex flex-wrap items-center justify-between gap-3 p-3.5">
              <div className="min-w-0">
                <p className="font-display truncate text-[14px] font-extrabold text-white">{r.toName || r.toCode}</p>
                <span className={`mt-1 inline-flex items-center gap-1 rounded-full border px-2 py-[2px] text-[10.5px] font-extrabold ${r.status === 'rejected' ? 'border-rose-400/30 bg-rose-500/10 text-rose-200' : 'border-amber-400/30 bg-amber-500/10 text-amber-200'}`}>
                  {r.status === 'rejected' ? <XCircle size={11} /> : <Clock size={11} />}
                  {r.status === 'rejected' ? tr('رفض الطلب') : tr('بانتظار موافقته')}
                </span>
              </div>
              <div className="flex shrink-0 gap-2">
                {r.status === 'rejected' ? (
                  <button type="button" disabled={busy === r.id} onClick={() => run(r.id, () => resend(r), tr('تم إرسال الطلب من جديد'))} className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-sky-400/25 bg-sky-500/10 px-3 text-[12px] font-extrabold text-sky-200 hover:bg-sky-500/20 disabled:opacity-50">
                    <RotateCcw size={13} />{tr('إعادة الإرسال')}
                  </button>
                ) : null}
                <button
                  type="button"
                  disabled={busy === r.id}
                  onClick={async () => {
                    if (!(await ask({ title: tr('سحب طلب الشراكة؟'), text: r.toName || r.toCode, confirmLabel: tr('سحب الطلب') }))) return
                    run(r.id, () => withdraw(r), tr('تم سحب الطلب'))
                  }}
                  className="min-h-[40px] rounded-xl border border-white/12 bg-white/[0.04] px-3 text-[12px] font-extrabold text-slate-300 hover:bg-white/[0.08] disabled:opacity-50"
                >
                  {tr('سحب الطلب')}
                </button>
              </div>
            </Card>
          ))}
        </div>
      ) : null}
    </div>
  )
}

/* ───────────────────────── اسم مكتبي (يعدّله صاحب المكتب فقط) ───────────────────────── */
function OfficeNameCard() {
  const toast = useToast()
  const d = useLyData()
  const { baseName } = useLy()
  const s = useSession()
  // تعديل اسم المكتب لصاحبه فقط: مالك التطبيق في القسم الرئيسي، أو صاحب المكتب في مساحته — لا الموظفين ولا الوكلاء
  const isOwner = s.mode === 'office' ? !!s.canManage : s.mode === 'main' ? auth.isAppOwner() : false
  const [edit, setEdit] = useState(false)
  const [val, setVal] = useState('')
  const [busy, setBusy] = useState(false)
  async function save(next) {
    setBusy(true)
    try {
      await d.renameMe(next)
      toast(tr('تم حفظ اسم المكتب'))
      setEdit(false)
    } catch (e) {
      toast(e?.message || tr('تعذّر تسجيل العملية'), 'err')
    } finally {
      setBusy(false)
    }
  }
  return (
    <Card className="p-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="min-w-0">
          <p className="text-[11px] font-bold text-slate-500">{tr('اسم مكتبك كما يظهر للمكاتب الشريكة')}</p>
          <p className="font-display truncate text-[17px] font-black text-white">{d.myName}</p>
        </div>
        {!edit && isOwner ? (
          <GhostBtn onClick={() => { setVal(d.customName || d.myName); setEdit(true) }}>{tr('تعديل الاسم')}</GhostBtn>
        ) : null}
      </div>
      {edit && isOwner ? (
        <div className="rise mt-3 space-y-2">
          <input value={val} onChange={(e) => setVal(e.target.value.slice(0, 60))} className={fieldCls} placeholder={baseName} />
          <div className="flex flex-wrap gap-2">
            <button type="button" disabled={busy || !val.trim()} onClick={() => save(val)} className="min-h-[44px] flex-1 rounded-xl bg-amber-400 px-4 text-[13px] font-extrabold text-[#1a1206] hover:bg-amber-300 disabled:opacity-50">
              {busy ? tr('جارٍ الحفظ...') : tr('حفظ')}
            </button>
            {d.customName ? (
              <GhostBtn onClick={() => save('')}>{tr('الاسم الأصلي')}</GhostBtn>
            ) : null}
            <GhostBtn onClick={() => setEdit(false)}>{tr('إلغاء')}</GhostBtn>
          </div>
          <p className="text-[11px] leading-relaxed text-slate-500">{tr('يظهر الاسم الجديد في الحوالات والطلبات والإشعارات القادمة. لا يستطيع أي مكتب آخر تغييره.')}</p>
        </div>
      ) : null}
    </Card>
  )
}

/* ───────────────────────── دعوة مكتب للتطبيق (لانتشار التطبيق) ───────────────────────── */
function InviteCard() {
  const toast = useToast()
  const { myCode } = useLy()
  const [qr, setQr] = useState(false)
  const link = `${APP_LINK}/#/offices`
  return (
    <Card className="relative overflow-hidden border-amber-300/25 bg-gradient-to-br from-amber-400/[0.08] to-transparent p-4">
      <div className="flex flex-wrap items-center gap-3">
        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-amber-400/15 text-amber-200"><UserPlus size={20} /></span>
        <div className="min-w-0 flex-1">
          <p className="text-[14px] font-extrabold text-white">{tr('ادعُ المكاتب التي تتعامل معها')}</p>
          <p className="text-[11.5px] leading-relaxed text-slate-400">{tr('كل مكتب ينضم يستلم حوالاتك فوراً، والمقاصة بينكما تصير تلقائية ومؤكدة من الطرفين.')}</p>
        </div>
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        <button type="button" onClick={() => share.whatsapp('', inviteText(myCode))} className="inline-flex min-h-[44px] flex-1 items-center justify-center gap-2 rounded-xl bg-emerald-500 px-4 text-[13px] font-extrabold text-emerald-950 hover:bg-emerald-400">
          <MessageCircle size={16} />{tr('دعوة عبر واتساب')}
        </button>
        <GhostBtn onClick={() => share.copy(inviteText(myCode)).then((ok) => ok && toast(tr('تم النسخ')))}>
          <span className="inline-flex items-center gap-1.5"><Copy size={14} />{tr('نسخ الدعوة')}</span>
        </GhostBtn>
        <GhostBtn onClick={() => setQr((v) => !v)}>
          <span className="inline-flex items-center gap-1.5"><QrCode size={14} />QR</span>
        </GhostBtn>
      </div>
      {qr ? (
        <div className="rise mt-3 flex flex-col items-center gap-2">
          <div className="rounded-2xl bg-white p-3"><QRCodeSVG value={link} size={150} level="M" fgColor="#0a1222" bgColor="#ffffff" /></div>
          <p className="text-[11.5px] text-slate-400">{tr('يمسحه صاحب المكتب ليسجّل مكتبه، ثم يرسل لك طلب شراكة بالكود')} <span dir="ltr" className="font-extrabold tracking-widest text-white">{myCode}</span></p>
        </div>
      ) : null}
    </Card>
  )
}

/* ───────────────────────── كود المكتب (مطويّ) ───────────────────────── */
function MyCodeCard() {
  const toast = useToast()
  const { myCode } = useLy()
  const [open, setOpen] = useState(false)
  return (
    <Card className="overflow-hidden border-sky-400/20 bg-sky-500/[0.04]">
      <button type="button" onClick={() => setOpen((v) => !v)} className="flex min-h-[54px] w-full items-center justify-between gap-3 px-4 text-start transition hover:bg-white/[0.03]">
        <span className="flex items-center gap-2 text-[13px] font-extrabold text-sky-100"><Link2 size={15} />{tr('كود مكتبك في التطبيق')}</span>
        <span className="flex items-center gap-1 text-[11.5px] font-bold text-sky-200/70">
          {open ? tr('إخفاء') : tr('إظهار')}
          <ChevronDown size={15} className={`transition-transform ${open ? 'rotate-180' : ''}`} />
        </span>
      </button>
      {open ? (
        <div className="rise flex flex-wrap items-center justify-between gap-3 border-t border-white/[0.06] px-4 pb-4 pt-3">
          <div className="min-w-0">
            <p className="font-display text-[26px] font-black tracking-[0.25em] text-white tabular-nums" dir="ltr">{myCode || '—'}</p>
            <p className="text-[11.5px] text-slate-400">{tr('أعطه للمكاتب الأخرى حتى ترسل لك طلب شراكة.')}</p>
          </div>
          <div className="flex gap-2">
            <GhostBtn onClick={() => share.copy(myCode).then((ok) => ok && toast(tr('تم النسخ')))}>
              <span className="inline-flex items-center gap-1.5"><Copy size={14} />{tr('نسخ')}</span>
            </GhostBtn>
            <button type="button" onClick={() => share.whatsapp('', `${tr('كود مكتبي في تطبيق ALEGDALY TECH')}: ${myCode}`)} aria-label="WhatsApp" className="flex h-[42px] w-11 items-center justify-center rounded-xl border border-emerald-400/25 bg-emerald-500/10 text-emerald-200 hover:bg-emerald-500/20">
              <MessageCircle size={16} />
            </button>
          </div>
        </div>
      ) : null}
    </Card>
  )
}

/* ───────────────────────── الأرباح ───────────────────────── */
function Profits({ ws, version }) {
  const [st, setSt] = useState(null)
  useEffect(() => {
    let off = false
    const base = { ws, dir: 'out', status: { ne: 'cancelled' } }
    Promise.all([
      db.sumShared(TX, 'fee', { ...base, date: { gte: dayStartISO(0) } }),
      db.sumShared(TX, 'fee', { ...base, date: { gte: dayStartISO(6) } }),
      db.sumShared(TX, 'fee', { ...base, date: { gte: monthStartISO() } }),
      db.groupByShared(TX, 'officeName', { agg: 'sum', field: 'deliver', filters: { ws, status: { ne: 'cancelled' } }, order: '-count', limit: 1 }),
    ])
      .then(([d, w, m, top]) => !off && setSt({ d, w, m, top: top?.[0] || null }))
      .catch(() => !off && setSt({ d: 0, w: 0, m: 0, top: null }))
    return () => { off = true }
  }, [ws, version])

  const items = [
    { k: tr('عمولات اليوم'), v: st?.d },
    { k: tr('هذا الأسبوع'), v: st?.w },
    { k: tr('هذا الشهر'), v: st?.m },
  ]
  return (
    <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
      {items.map((it) => (
        <Card key={it.k} className="p-3.5">
          <p className="text-[11px] font-bold text-slate-500">{it.k}</p>
          <p className="font-display mt-1 text-[20px] font-black tabular-nums text-amber-200">
            {st ? fmt(it.v) : '—'} <span className="text-[11px] font-bold text-amber-200/60">{cur()}</span>
          </p>
        </Card>
      ))}
      <Card className="p-3.5">
        <p className="flex items-center gap-1 text-[11px] font-bold text-slate-500"><TrendingUp size={12} />{tr('أكثر مكتب تتعامل معه')}</p>
        <p className="font-display mt-1 truncate text-[15px] font-black text-white">{st?.top?.key || '—'}</p>
        {st?.top ? <p className="text-[11px] font-bold text-slate-500">{tr('{n} حوالة', { n: st.top.count })}</p> : null}
      </Card>
    </div>
  )
}

/* ───────────────────────── حوالة جديدة ───────────────────────── */
function NewTransfer({ offices, goOffices, onDone }) {
  const toast = useToast()
  const lyData = useLyData()
  const { ws, gid, writeOpts, userId, myCode, myName } = useLy()
  const [dir, setDir] = useState('out')
  const savingRef = useRef(false)
  const [officeId, setOfficeId] = useState('')
  const [f, setF] = useState({ senderName: '', senderPhone: '', recvName: '', recvPhone: '', amount: '', fee: '', code: '' })
  const [feeMode, setFeeMode] = useState('deduct')
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(null)
  const [officePhoneDraft, setOfficePhoneDraft] = useState('')
  const set = (k) => (v) => setF((x) => ({ ...x, [k]: typeof v === 'string' ? v : v.target.value }))

  useEffect(() => {
    if ((!officeId || !offices.some((o) => o.id === officeId)) && offices.length) setOfficeId(offices[0].id)
  }, [offices, officeId])

  const amount = Number(f.amount) || 0
  const fee = dir === 'out' ? Number(f.fee) || 0 : 0
  const deliver = dir === 'out' && feeMode === 'deduct' ? amount - fee : amount
  const paid = dir === 'out' ? (feeMode === 'add' ? amount + fee : amount) : 0

  async function save() {
    const office = offices.find((o) => o.id === officeId)
    if (!office) return toast(tr('اختر المكتب أولاً'), 'err')
    if (!f.recvName.trim()) return toast(tr('اكتب اسم المستلم'), 'err')
    if (!amount) return toast(tr('أدخل مبلغاً صحيحاً'), 'err')
    if (deliver <= 0) return toast(tr('العمولة أكبر من المبلغ'), 'err')
    if (!gid) return toast(tr('تعذّر تجهيز الجلسة، أعد المحاولة'), 'err')
    // منع التسجيل المزدوج بضغطتين سريعتين
    if (savingRef.current) return
    savingRef.current = true
    setSaving(true)
    try {
      const now = new Date().toISOString()
      const linked = dir === 'out' && office.linkedUserId
      const row = {
        ws,
        dir,
        officeId: office.id,
        officeName: office.name,
        officeCity: office.city || '',
        officePhone: office.phone || '',
        senderName: f.senderName.trim(),
        senderPhone: f.senderPhone.trim(),
        recvName: f.recvName.trim(),
        recvPhone: f.recvPhone.trim(),
        amount,
        fee,
        feeMode: dir === 'out' ? feeMode : 'none',
        paid,
        deliver,
        code: dir === 'out' ? newCode() : f.code.replace(/[^\d]/g, ''),
        status: 'pending',
        date: now,
      }
      if (linked) {
        // الحوالة تظهر مباشرة عند المكتب الشريك — يقرؤها هو فقط، ولا يغيّر فيها إلا حالة التسليم
        const linkId = rid('lk')
        await db.insertShared(
          LINK,
          {
            fromWs: ws, fromCode: myCode, fromUserId: userId, fromName: myName,
            toWs: office.linkedWs || '', toCode: office.linkedCode || '', toUserId: office.linkedUserId,
            senderName: row.senderName, senderPhone: row.senderPhone,
            recvName: row.recvName, recvPhone: row.recvPhone,
            deliver, status: 'pending', date: now,
          },
          linkId,
          { groupId: gid, visibleTo: `user:${office.linkedUserId}`, writableBy: `user:${office.linkedUserId}`, writableFields: ['status', 'deliveredAt'] },
        )
        // الرقم السري يبقى على السيرفر — المكتب المستلم يتحقق منه ولا يراه
        await db.setSecret(LINK, linkId, 'code', row.code)
        row.linkId = linkId
      }
      const txId = rid('tx')
      await db.insertShared(TX, row, txId, writeOpts)
      lyData?.addTx({ ...row, id: txId })
      if (linked) {
        notify(
          office.linkedUserId,
          '💸 حوالة واردة جديدة',
          `من ${myName}: سلّم ${fmt(deliver)} د.ل إلى ${row.recvName}. لا تسلّم إلا بالرقم السري.`,
          '#/ly/in',
        )
      }
      setSaved(row)
      setOfficePhoneDraft('')
      setF({ senderName: '', senderPhone: '', recvName: '', recvPhone: '', amount: '', fee: '', code: '' })
      toast(tr('تم تسجيل الحوالة'))
    } catch (e) {
      toast(e?.message || tr('تعذّر تسجيل العملية'), 'err')
    } finally {
      savingRef.current = false
      setSaving(false)
    }
  }

  if (saved) {
    return (
      <Card className="rise space-y-4 p-5 text-center md:p-7">
        <CheckCircle2 size={34} className="mx-auto text-emerald-300" />
        <p className="font-display text-[18px] font-black text-white">{tr('تم تسجيل الحوالة')}</p>
        {saved.dir === 'out' ? (
          <>
            <div className="mx-auto max-w-xs rounded-2xl border border-amber-300/30 bg-amber-400/10 p-4">
              <p className="text-[11px] font-bold text-amber-200/80">{tr('الرقم السري')}</p>
              <p className="font-display mt-1 text-[34px] font-black tracking-[0.3em] text-amber-100 tabular-nums">{saved.code}</p>
            </div>
            <p className="text-[12.5px] text-slate-400">
              {tr('يستلم {name} مبلغ {amount} من {office}', { name: saved.recvName, amount: `${fmt(saved.deliver)} ${cur()}`, office: saved.officeName })}
            </p>
            <div className="mx-auto w-full max-w-sm space-y-2 rounded-2xl border border-emerald-400/25 bg-emerald-500/[0.07] p-3 text-start">
              <p className="text-[12.5px] font-extrabold text-emerald-100">{tr('إعلام صاحب المكتب')} — {saved.officeName}</p>
              {!saved.officePhone && (
                <input
                  value={officePhoneDraft}
                  onChange={(e) => setOfficePhoneDraft(e.target.value)}
                  inputMode="tel"
                  dir="ltr"
                  className={fieldCls}
                  placeholder={tr('رقم واتساب المكتب') + ' 09x xxx xxxx'}
                />
              )}
              <button
                type="button"
                onClick={() => {
                  const raw = saved.officePhone || officePhoneDraft.trim()
                  const phone = lyPhone(raw)
                  if (!phone) return toast(tr('اكتب رقم واتساب المكتب'), 'err')
                  if (!saved.officePhone) {
                    // نحفظ الرقم في دليل المكاتب للمرات القادمة — بدون انتظار حتى لا يتأخر فتح واتساب
                    db.updateShared(OFF, saved.officeId, { phone: raw }).catch(() => null)
                    setSaved((s) => ({ ...s, officePhone: raw }))
                  }
                  share.whatsapp(phone, officeNoticeText(saved, myName, myCode))
                }}
                className="inline-flex min-h-[46px] w-full items-center justify-center gap-2 rounded-xl bg-emerald-500 px-4 text-[13.5px] font-black text-emerald-950 hover:bg-emerald-400"
              >
                <MessageCircle size={17} />{tr('إرسال الحوالة للمكتب عبر واتساب')}
              </button>
              <p className="text-[11px] leading-relaxed text-slate-400">
                {saved.linkId
                  ? tr('المكتب شريك في التطبيق: الرسالة لا تحتوي الرقم السري، والتحقق يتم داخل التطبيق.')
                  : tr('يفتح واتساب برسالة جاهزة فيها تفاصيل الحوالة والرقم السري، وأنت تضغط إرسال.')}
              </p>
            </div>
            <div className="flex flex-wrap justify-center gap-2">
              <button
                type="button"
                onClick={() => share.whatsapp(lyPhone(saved.recvPhone), receiptText(saved))}
                className="inline-flex min-h-[44px] items-center gap-2 rounded-xl border border-emerald-400/30 bg-emerald-500/15 px-4 text-[13px] font-extrabold text-emerald-200 hover:bg-emerald-500/25"
              >
                <MessageCircle size={16} />{tr('إرسال الإيصال للزبون عبر واتساب')}
              </button>
              <GhostBtn onClick={() => share.copy(receiptText(saved)).then((ok) => ok && toast(tr('تم النسخ')))}>
                <span className="inline-flex items-center gap-1.5"><Copy size={14} />{tr('نسخ الإيصال')}</span>
              </GhostBtn>
            </div>
          </>
        ) : (
          <p className="text-[12.5px] text-slate-400">{tr('سلّم المبلغ للمستلم ثم أكّد التسليم من قائمة الحوالات.')}</p>
        )}
        <div className="flex justify-center gap-2 pt-1">
          <GhostBtn onClick={() => setSaved(null)}>{tr('حوالة جديدة')}</GhostBtn>
          <GhostBtn onClick={onDone}>{tr('قائمة الحوالات')}</GhostBtn>
        </div>
      </Card>
    )
  }

  if (!offices.length) {
    return (
      <EmptyState
        icon={Building2}
        title={tr('أضف مكتباً أولاً')}
        text={tr('سجّل المكاتب التي تتعامل معها في «دليل المكاتب» حتى تختارها بضغطة.')}
        action={<GhostBtn onClick={goOffices}>{tr('دليل المكاتب')}</GhostBtn>}
      />
    )
  }

  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <Segmented
        value={dir}
        onChange={setDir}
        options={[
          { value: 'out', label: tr('أرسل عبر مكتب آخر') },
          { value: 'in', label: tr('وصلتني لأسلّمها') },
        ]}
      />
      <Card className="space-y-4 p-4 md:p-6">
        <Field label={dir === 'out' ? tr('المكتب الذي سيسلّم') : tr('المكتب المرسِل')}>
          <select value={officeId} onChange={(e) => setOfficeId(e.target.value)} className={`${fieldCls} appearance-none`}>
            {offices.map((o) => (
              <option key={o.id} value={o.id} className="bg-[#0b1424]">{o.name}{o.city ? ` — ${o.city}` : ''}{o.linkedUserId ? ` · ${tr('شريك')}` : ''}</option>
            ))}
          </select>
        </Field>
        {dir === 'out' && offices.find((o) => o.id === officeId)?.linkedUserId ? (
          <p className="flex items-center gap-1.5 rounded-xl border border-emerald-400/25 bg-emerald-500/10 px-3 py-2 text-[12px] font-bold text-emerald-200">
            <Zap size={14} />{tr('هذا المكتب شريك: ستظهر الحوالة عنده مباشرة، ويؤكّد التسليم بالرقم السري.')}
          </p>
        ) : null}
        <div className="grid gap-4 md:grid-cols-2">
          <Field label={tr('اسم المرسل')}><input value={f.senderName} onChange={set('senderName')} className={fieldCls} /></Field>
          <Field label={tr('هاتف المرسل')}><input value={f.senderPhone} onChange={set('senderPhone')} inputMode="tel" dir="ltr" className={fieldCls} placeholder="09x xxx xxxx" /></Field>
          <Field label={tr('اسم المستلم')}><input value={f.recvName} onChange={set('recvName')} className={fieldCls} /></Field>
          <Field label={tr('هاتف المستلم')}><input value={f.recvPhone} onChange={set('recvPhone')} inputMode="tel" dir="ltr" className={fieldCls} placeholder="09x xxx xxxx" /></Field>
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          <Field label={`${tr('المبلغ')} (${cur()})`}>
            <MoneyInput value={f.amount} onChange={set('amount')} placeholder="1,000" className={`${fieldCls} font-display text-[18px]`} />
          </Field>
          {dir === 'out' ? (
            <Field label={`${tr('العمولة')} (${cur()})`}>
              <MoneyInput value={f.fee} onChange={set('fee')} placeholder="5" className={`${fieldCls} font-display text-[18px]`} />
            </Field>
          ) : (
            <Field label={tr('الرقم السري من المكتب المرسِل (اختياري)')}>
              <input value={f.code} onChange={(e) => setF((x) => ({ ...x, code: e.target.value.replace(/[^\d]/g, '').slice(0, 8) }))} inputMode="numeric" dir="ltr" className={`${fieldCls} tracking-[0.3em]`} />
            </Field>
          )}
        </div>
        {dir === 'out' ? (
          <Segmented
            value={feeMode}
            onChange={setFeeMode}
            options={[
              { value: 'deduct', label: tr('العمولة تُخصم من المبلغ') },
              { value: 'add', label: tr('العمولة فوق المبلغ') },
            ]}
          />
        ) : null}
        {amount ? (
          <div className="grid grid-cols-2 gap-2 rounded-2xl border border-white/[0.07] bg-black/20 p-3 text-center">
            {dir === 'out' ? (
              <div>
                <p className="text-[11px] font-bold text-slate-500">{tr('يدفع الزبون')}</p>
                <p className="font-display text-[17px] font-black tabular-nums text-white">{fmt(paid)} {cur()}</p>
              </div>
            ) : (
              <div>
                <p className="text-[11px] font-bold text-slate-500">{tr('مكتب الإرسال')}</p>
                <p className="font-display truncate text-[15px] font-black text-white">{offices.find((o) => o.id === officeId)?.name}</p>
              </div>
            )}
            <div>
              <p className="text-[11px] font-bold text-slate-500">{tr('يستلم المستلم')}</p>
              <p className={`font-display text-[17px] font-black tabular-nums ${deliver > 0 ? 'text-emerald-300' : 'text-rose-300'}`}>{fmt(deliver)} {cur()}</p>
            </div>
          </div>
        ) : null}
      </Card>
      <PrimaryBtn onClick={save} disabled={saving} className="!from-amber-400 !to-amber-300 !text-[#1a1206] !shadow-[0_10px_30px_-12px_rgba(251,191,36,0.8)]">
        {saving ? tr('جارٍ الحفظ...') : tr('تسجيل الحوالة')}
      </PrimaryBtn>
    </div>
  )
}

/* ───────────────────────── قائمة الحوالات ───────────────────────── */
function TransferRow({ t, link }) {
  const toast = useToast()
  const ask = useConfirm()
  const lyData = useLyData()
  const { gid } = useLy()
  const [removing, setRemoving] = useState(false)
  const [open, setOpen] = useState(false)
  const [code, setCode] = useState('')
  const [busy, setBusy] = useState(false)
  const linkDelivered = link?.status === 'delivered'
  const pending = t.status === 'pending' && !linkDelivered
  const viaApp = !!t.linkId

  async function deliver() {
    if (t.code && code !== t.code) return toast(tr('الرقم السري غير صحيح'), 'err')
    setBusy(true)
    try {
      const fields = { status: 'delivered', deliveredAt: new Date().toISOString() }
      await db.updateShared(TX, t.id, fields, { expect: { status: 'pending' } })
      lyData?.patchTx(t.id, fields)
      toast(tr('تم تأكيد التسليم'))
      setOpen(false)
    } catch (e) {
      toast(isExpect(e) ? tr('هذه الحوالة لم تعد بانتظار التسليم') : e?.message || tr('تعذّر تسجيل العملية'), 'err')
    } finally {
      setBusy(false)
    }
  }
  async function cancel() {
    const ok = await ask({
      title: tr('إلغاء هذه الحوالة؟'),
      text: `${t.recvName} · ${fmt(t.deliver)} ${cur()}`,
      confirmLabel: tr('تأكيد الإلغاء'),
      icon: XCircle,
    })
    if (!ok) return
    try {
      if (t.linkId) {
        // لا يُلغى إلا إذا كانت ما زالت بانتظار التسليم عند الشريك (السيرفر يتحقق)
        await db.updateShared(LINK, t.linkId, { status: 'cancelled' }, { expect: { status: 'pending' } })
        lyData?.patchLink(t.linkId, { status: 'cancelled' })
      }
      const fields = { status: 'cancelled', cancelledAt: new Date().toISOString() }
      await db.updateShared(TX, t.id, fields, { expect: { status: 'pending' } })
      lyData?.patchTx(t.id, fields)
      if (t.linkId) {
        notify(link?.toUserId, '⛔ أُلغيت حوالة — لا تسلّمها', `${t.recvName} · ${fmt(t.deliver)} د.ل — ألغاها المكتب المرسل.`, '#/ly/in')
      }
      toast(tr('تم إلغاء الحوالة'))
    } catch (e) {
      toast(isExpect(e) ? tr('لا يمكن الإلغاء: المكتب الشريك سلّمها بالفعل') : e?.message || tr('تعذّر تسجيل العملية'), 'err')
      lyData?.refreshAll()
    }
  }

  // الإزالة من السجل = أرشفة: تختفي من القائمة فقط، ولا تتغيّر المقاصة ولا الأرباح (الحذف الفعلي ممنوع على السيرفر)
  async function remove() {
    const willCancel = pending
    const ok = await ask({
      title: tr('إزالة الحوالة من السجل؟'),
      text: [
        `${t.recvName} · ${fmt(t.deliver)} ${cur()}`,
        willCancel ? (t.linkId ? tr('لم تُسلَّم بعد: ستُلغى أولاً ويصل المكتب الشريك تنبيه بعدم تسليمها.') : tr('لم تُسلَّم بعد: ستُلغى أولاً.')) : '',
        tr('تختفي من القائمة فقط، وتبقى محفوظة في المقاصة والأرباح وكشف الحساب، وتجدها بالبحث.'),
      ].filter(Boolean).join(' — '),
      confirmLabel: tr('إزالة'),
      danger: true,
      icon: Trash2,
    })
    if (!ok) return
    setRemoving(true)
    try {
      const now = new Date().toISOString()
      if (willCancel && t.linkId) {
        await db.updateShared(LINK, t.linkId, { status: 'cancelled' }, { expect: { status: 'pending' } })
        lyData?.patchLink(t.linkId, { status: 'cancelled' })
        notify(link?.toUserId, '⛔ أُلغيت حوالة — لا تسلّمها', `${t.recvName} · ${fmt(t.deliver)} د.ل — ألغاها المكتب المرسل.`, '#/ly/in')
      }
      const fields = willCancel
        ? { status: 'cancelled', cancelledAt: now, archived: true, archivedAt: now }
        : { archived: true, archivedAt: now }
      await db.updateShared(TX, t.id, fields, willCancel ? { expect: { status: 'pending' } } : undefined)
      lyData?.removeTx([t.id])
      toast(tr('أُزيلت من السجل'))
    } catch (e) {
      toast(isExpect(e) ? tr('لا يمكن الإلغاء: المكتب الشريك سلّمها بالفعل') : e?.message || tr('تعذّر تسجيل العملية'), 'err')
      lyData?.refreshAll()
      setRemoving(false)
    }
  }

  const shown = linkDelivered ? 'delivered' : t.status
  const badge =
    shown === 'delivered'
      ? { cls: 'border-emerald-400/30 bg-emerald-500/10 text-emerald-200', icon: CheckCircle2, label: tr('تم التسليم') }
      : shown === 'cancelled'
        ? { cls: 'border-slate-400/20 bg-white/[0.04] text-slate-400', icon: XCircle, label: tr('ملغاة') }
        : { cls: 'border-amber-400/30 bg-amber-500/10 text-amber-200', icon: Clock, label: viaApp ? tr('بانتظار تأكيد المكتب') : tr('بانتظار التسليم') }
  const B = badge.icon
  const deliveredAt = t.deliveredAt || link?.deliveredAt
  const late = shown === 'pending' ? ageDays(t.date) : 0

  return (
    <Card className="p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="flex items-center gap-1.5 text-[11px] font-bold text-slate-500">
            {t.dir === 'out' ? <ArrowUpRight size={13} className="text-amber-300" /> : <ArrowDownLeft size={13} className="text-sky-300" />}
            {t.dir === 'out' ? tr('عبر {office}', { office: t.officeName }) : tr('من {office}', { office: t.officeName })}
            <span className="text-slate-600">· {when(t.date)}</span>
          </p>
          <p className="font-display mt-1 truncate text-[15px] font-extrabold text-white">{t.recvName}</p>
          {t.senderName ? <p className="truncate text-[11.5px] text-slate-500">{tr('من')}: {t.senderName}</p> : null}
        </div>
        <div className="shrink-0 text-end">
          <p className="font-display text-[18px] font-black tabular-nums text-white">{fmt(t.deliver)} <span className="text-[11px] text-slate-500">{cur()}</span></p>
          {t.fee ? <p className="text-[11px] font-bold text-amber-200/80">{tr('عمولة')} {fmt(t.fee)}</p> : null}
        </div>
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <span className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-[11px] font-extrabold ${badge.cls}`}>
          <B size={12} />{badge.label}{shown === 'delivered' && deliveredAt ? ` · ${when(deliveredAt)}` : ''}
        </span>
        {late >= 1 ? (
          <span className="inline-flex items-center gap-1 rounded-full border border-rose-400/30 bg-rose-500/10 px-2.5 py-1 text-[11px] font-extrabold text-rose-200">
            <AlertTriangle size={11} />{tr('متأخرة {n} يوم', { n: late })}
          </span>
        ) : null}
        {t.archived ? (
          <span className="inline-flex items-center gap-1 rounded-full border border-white/10 bg-white/[0.04] px-2.5 py-1 text-[11px] font-extrabold text-slate-400">{tr('مؤرشفة')}</span>
        ) : null}
        {viaApp ? (
          <span className="inline-flex items-center gap-1 rounded-full border border-sky-400/25 bg-sky-500/10 px-2.5 py-1 text-[11px] font-extrabold text-sky-200">
            <Zap size={11} />{tr('عبر التطبيق')}
          </span>
        ) : null}
        {t.dir === 'out' && t.code ? (
          <span className="inline-flex items-center gap-1 rounded-full border border-white/10 px-2.5 py-1 text-[11px] font-bold tabular-nums tracking-widest text-slate-300">
            <KeyRound size={11} />{t.code}
          </span>
        ) : null}
        <div className="ms-auto flex flex-wrap gap-2">
          {t.dir === 'out' && t.status !== 'cancelled' ? (
            <button type="button" onClick={() => share.whatsapp(lyPhone(t.recvPhone), receiptText(t))} className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-emerald-400/25 bg-emerald-500/10 px-3 text-[12px] font-extrabold text-emerald-200 hover:bg-emerald-500/20">
              <MessageCircle size={14} />{tr('واتساب')}
            </button>
          ) : null}
          {pending && !viaApp ? (
            <button type="button" onClick={() => setOpen((v) => !v)} className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl bg-emerald-500/90 px-3 text-[12px] font-extrabold text-emerald-950 hover:bg-emerald-400">
              <CheckCircle2 size={14} />{tr('تأكيد التسليم')}
            </button>
          ) : null}
          {pending ? (
            <button type="button" onClick={cancel} className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-rose-400/25 bg-rose-500/10 px-3 text-[12px] font-extrabold text-rose-200 hover:bg-rose-500/20">
              <XCircle size={14} />{tr('إلغاء')}
            </button>
          ) : null}
          {t.archived ? null : (
          <button
            type="button"
            disabled={removing}
            onClick={remove}
            aria-label={tr('إزالة')}
            className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 text-slate-500 transition hover:border-rose-400/25 hover:bg-rose-500/10 hover:text-rose-300 disabled:opacity-50"
          >
            <Trash2 size={15} />
          </button>
          )}
        </div>
      </div>
      {open && pending ? (
        <div className="mt-3 flex flex-wrap items-end gap-2 rounded-2xl border border-white/[0.07] bg-black/20 p-3">
          {t.code ? (
            <label className="min-w-[160px] flex-1">
              <span className="mb-1 block text-[11px] font-bold text-slate-400">{tr('الرقم السري الذي قاله المستلم')}</span>
              <input value={code} onChange={(e) => setCode(e.target.value.replace(/[^\d]/g, '').slice(0, 8))} inputMode="numeric" dir="ltr" className={`${fieldCls} tracking-[0.3em]`} />
            </label>
          ) : (
            <p className="flex-1 text-[12px] text-slate-400">{tr('لا يوجد رقم سري لهذه الحوالة. أكّد بعد التسليم.')}</p>
          )}
          <button type="button" disabled={busy} onClick={deliver} className="min-h-[46px] rounded-xl bg-emerald-500 px-4 text-[13px] font-extrabold text-emerald-950 disabled:opacity-50">
            {busy ? tr('جارٍ...') : tr('تم التسليم')}
          </button>
        </div>
      ) : null}
    </Card>
  )
}

function TransferList({ rows, loading, goNew, linkMap }) {
  const toast = useToast()
  const ask = useConfirm()
  const lyData = useLyData()
  const { ws } = useLy()
  const [filter, setFilter] = useState('pending')
  const [clearing, setClearing] = useState(null) // null | { done, total }
  const [q, setQ] = useState('')
  const [hits, setHits] = useState(null) // نتائج البحث في كل السجل (حتى القديم والمؤرشف)
  const [searching, setSearching] = useState(false)
  // الحالة الفعلية: حوالة عبر التطبيق سلّمها الشريك = مسلّمة حتى لو لم تتحدّث بعد
  const eff = useCallback((r) => (r.linkId && linkMap[r.linkId]?.status === 'delivered' ? 'delivered' : r.status), [linkMap])
  const term = q.trim()

  useEffect(() => {
    if (term.length < 2) { setHits(null); setSearching(false); return undefined }
    let off = false
    setSearching(true)
    const h = setTimeout(() => {
      db.searchShared(TX, term, { fields: ['recvName', 'recvPhone', 'senderName', 'senderPhone', 'code', 'officeName'], limit: 200, order: '-createdAt' })
        .then((r) => { if (!off) setHits((r || []).filter((x) => x.ws === ws)) })
        .catch(() => { if (!off) setHits([]) })
        .finally(() => { if (!off) setSearching(false) })
    }, 400)
    return () => { off = true; clearTimeout(h) }
  }, [term, ws])

  const source = useMemo(() => {
    if (term.length < 2) return rows
    const s = term.toLowerCase()
    const digits = term.replace(/[^\d]/g, '')
    const num = Number(digits)
    const hit = (r) =>
      [r.recvName, r.senderName, r.officeName, r.code].some((v) => String(v || '').toLowerCase().includes(s)) ||
      (digits.length >= 3 && [r.recvPhone, r.senderPhone].some((v) => String(v || '').replace(/[^\d]/g, '').includes(digits))) ||
      (digits && digits === term.replace(/[\s,]/g, '') && (Number(r.deliver) === num || Number(r.amount) === num))
    const m = new Map()
    for (const r of rows) if (hit(r)) m.set(r.id, r)
    for (const r of hits || []) if (!m.has(r.id)) m.set(r.id, r)
    return [...m.values()].sort((a, b) => String(b.date || '').localeCompare(String(a.date || '')))
  }, [rows, hits, term])
  const list = useMemo(() => (filter === 'all' ? source : source.filter((r) => eff(r) === filter)), [source, filter, eff])
  const pendingCount = source.filter((r) => eff(r) === 'pending').length
  const finishedCount = rows.filter((r) => r.status === 'delivered' || r.status === 'cancelled').length

  // تنظيف السجل: أرشفة كل الحوالات المسلّمة والملغاة — تختفي من القائمة وتبقى في المقاصة والأرباح والبحث
  async function clearHistory() {
    const ok = await ask({
      title: tr('تنظيف السجل؟'),
      text: tr('تختفي كل الحوالات المسلّمة والملغاة من القائمة. تبقى محفوظة في المقاصة والأرباح وكشف الحساب، وتجدها بالبحث. الحوالات التي بانتظار التسليم تبقى كما هي.'),
      confirmLabel: tr('تنظيف'),
      danger: false,
      icon: Trash2,
    })
    if (!ok) return
    setClearing({ done: 0, total: 0 })
    try {
      const txRows = await db.selectAllShared(TX, { ws, status: { in: ['delivered', 'cancelled'] } })
      const todo = (txRows || []).filter((r) => !r.archived)
      setClearing({ done: 0, total: todo.length })
      const now = new Date().toISOString()
      const gone = []
      let failed = 0
      for (let i = 0; i < todo.length; i += 20) {
        const chunk = todo.slice(i, i + 20)
        try {
          await db.batch(chunk.map((r) => ({ action: 'updateShared', collection: TX, id: r.id, data: { archived: true, archivedAt: now } })))
          chunk.forEach((r) => gone.push(r.id))
        } catch {
          failed += chunk.length
        }
        setClearing({ done: Math.min(i + 20, todo.length), total: todo.length })
      }
      lyData?.removeTx(gone)
      lyData?.refreshAll()
      if (failed) toast(tr('تعذّر تنظيف {n} سجل، حاول مرة أخرى', { n: failed }), 'err')
      else toast(tr('تم تنظيف السجل'))
    } catch (e) {
      toast(e?.message || tr('تعذّر تسجيل العملية'), 'err')
    } finally {
      setClearing(null)
    }
  }

  return (
    <div className="space-y-3">
      {finishedCount ? (
        <div className="flex justify-end">
          <button
            type="button"
            disabled={!!clearing}
            onClick={clearHistory}
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-rose-400/25 bg-rose-500/10 px-3.5 text-[12px] font-extrabold text-rose-200 transition hover:bg-rose-500/20 disabled:opacity-60"
          >
            <Trash2 size={14} />
            {clearing ? (clearing.total ? `${tr('جارٍ...')} ${clearing.done}/${clearing.total}` : tr('جارٍ...')) : tr('تنظيف السجل')}
          </button>
        </div>
      ) : null}
      <div className="relative">
        <Search size={17} className="pointer-events-none absolute start-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          className={`${fieldCls} ps-10 pe-10`}
          placeholder={tr('ابحث: اسم المستلم، الهاتف، المرسل، المكتب، الرقم السري أو المبلغ')}
        />
        {q ? (
          <button type="button" onClick={() => setQ('')} aria-label={tr('مسح')} className="absolute end-2 top-1/2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-lg text-slate-400 hover:bg-white/[0.06]">
            <X size={15} />
          </button>
        ) : null}
      </div>
      {term.length >= 2 ? (
        <p className="text-[11.5px] font-bold text-slate-500">
          {searching ? tr('جارٍ البحث في كل السجل...') : tr('{n} نتيجة — البحث يشمل الحوالات القديمة والمؤرشفة', { n: list.length })}
        </p>
      ) : null}
      <Segmented
        value={filter}
        onChange={setFilter}
        options={[
          { value: 'pending', label: `${tr('لم تُسلَّم')} (${pendingCount})` },
          { value: 'delivered', label: tr('تم التسليم') },
          { value: 'cancelled', label: tr('ملغاة') },
          { value: 'all', label: tr('الكل') },
        ]}
      />
      {loading && !rows.length ? (
        <div className="py-12 text-center text-[12px] text-slate-500">{tr('جارٍ...')}</div>
      ) : list.length ? (
        <div className="grid gap-3 lg:grid-cols-2">{list.map((t) => <TransferRow key={t.id} t={t} link={t.linkId ? linkMap[t.linkId] : null} />)}</div>
      ) : (
        <EmptyState icon={term.length >= 2 ? Search : ListChecks} title={term.length >= 2 ? tr('لا توجد نتائج') : tr('لا توجد حوالات هنا')} action={term.length >= 2 ? null : <GhostBtn onClick={goNew}>{tr('حوالة جديدة')}</GhostBtn>} />
      )}
    </div>
  )
}

/* ───────────────────────── الحوالات الواردة من المكاتب الشريكة ───────────────────────── */
async function recordIncoming(link, ws, writeOpts) {
  // سجل التسليم في حسابات هذا المكتب (للمقاصة) — مرة واحدة لكل حوالة
  const offs = await db.selectShared(OFF, { ws }).catch(() => [])
  const office = await linkOffice(ws, offs || [], { code: link.fromCode, userId: link.fromUserId, ws: link.fromWs, name: link.fromName }, writeOpts)
  try {
    await db.insertShared(
      TX,
      {
        ws, dir: 'in', officeId: office.id, officeName: office.name || link.fromName, officeCity: office.city || '',
        senderName: link.senderName || '', senderPhone: link.senderPhone || '',
        recvName: link.recvName, recvPhone: link.recvPhone || '',
        amount: link.deliver, fee: 0, feeMode: 'none', paid: 0, deliver: link.deliver,
        code: '', status: 'delivered', deliveredAt: new Date().toISOString(), date: new Date().toISOString(),
        fromLinkId: link.id,
      },
      `in_${link.id}`,
      writeOpts,
    )
  } catch (e) {
    if (e?.status !== 409) throw e
  }
}

function IncomingRow({ l }) {
  const toast = useToast()
  const lyData = useLyData()
  const { ws, writeOpts, myName } = useLy()
  const [code, setCode] = useState('')
  const [busy, setBusy] = useState(false)
  const pending = l.status === 'pending'
  const what = `${l.recvName} · ${fmt(l.deliver)} د.ل`

  async function confirm() {
    if (code.length < 4) return toast(tr('اكتب الرقم السري الذي قاله المستلم'), 'err')
    setBusy(true)
    try {
      const ok = await db.checkSecret(LINK, l.id, 'code', code)
      if (!ok) {
        // تنبيه أمني للمكتب المرسل: أحد حاول تسليم حوالته برقم سري خاطئ
        notify(l.fromUserId, '⚠️ رقم سري خاطئ', `أُدخل رقم سري خاطئ لحوالتك (${what}) عند ${myName}.`, '#/ly/list', 'sec')
        toast(tr('الرقم السري غير صحيح'), 'err')
        return
      }
      // وقت التسليم ومن أكّده يسجّلهما السيرفر بنفسه — ولا يُسلَّم مرتين ولا بعد إلغائها
      await db.updateShared(LINK, l.id, { status: 'delivered' }, { expect: { status: 'pending' } })
      lyData?.patchLink(l.id, { status: 'delivered' })
      await recordIncoming(l, ws, writeOpts).catch(() => null)
      lyData?.refreshAll()
      notify(l.fromUserId, '✅ تم تسليم حوالتك', `${myName} سلّم ${fmt(l.deliver)} د.ل إلى ${l.recvName}.`, '#/ly/list')
      setCode('')
      toast(tr('تم تأكيد التسليم'))
    } catch (e) {
      if (isAttempts(e)) notify(l.fromUserId, '🚨 محاولات كثيرة برقم سري خاطئ', `حوالتك (${what}) عند ${myName} — أوقف السيرفر المحاولات مؤقتاً.`, '#/ly/list', 'sec')
      if (isExpect(e)) lyData?.refreshAll()
      toast(isAttempts(e) ? tr('محاولات كثيرة، حاول بعد دقيقة') : isExpect(e) ? tr('الحوالة لم تعد بانتظار التسليم (ربما ألغاها المرسل)') : e?.message || tr('تعذّر تسجيل العملية'), 'err')
    } finally {
      setBusy(false)
    }
  }

  const badge =
    l.status === 'delivered'
      ? { cls: 'border-emerald-400/30 bg-emerald-500/10 text-emerald-200', icon: CheckCircle2, label: tr('تم التسليم') }
      : l.status === 'cancelled'
        ? { cls: 'border-slate-400/20 bg-white/[0.04] text-slate-400', icon: XCircle, label: tr('ألغاها المرسل') }
        : { cls: 'border-amber-400/30 bg-amber-500/10 text-amber-200', icon: Clock, label: tr('بانتظار التسليم') }
  const B = badge.icon

  return (
    <Card className={`p-4 ${pending ? 'border-amber-300/25' : ''}`}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="flex items-center gap-1.5 text-[11px] font-bold text-slate-500">
            <ArrowDownLeft size={13} className="text-sky-300" />
            {tr('من {office}', { office: l.fromName || '—' })}
            <span className="text-slate-600">· {when(l.date)}</span>
          </p>
          <p className="font-display mt-1 truncate text-[15px] font-extrabold text-white">{l.recvName}</p>
          <p className="truncate text-[11.5px] text-slate-500" dir="ltr">{l.recvPhone}</p>
          {l.senderName ? <p className="truncate text-[11.5px] text-slate-500">{tr('من')}: {l.senderName}</p> : null}
        </div>
        <div className="shrink-0 text-end">
          <p className="text-[10.5px] font-bold text-slate-500">{tr('سلّم له')}</p>
          <p className="font-display text-[19px] font-black tabular-nums text-white">{fmt(l.deliver)} <span className="text-[11px] text-slate-500">{cur()}</span></p>
        </div>
      </div>
      <div className="mt-3">
        <span className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-[11px] font-extrabold ${badge.cls}`}>
          <B size={12} />{badge.label}{l.status === 'delivered' && l.deliveredAt ? ` · ${when(l.deliveredAt)}` : ''}
        </span>
      </div>
      {pending ? (
        <div className="mt-3 flex flex-wrap items-end gap-2 rounded-2xl border border-white/[0.07] bg-black/20 p-3">
          <label className="min-w-[160px] flex-1">
            <span className="mb-1 block text-[11px] font-bold text-slate-400">{tr('الرقم السري الذي قاله المستلم')}</span>
            <input value={code} onChange={(e) => setCode(e.target.value.replace(/[^\d]/g, '').slice(0, 8))} inputMode="numeric" dir="ltr" className={`${fieldCls} tracking-[0.3em]`} />
          </label>
          <button type="button" disabled={busy} onClick={confirm} className="min-h-[46px] rounded-xl bg-emerald-500 px-4 text-[13px] font-extrabold text-emerald-950 disabled:opacity-50">
            {busy ? tr('جارٍ...') : tr('تم التسليم')}
          </button>
        </div>
      ) : null}
    </Card>
  )
}

function IncomingList({ rows, loading }) {
  const [filter, setFilter] = useState('pending')
  const [q, setQ] = useState('')
  const term = q.trim().toLowerCase()
  const list = useMemo(() => {
    let out = filter === 'all' ? rows : rows.filter((r) => r.status === filter)
    if (term) {
      const digits = term.replace(/[^\d]/g, '')
      out = out.filter((r) =>
        [r.recvName, r.senderName, r.fromName].some((v) => String(v || '').toLowerCase().includes(term)) ||
        (digits.length >= 3 && [r.recvPhone, r.senderPhone].some((v) => String(v || '').replace(/[^\d]/g, '').includes(digits))) ||
        (digits && Number(r.deliver) === Number(digits)))
    }
    return out
  }, [rows, filter, term])
  return (
    <div className="space-y-3">
      <div className="relative">
        <Search size={17} className="pointer-events-none absolute start-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
        <input value={q} onChange={(e) => setQ(e.target.value)} className={`${fieldCls} ps-10`} placeholder={tr('ابحث: اسم المستلم، الهاتف، المكتب أو المبلغ')} />
      </div>
      <Segmented
        value={filter}
        onChange={setFilter}
        options={[
          { value: 'pending', label: `${tr('بانتظار التسليم')} (${rows.filter((r) => r.status === 'pending').length})` },
          { value: 'delivered', label: tr('تم التسليم') },
          { value: 'all', label: tr('الكل') },
        ]}
      />
      {loading && !rows.length ? (
        <div className="py-12 text-center text-[12px] text-slate-500">{tr('جارٍ...')}</div>
      ) : list.length ? (
        <div className="grid gap-3 lg:grid-cols-2">{list.map((l) => <IncomingRow key={l.id} l={l} />)}</div>
      ) : (
        <EmptyState icon={Inbox} title={tr('لا توجد حوالات واردة')} text={tr('عندما يرسل لك مكتب شريك حوالة من التطبيق تظهر هنا مباشرة.')} />
      )}
    </div>
  )
}

/* ───────────────────────── المقاصة ───────────────────────── */
function SettleRow({ o, balance }) {
  const toast = useToast()
  const ask = useConfirm()
  const { ws, writeOpts, myCode } = useLy()
  const [amt, setAmt] = useState('')
  const [busy, setBusy] = useState(false)
  const b = Math.round(balance || 0)

  async function settle() {
    const val = Number(amt) || Math.abs(b)
    if (!val) return toast(tr('الرصيد صفر، لا شيء للتسوية'), 'info')
    // الرصيد موجب = المكتب عليه لك → دفع لك → ينقص. سالب = أنت عليك → دفعت له → يزيد.
    const effect = b >= 0 ? -val : val
    const ok = await ask({
      title: b >= 0 ? tr('تسجيل استلام {amount} من {name}؟', { amount: `${fmt(val)} ${cur()}`, name: o.name }) : tr('تسجيل دفع {amount} إلى {name}؟', { amount: `${fmt(val)} ${cur()}`, name: o.name }),
      text: tr('التسوية لا تُعدَّل ولا تُحذف بعد تسجيلها. إذا أخطأت سجّل تسوية معاكسة.'),
      confirmLabel: tr('تسجيل'),
      danger: false,
      icon: Scale,
    })
    if (!ok) return
    setBusy(true)
    try {
      await db.insertShared(SET, { ws, officeId: o.id, officeName: o.name, amount: val, effect, date: new Date().toISOString() }, undefined, writeOpts)
      setAmt('')
      toast(tr('تم تسجيل التسوية'))
    } catch (e) {
      toast(e?.message || tr('تعذّر تسجيل العملية'), 'err')
    } finally {
      setBusy(false)
    }
  }

  return (
    <Card className="p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="font-display truncate text-[15px] font-extrabold text-white">{o.name}</p>
          {o.city ? <p className="text-[11.5px] text-slate-500">{o.city}</p> : null}
        </div>
        <div className="text-end">
          <p className={`font-display text-[19px] font-black tabular-nums ${b > 0 ? 'text-emerald-300' : b < 0 ? 'text-rose-300' : 'text-slate-400'}`}>
            {fmt(Math.abs(b))} <span className="text-[11px]">{cur()}</span>
          </p>
          <p className="text-[11px] font-bold text-slate-500">{b > 0 ? tr('لك عنده') : b < 0 ? tr('عليك له') : tr('متعادل')}</p>
        </div>
      </div>
      <button
        type="button"
        onClick={() => share.whatsapp(lyPhone(o.phone), inviteText(myCode))}
        className="mt-3 inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-sky-400/25 bg-sky-500/10 px-3 text-[11.5px] font-extrabold text-sky-200 hover:bg-sky-500/20"
      >
        <UserPlus size={13} />{tr('ادعُه للتطبيق ليصبح الحساب مشتركاً')}
      </button>
      {b !== 0 ? (
        <div className="mt-3 flex items-end gap-2">
          <label className="flex-1">
            <span className="mb-1 block text-[11px] font-bold text-slate-400">{b > 0 ? tr('استلمت منه') : tr('دفعت له')}</span>
            <MoneyInput value={amt} onChange={setAmt} placeholder={fmt(Math.abs(b))} className={fieldCls} />
          </label>
          <button type="button" disabled={busy} onClick={settle} className="min-h-[50px] rounded-xl border border-amber-300/40 bg-amber-400/15 px-4 text-[13px] font-extrabold text-amber-100 hover:bg-amber-400/25 disabled:opacity-50">
            {tr('تسوية')}
          </button>
        </div>
      ) : null}
    </Card>
  )
}

function Clearing({ offices, version, setsVersion }) {
  const { ws } = useLy()
  const [bal, setBal] = useState(null)
  const manual = offices.filter((o) => !o.linkedUserId)
  useEffect(() => {
    let off = false
    // القاعدة: الحوالة تُحسب فور تسجيلها (معلّقة أو مسلّمة)، والملغاة فقط لا تُحسب
    const live = { ws, status: { in: ['pending', 'delivered'] } }
    Promise.all([
      db.groupByShared(TX, 'officeId', { agg: 'sum', field: 'deliver', filters: { ...live, dir: 'in' }, limit: 500 }),
      db.groupByShared(TX, 'officeId', { agg: 'sum', field: 'deliver', filters: { ...live, dir: 'out' }, limit: 500 }),
      db.groupByShared(SET, 'officeId', { agg: 'sum', field: 'effect', filters: { ws }, limit: 500 }),
    ])
      .then(([inn, out, sets]) => {
        if (off) return
        const m = {}
        const add = (arr, sign) => (arr || []).forEach((r) => { m[r.key] = (m[r.key] || 0) + sign * (Number(r.value) || 0) })
        add(inn, 1)
        add(out, -1)
        add(sets, 1)
        setBal(m)
      })
      .catch(() => !off && setBal({}))
    return () => { off = true }
  }, [ws, version, setsVersion])

  return (
    <div className="space-y-5">
      <div className="rise flex gap-3 rounded-2xl border border-emerald-400/20 bg-emerald-500/[0.05] p-4">
        <ShieldCheck size={22} className="mt-0.5 shrink-0 text-emerald-300" />
        <div className="space-y-1.5 text-[12px] leading-relaxed text-slate-300">
          <p className="font-extrabold text-white">{tr('قواعد المقاصة')}</p>
          <p>{tr('كل حوالة ترسلها عبر مكتب تُسجَّل له عليك فور إرسالها، وكل حوالة يرسلها عبرك تُسجَّل لك عليه، فيتصافى الحساب تلقائياً. الحوالة الملغاة فقط لا تُحسب.')}</p>
          <p>{tr('مع المكاتب الشريكة الحساب واحد يراه الطرفان بنفس الأرقام: لا يستطيع أحد حذف حوالة أو تغيير مبلغ، ولا إلغاء حوالة بعد تسليمها، والدفعة لا تُحتسب إلا بعد أن يؤكدها الطرف الآخر. كل تغيير محفوظ بالوقت واسم من قام به.')}</p>
        </div>
      </div>

      <PendingSettlements />

      <PartnerBalances />

      {manual.length ? (
        <div className="space-y-3">
          <div>
            <p className="font-display text-[15px] font-extrabold text-white">{tr('مكاتب خارج التطبيق')}</p>
            <p className="text-[11.5px] text-slate-500">{tr('الحساب هنا من طرفك فقط. ادعُ المكتب للتطبيق حتى يصبح الحساب مشتركاً ومؤكّداً من الطرفين.')}</p>
          </div>
          <div className="grid gap-3 md:grid-cols-2">
            {manual.map((o) => <SettleRow key={o.id} o={o} balance={bal ? bal[o.id] || 0 : 0} />)}
          </div>
        </div>
      ) : null}
    </div>
  )
}

/* ── المقاصة مع المكاتب الشريكة: مصدرها الحوالات المشتركة نفسها (يراها الطرفان) + الدفعات المؤكدة ── */
// الرصيد الموجب = الشريك عليه لك، السالب = أنت عليك له
function usePartnerBalances() {
  const d = useLyData()
  const { userId } = useLy()
  const [st, setSt] = useState(null)
  const [tick, setTick] = useState(0)
  useEffect(() => {
    if (!userId) return undefined
    let off = false
    const g = (coll, by, field, filters) => db.groupByShared(coll, by, { agg: 'sum', field, filters, limit: 500 })
    Promise.all([
      g(LINK, 'toUserId', 'deliver', { fromUserId: userId, status: 'delivered' }),
      g(LINK, 'toUserId', 'deliver', { fromUserId: userId, status: 'pending' }),
      g(LINK, 'fromUserId', 'deliver', { toUserId: userId, status: 'delivered' }),
      g(LINK, 'fromUserId', 'deliver', { toUserId: userId, status: 'pending' }),
      g(PSET, 'toUserId', 'amount', { fromUserId: userId, status: 'confirmed', payerId: userId }),
      g(PSET, 'toUserId', 'amount', { fromUserId: userId, status: 'confirmed', payerId: { ne: userId } }),
      g(PSET, 'fromUserId', 'amount', { toUserId: userId, status: 'confirmed', payerId: userId }),
      g(PSET, 'fromUserId', 'amount', { toUserId: userId, status: 'confirmed', payerId: { ne: userId } }),
    ])
      .then(([oD, oP, iD, iP, s1, s2, s3, s4]) => {
        if (off) return
        const m = {}
        const get = (k) => (m[k] ||= { outD: 0, outP: 0, inD: 0, inP: 0, iPaid: 0, hePaid: 0 })
        const put = (arr, key) => (arr || []).forEach((r) => { if (r.key && r.key !== userId) get(r.key)[key] += Number(r.value) || 0 })
        put(oD, 'outD'); put(oP, 'outP'); put(iD, 'inD'); put(iP, 'inP')
        put(s1, 'iPaid'); put(s3, 'iPaid'); put(s2, 'hePaid'); put(s4, 'hePaid')
        for (const k of Object.keys(m)) {
          const x = m[k]
          x.bal = x.inD + x.inP - x.outD - x.outP + x.iPaid - x.hePaid
        }
        setSt({ map: m, error: false })
      })
      .catch(() => { if (!off) setSt((s) => ({ map: s?.map || {}, error: true })) })
    return () => { off = true }
  }, [userId, d.linkVersion, d.psVersion, tick])
  return { st, reload: () => setTick((n) => n + 1) }
}

function balLabel(b) {
  return b > 0 ? tr('لك عنده') : b < 0 ? tr('له عندك') : tr('متصافي')
}

function PartnerBalances() {
  const d = useLyData()
  const { st, reload } = usePartnerBalances()
  const [names, setNames] = useState({})
  const [open, setOpen] = useState(null) // { userId, name, phone } — كشف الحساب
  const [pay, setPay] = useState(null) // userId

  const partners = useMemo(() => {
    const m = new Map()
    for (const o of d.allOffices) if (o.linkedUserId) m.set(o.linkedUserId, { userId: o.linkedUserId, name: o.name, phone: o.phone || '' })
    for (const k of Object.keys(st?.map || {})) if (!m.has(k)) m.set(k, { userId: k, name: names[k] || '', phone: '' })
    return [...m.values()]
  }, [d.allOffices, st, names])

  // شريك له حساب لكنه غير موجود في دليلك (حُذف منه) — نجلب اسمه حتى لا يختفي حسابه
  useEffect(() => {
    const missing = partners.filter((p) => !p.name && names[p.userId] === undefined).map((p) => p.userId)
    if (!missing.length) return
    Promise.all(missing.map((uid) => db.getShared(NODES, codeOf(uid)).then((n) => [uid, n?.userId === uid ? n.name || codeOf(uid) : codeOf(uid)]).catch(() => [uid, codeOf(uid)])))
      .then((pairs) => setNames((m) => ({ ...m, ...Object.fromEntries(pairs) })))
  }, [partners, names])

  if (!partners.length) {
    return (
      <Card className="p-4 text-center">
        <Handshake size={22} className="mx-auto text-sky-300" />
        <p className="mt-2 text-[13px] font-extrabold text-white">{tr('لا توجد مكاتب شريكة بعد')}</p>
        <p className="mt-1 text-[11.5px] text-slate-500">{tr('المقاصة المشتركة تعمل مع المكاتب الشريكة في التطبيق. أرسل طلب شراكة من صفحة المكاتب.')}</p>
      </Card>
    )
  }

  return (
    <div className="space-y-3">
      <div className="flex items-end justify-between gap-2">
        <div>
          <p className="font-display text-[15px] font-extrabold text-white">{tr('المكاتب الشريكة')}</p>
          <p className="text-[11.5px] text-slate-500">{tr('حساب مشترك — نفس الأرقام عندك وعنده')}</p>
        </div>
        {st?.error ? (
          <button type="button" onClick={reload} className="inline-flex min-h-[38px] items-center gap-1.5 rounded-xl border border-rose-400/25 bg-rose-500/10 px-3 text-[11.5px] font-extrabold text-rose-200">
            <RotateCcw size={13} />{tr('تعذّر التحميل — إعادة')}
          </button>
        ) : null}
      </div>
      <div className="grid gap-3 md:grid-cols-2">
        {partners.map((p) => {
          const x = st?.map?.[p.userId] || { outD: 0, outP: 0, inD: 0, inP: 0, iPaid: 0, hePaid: 0, bal: 0 }
          const b = Math.round(x.bal || 0)
          const name = p.name || names[p.userId] || codeOf(p.userId)
          const waiting = d.psIn.filter((s) => s.status === 'pending' && s.fromUserId === p.userId).length
          return (
            <Card key={p.userId} className="p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="font-display truncate text-[15px] font-extrabold text-white">{name}</p>
                  <span className="mt-1 inline-flex items-center gap-1 rounded-full border border-emerald-400/30 bg-emerald-500/10 px-2 py-[1px] text-[10px] font-extrabold text-emerald-200"><ShieldCheck size={10} />{tr('حساب مشترك')}</span>
                </div>
                <div className="text-end">
                  <p className={`font-display text-[22px] font-black tabular-nums ${b > 0 ? 'text-emerald-300' : b < 0 ? 'text-rose-300' : 'text-slate-400'}`}>
                    {st ? fmt(Math.abs(b)) : '—'} <span className="text-[11px]">{cur()}</span>
                  </p>
                  <p className="text-[11px] font-bold text-slate-500">{balLabel(b)}</p>
                </div>
              </div>
              <div className="mt-3 grid grid-cols-3 gap-2 rounded-2xl border border-white/[0.06] bg-black/20 p-2.5 text-center">
                <div>
                  <p className="text-[10px] font-bold text-slate-500">{tr('حوالاتك عبره')}</p>
                  <p className="font-display text-[13.5px] font-black tabular-nums text-rose-200">{fmt(x.outD + x.outP)}</p>
                  {x.outP ? <p className="text-[9.5px] font-bold text-amber-200/80">{tr('منها {n} لم تُسلَّم', { n: fmt(x.outP) })}</p> : null}
                </div>
                <div>
                  <p className="text-[10px] font-bold text-slate-500">{tr('حوالاته عبرك')}</p>
                  <p className="font-display text-[13.5px] font-black tabular-nums text-emerald-200">{fmt(x.inD + x.inP)}</p>
                  {x.inP ? <p className="text-[9.5px] font-bold text-amber-200/80">{tr('منها {n} لم تُسلَّم', { n: fmt(x.inP) })}</p> : null}
                </div>
                <div>
                  <p className="text-[10px] font-bold text-slate-500">{tr('دفعات مؤكدة')}</p>
                  <p className="font-display text-[13.5px] font-black tabular-nums text-white">{fmt(x.iPaid + x.hePaid)}</p>
                </div>
              </div>
              {waiting ? (
                <p className="mt-2 flex items-center gap-1.5 text-[11.5px] font-extrabold text-amber-200"><Clock size={12} />{tr('{n} دفعة بانتظار تأكيدك (أعلى الصفحة)', { n: waiting })}</p>
              ) : null}
              <div className="mt-3 grid grid-cols-2 gap-2">
                <button type="button" onClick={() => setOpen({ ...p, name })} className="inline-flex min-h-[42px] items-center justify-center gap-1.5 rounded-xl border border-white/12 bg-white/[0.04] px-3 text-[12px] font-extrabold text-slate-200 hover:bg-white/[0.08]">
                  <FileText size={14} />{tr('كشف الحساب')}
                </button>
                <button type="button" onClick={() => setPay((v) => (v === p.userId ? null : p.userId))} className="inline-flex min-h-[42px] items-center justify-center gap-1.5 rounded-xl border border-amber-300/40 bg-amber-400/15 px-3 text-[12px] font-extrabold text-amber-100 hover:bg-amber-400/25">
                  {pay === p.userId ? <X size={14} /> : <Wallet size={14} />}{pay === p.userId ? tr('إغلاق') : tr('تسجيل دفعة')}
                </button>
              </div>
              {pay === p.userId ? <PaymentForm partner={{ ...p, name }} balance={b} onDone={() => setPay(null)} /> : null}
            </Card>
          )
        })}
      </div>
      {open ? <Statement partner={open} onClose={() => setOpen(null)} /> : null}
    </div>
  )
}

/** دفعة نقدية بين الشريكين — لا تُحتسب إلا بعد تأكيد الطرف الآخر */
function PaymentForm({ partner, balance, onDone }) {
  const toast = useToast()
  const ask = useConfirm()
  const { gid, userId, myName } = useLy()
  const [kind, setKind] = useState(balance > 0 ? 'got' : 'paid')
  const [amt, setAmt] = useState('')
  const [note, setNote] = useState('')
  const [busy, setBusy] = useState(false)

  async function submit() {
    const val = Math.round(Number(amt) || 0)
    if (val <= 0) return toast(tr('أدخل مبلغاً صحيحاً'), 'err')
    if (!gid || !userId) return toast(tr('تعذّر تجهيز الجلسة، أعد المحاولة'), 'err')
    const what = kind === 'paid'
      ? tr('دفعت {amount} إلى {name}', { amount: `${fmt(val)} ${cur()}`, name: partner.name })
      : tr('استلمت {amount} من {name}', { amount: `${fmt(val)} ${cur()}`, name: partner.name })
    const ok = await ask({
      title: what,
      text: tr('تُرسل لـ{name} ليؤكدها. لا تدخل في الرصيد إلا بعد تأكيده، ولا تُعدَّل بعده.', { name: partner.name }),
      confirmLabel: tr('إرسال للتأكيد'),
      danger: false,
      icon: Wallet,
    })
    if (!ok) return
    setBusy(true)
    try {
      await db.insertShared(
        PSET,
        {
          fromUserId: userId, fromName: myName, toUserId: partner.userId, toName: partner.name,
          payerId: kind === 'paid' ? userId : partner.userId,
          amount: val, note: note.trim(), status: 'pending', date: new Date().toISOString(),
        },
        rid('ps'),
        { groupId: gid, visibleTo: `user:${partner.userId}`, writableBy: `user:${partner.userId}`, writableFields: ['status'] },
      )
      notify(
        partner.userId,
        '⚖️ دفعة مقاصة بانتظار تأكيدك',
        `${myName} ${kind === 'paid' ? 'يقول إنه دفع لك' : 'يقول إنه استلم منك'} ${fmt(val)} د.ل — افتح المقاصة للتأكيد أو الرفض.`,
        '#/ly/clear',
      )
      toast(tr('أُرسلت الدفعة للتأكيد'))
      onDone?.()
    } catch (e) {
      toast(e?.message || tr('تعذّر تسجيل العملية'), 'err')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="rise mt-3 space-y-3 rounded-2xl border border-white/[0.07] bg-black/20 p-3">
      <Segmented
        value={kind}
        onChange={setKind}
        options={[
          { value: 'paid', label: tr('دفعت له') },
          { value: 'got', label: tr('استلمت منه') },
        ]}
      />
      <div className="grid gap-2 sm:grid-cols-2">
        <MoneyInput value={amt} onChange={setAmt} placeholder={balance ? fmt(Math.abs(balance)) : '1,000'} className={`${fieldCls} font-display text-[17px]`} />
        <input value={note} onChange={(e) => setNote(e.target.value)} className={fieldCls} placeholder={tr('ملاحظة (اختياري)')} />
      </div>
      <button type="button" disabled={busy} onClick={submit} className="min-h-[46px] w-full rounded-xl bg-amber-400 px-4 text-[13px] font-extrabold text-[#1a1206] hover:bg-amber-300 disabled:opacity-50">
        {busy ? tr('جارٍ...') : tr('إرسال للتأكيد')}
      </button>
      <p className="text-[11px] leading-relaxed text-slate-500">{tr('لا تُحتسب الدفعة إلا بعد أن يؤكدها الطرف الآخر من جهازه.')}</p>
    </div>
  )
}

/** دفعات تنتظر قرارك، ودفعات أرسلتها وتنتظر الطرف الآخر */
function PendingSettlements() {
  const d = useLyData()
  const toast = useToast()
  const ask = useConfirm()
  const { myName } = useLy()
  const [busy, setBusy] = useState(null)
  const inc = d.psIn.filter((s) => s.status === 'pending')
  const out = d.psOut.filter((s) => s.status === 'pending')
  if (!inc.length && !out.length) return null

  async function decide(s, status) {
    const amount = `${fmt(s.amount)} ${cur()}`
    const ok = await ask({
      title: status === 'confirmed' ? tr('تأكيد الدفعة؟') : tr('رفض الدفعة؟'),
      text: status === 'confirmed' ? tr('بعد التأكيد تدخل {amount} في الرصيد المشترك ولا يمكن التراجع.', { amount }) : amount,
      confirmLabel: status === 'confirmed' ? tr('تأكيد') : tr('رفض'),
      danger: status !== 'confirmed',
      icon: status === 'confirmed' ? CheckCircle2 : XCircle,
    })
    if (!ok) return
    setBusy(s.id)
    try {
      await db.updateShared(PSET, s.id, { status }, { expect: { status: 'pending' } })
      notify(
        s.fromUserId,
        status === 'confirmed' ? '✅ تم تأكيد دفعة المقاصة' : '⛔ رُفضت دفعة المقاصة',
        `${myName}: ${fmt(s.amount)} د.ل`,
        '#/ly/clear',
      )
      toast(status === 'confirmed' ? tr('تم تأكيد الدفعة') : tr('تم رفض الدفعة'))
    } catch (e) {
      toast(isExpect(e) ? tr('هذه الدفعة لم تعد بانتظار التأكيد') : e?.message || tr('تعذّر تسجيل العملية'), 'err')
    } finally {
      setBusy(null)
    }
  }
  async function withdraw(s) {
    const ok = await ask({ title: tr('سحب الدفعة؟'), text: `${fmt(s.amount)} ${cur()} · ${s.toName || ''}`, confirmLabel: tr('سحب'), icon: XCircle })
    if (!ok) return
    setBusy(s.id)
    try {
      await db.updateShared(PSET, s.id, { status: 'withdrawn' }, { expect: { status: 'pending' } })
      toast(tr('تم سحب الدفعة'))
    } catch (e) {
      toast(isExpect(e) ? tr('هذه الدفعة لم تعد بانتظار التأكيد') : e?.message || tr('تعذّر تسجيل العملية'), 'err')
    } finally {
      setBusy(null)
    }
  }

  return (
    <div className="space-y-2">
      {inc.map((s) => (
        <Card key={s.id} className="rise border-amber-300/30 bg-amber-400/[0.06] p-4">
          <p className="flex items-center gap-1.5 text-[11.5px] font-extrabold text-amber-200"><Wallet size={13} />{tr('دفعة بانتظار تأكيدك')}</p>
          <p className="mt-1 text-[14px] font-extrabold text-white">
            {s.fromName} {s.payerId === s.fromUserId ? tr('يقول إنه دفع لك') : tr('يقول إنه استلم منك')}{' '}
            <span className="font-display tabular-nums text-amber-100">{fmt(s.amount)} {cur()}</span>
          </p>
          <p className="text-[11.5px] text-slate-400">{when(s.date)}{s.note ? ` · ${s.note}` : ''}</p>
          <div className="mt-3 flex gap-2">
            <button type="button" disabled={busy === s.id} onClick={() => decide(s, 'rejected')} className="min-h-[42px] flex-1 rounded-xl border border-white/12 bg-white/[0.04] text-[12.5px] font-extrabold text-slate-300 hover:bg-white/[0.08] disabled:opacity-50">{tr('رفض')}</button>
            <button type="button" disabled={busy === s.id} onClick={() => decide(s, 'confirmed')} className="inline-flex min-h-[42px] flex-1 items-center justify-center gap-1.5 rounded-xl bg-emerald-500 text-[12.5px] font-extrabold text-emerald-950 hover:bg-emerald-400 disabled:opacity-50"><CheckCircle2 size={15} />{tr('تأكيد')}</button>
          </div>
        </Card>
      ))}
      {out.map((s) => (
        <Card key={s.id} className="flex flex-wrap items-center justify-between gap-3 p-3.5">
          <div className="min-w-0">
            <p className="text-[13px] font-extrabold text-white">
              {s.payerId === s.fromUserId ? tr('دفعت لـ{name}', { name: s.toName || '' }) : tr('استلمت من {name}', { name: s.toName || '' })}{' '}
              <span className="font-display tabular-nums">{fmt(s.amount)} {cur()}</span>
            </p>
            <span className="mt-1 inline-flex items-center gap-1 rounded-full border border-amber-400/30 bg-amber-500/10 px-2 py-[2px] text-[10.5px] font-extrabold text-amber-200"><Clock size={11} />{tr('بانتظار تأكيده')}</span>
          </div>
          <button type="button" disabled={busy === s.id} onClick={() => withdraw(s)} className="min-h-[40px] rounded-xl border border-white/12 bg-white/[0.04] px-3 text-[12px] font-extrabold text-slate-300 hover:bg-white/[0.08] disabled:opacity-50">{tr('سحب')}</button>
        </Card>
      ))}
    </div>
  )
}

/** كشف حساب مفصّل مع شريك — نفس السجل يظهر عند الطرفين */
function Statement({ partner, onClose }) {
  const toast = useToast()
  const { userId, myName } = useLy()
  const [rows, setRows] = useState(null)
  const [err, setErr] = useState(false)

  useEffect(() => {
    let off = false
    const P = partner.userId
    Promise.all([
      db.selectAllShared(LINK, { fromUserId: userId, toUserId: P }),
      db.selectAllShared(LINK, { fromUserId: P, toUserId: userId }),
      db.selectAllShared(PSET, { fromUserId: userId, toUserId: P }),
      db.selectAllShared(PSET, { fromUserId: P, toUserId: userId }),
    ])
      .then(([mine, his, s1, s2]) => {
        if (off) return
        const list = []
        for (const l of mine || []) list.push({ id: l.id, date: l.date, kind: 'out', title: tr('حوالتك عبره إلى {name}', { name: l.recvName }), amount: -Number(l.deliver || 0), status: l.status, counts: l.status !== 'cancelled', at: l.deliveredAt || l.cancelledAt })
        for (const l of his || []) list.push({ id: l.id, date: l.date, kind: 'in', title: tr('حوالته عبرك إلى {name}', { name: l.recvName }), amount: Number(l.deliver || 0), status: l.status, counts: l.status !== 'cancelled', at: l.deliveredAt || l.cancelledAt })
        for (const s of [...(s1 || []), ...(s2 || [])]) {
          const iPaid = s.payerId === userId
          list.push({ id: s.id, date: s.date, kind: 'pay', title: iPaid ? tr('دفعة: دفعت له') : tr('دفعة: استلمت منه'), note: s.note, amount: iPaid ? Number(s.amount || 0) : -Number(s.amount || 0), status: s.status, counts: s.status === 'confirmed', at: s.respondedAt })
        }
        list.sort((a, b) => String(a.date || '').localeCompare(String(b.date || '')))
        let run = 0
        for (const e of list) {
          if (e.counts) run += e.amount
          e.run = run
        }
        setRows(list.reverse())
      })
      .catch(() => { if (!off) setErr(true) })
    return () => { off = true }
  }, [partner.userId, userId])

  const total = rows?.length ? rows[0].run : 0
  const statusLabel = (e) => {
    if (e.kind === 'pay') return { confirmed: tr('مؤكدة'), pending: tr('بانتظار التأكيد'), rejected: tr('مرفوضة'), withdrawn: tr('مسحوبة') }[e.status] || e.status
    return { delivered: tr('مسلّمة'), pending: tr('لم تُسلَّم'), cancelled: tr('ملغاة') }[e.status] || e.status
  }

  function summaryText() {
    const lines = [
      `${tr('كشف حساب')}: ${myName} ↔ ${partner.name}`,
      `${tr('الرصيد')}: ${fmt(Math.abs(total))} ${cur()} — ${total > 0 ? `${tr('لي عند')} ${partner.name}` : total < 0 ? `${tr('لـ')}${partner.name} ${tr('عندي')}` : tr('متصافي')}`,
      '—',
      ...(rows || []).slice(0, 40).map((e) => `${when(e.date)} · ${e.title} · ${e.amount > 0 ? '+' : '−'}${fmt(Math.abs(e.amount))} · ${statusLabel(e)}`),
      '—',
      `${tr('نفس الكشف موجود عند الطرفين في تطبيق الأقدالي للتقنية')}: ${APP_LINK}`,
    ]
    return lines.join('\n')
  }

  return (
    <div className="fixed inset-0 z-[35] flex items-end justify-center bg-[#02050c]/75 backdrop-blur-md md:items-center md:p-6" onClick={onClose} role="dialog" aria-modal="true">
      <div
        onClick={(e) => e.stopPropagation()}
        className="rise flex max-h-[88%] w-full max-w-2xl flex-col overflow-hidden rounded-t-[1.75rem] border border-white/10 bg-gradient-to-b from-[#0f1a2e] to-[#070d1a] text-slate-100 md:rounded-[1.75rem]"
      >
        <div className="flex items-start justify-between gap-3 border-b border-white/[0.07] p-4 md:p-5">
          <div className="min-w-0">
            <p className="flex items-center gap-1.5 text-[11px] font-extrabold tracking-wider text-amber-300/80"><FileText size={13} />{tr('كشف الحساب')}</p>
            <p className="font-display truncate text-[18px] font-black text-white">{partner.name}</p>
            <p className={`font-display mt-1 text-[22px] font-black tabular-nums ${total > 0 ? 'text-emerald-300' : total < 0 ? 'text-rose-300' : 'text-slate-400'}`}>
              {rows ? fmt(Math.abs(total)) : '—'} <span className="text-[12px]">{cur()}</span>
              <span className="ms-2 text-[12px] font-bold text-slate-400">{balLabel(total)}</span>
            </p>
          </div>
          <button type="button" onClick={onClose} aria-label={tr('إغلاق')} className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-white/10 bg-white/[0.05] text-slate-300 hover:bg-white/[0.1]"><X size={18} /></button>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto p-4 md:p-5">
          {err ? (
            <p className="py-10 text-center text-[12.5px] text-rose-300">{tr('تعذّر تحميل كشف الحساب')}</p>
          ) : !rows ? (
            <p className="py-10 text-center text-[12px] text-slate-500">{tr('جارٍ...')}</p>
          ) : !rows.length ? (
            <p className="py-10 text-center text-[12px] text-slate-500">{tr('لا توجد عمليات بعد')}</p>
          ) : (
            <div className="space-y-2">
              {rows.map((e) => (
                <div key={e.id} className={`flex items-center justify-between gap-3 rounded-2xl border border-white/[0.06] bg-white/[0.02] px-3.5 py-3 ${e.counts ? '' : 'opacity-50'}`}>
                  <div className="min-w-0">
                    <p className="truncate text-[13px] font-extrabold text-white">{e.title}</p>
                    <p className="text-[11px] text-slate-500">
                      {when(e.date)} · {statusLabel(e)}{e.at && e.status !== 'pending' ? ` ${when(e.at)}` : ''}{e.note ? ` · ${e.note}` : ''}
                    </p>
                  </div>
                  <div className="shrink-0 text-end">
                    <p className={`font-display text-[15px] font-black tabular-nums ${e.amount > 0 ? 'text-emerald-300' : 'text-rose-300'} ${e.counts ? '' : 'line-through'}`}>
                      {e.amount > 0 ? '+' : '−'}{fmt(Math.abs(e.amount))}
                    </p>
                    <p className="text-[10.5px] font-bold tabular-nums text-slate-500">{tr('الرصيد')} {e.run >= 0 ? '' : '−'}{fmt(Math.abs(e.run))}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        <div className="flex gap-2 border-t border-white/[0.07] p-3 pb-[calc(env(safe-area-inset-bottom,0px)+12px)] md:pb-3">
          <button type="button" disabled={!rows} onClick={() => share.whatsapp(lyPhone(partner.phone), summaryText())} className="inline-flex min-h-[46px] flex-1 items-center justify-center gap-2 rounded-xl bg-emerald-500 text-[13px] font-extrabold text-emerald-950 hover:bg-emerald-400 disabled:opacity-50">
            <MessageCircle size={16} />{tr('إرسال الكشف عبر واتساب')}
          </button>
          <GhostBtn onClick={() => share.copy(summaryText()).then((ok) => ok && toast(tr('تم النسخ')))}>
            <span className="inline-flex items-center gap-1.5"><Copy size={14} />{tr('نسخ')}</span>
          </GhostBtn>
        </div>
      </div>
    </div>
  )
}

/* ───────────────────────── المكاتب والشراكات ───────────────────────── */
function AddOfficeForm({ onClose }) {
  const toast = useToast()
  const { ws, gid, writeOpts } = useLy()
  const [f, setF] = useState({ name: '', city: '', phone: '' })
  const [busy, setBusy] = useState(false)
  async function add() {
    if (!f.name.trim()) return toast(tr('اكتب اسم المكتب'), 'err')
    if (!gid) return toast(tr('تعذّر تجهيز الجلسة، أعد المحاولة'), 'err')
    setBusy(true)
    try {
      await db.insertShared(OFF, { ws, name: f.name.trim(), city: f.city.trim(), phone: f.phone.trim() }, rid('of'), writeOpts)
      setF({ name: '', city: '', phone: '' })
      toast(tr('تمت إضافة المكتب'))
      onClose()
    } catch (e) {
      toast(e?.message || tr('تعذّر تسجيل العملية'), 'err')
    } finally {
      setBusy(false)
    }
  }
  return (
    <div className="space-y-3">
      <div className="grid gap-3 md:grid-cols-3">
        <Field label={tr('اسم المكتب')}><input value={f.name} onChange={(e) => setF((x) => ({ ...x, name: e.target.value }))} className={fieldCls} /></Field>
        <Field label={tr('المدينة')}><input value={f.city} onChange={(e) => setF((x) => ({ ...x, city: e.target.value }))} className={fieldCls} placeholder={tr('طرابلس')} /></Field>
        <Field label={tr('الهاتف')}><input value={f.phone} onChange={(e) => setF((x) => ({ ...x, phone: e.target.value }))} inputMode="tel" dir="ltr" className={fieldCls} placeholder="09x xxx xxxx" /></Field>
      </div>
      <PrimaryBtn onClick={add} disabled={busy}>
        <span className="inline-flex items-center gap-2"><Plus size={16} />{busy ? tr('جارٍ الحفظ...') : tr('حفظ المكتب')}</span>
      </PrimaryBtn>
    </div>
  )
}

function OfficeCard({ o, waiting }) {
  const toast = useToast()
  const ask = useConfirm()
  const { ws } = useLy()
  const [req, setReq] = useState(false)
  async function remove() {
    // مكتب خارج التطبيق له حوالات: حذفه يُخفي حسابه من المقاصة — ممنوع
    if (!o.linkedUserId) {
      const n = await db.countShared(TX, { ws, officeId: o.id, status: { in: ['pending', 'delivered'] } }).catch(() => null)
      if (n === null) return toast(tr('تعذّر تسجيل العملية'), 'err')
      if (n > 0) return toast(tr('لا يمكن حذف مكتب له حوالات مسجّلة — حسابه محفوظ في المقاصة'), 'err')
    }
    const ok = await ask({
      title: tr('حذف المكتب من الدليل؟'),
      text: o.linkedUserId ? `${o.name} — ${tr('الحساب المشترك معه يبقى ظاهراً في المقاصة.')}` : o.name,
      confirmLabel: tr('حذف'),
    })
    if (!ok) return
    try {
      // الشريك يُخفى فقط: الحذف الكامل كان يجعل الربط التلقائي يعيده من جديد
      if (o.linkedUserId) await db.updateShared(OFF, o.id, { hidden: true })
      else await db.deleteShared(OFF, o.id)
      toast(tr('تم حذف المكتب من الدليل'))
    } catch (e) {
      toast(e?.message || tr('تعذّر تسجيل العملية'), 'err')
    }
  }
  return (
    <Card className="p-3.5">
      <div className="flex items-center justify-between gap-3">
        <div className="min-w-0">
          <p className="font-display flex flex-wrap items-center gap-1.5 text-[14.5px] font-extrabold text-white">
            <span className="truncate">{o.name}</span>
            {o.linkedUserId ? (
              <span className="inline-flex items-center gap-1 rounded-full border border-emerald-400/30 bg-emerald-500/10 px-2 py-[1px] text-[10px] font-extrabold text-emerald-200"><Handshake size={10} />{tr('شريك')}</span>
            ) : waiting ? (
              <span className="inline-flex items-center gap-1 rounded-full border border-amber-400/30 bg-amber-500/10 px-2 py-[1px] text-[10px] font-extrabold text-amber-200"><Clock size={10} />{tr('بانتظار موافقته')}</span>
            ) : null}
          </p>
          <p className="truncate text-[11.5px] text-slate-500">{[o.city, o.phone].filter(Boolean).join(' · ') || '—'}</p>
        </div>
        <div className="flex shrink-0 gap-2">
          {!o.linkedUserId && !waiting && !req ? (
            <button type="button" onClick={() => setReq(true)} className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-sky-400/25 bg-sky-500/10 px-3 text-[12px] font-extrabold text-sky-200 hover:bg-sky-500/20">
              <Handshake size={14} />{tr('طلب شراكة')}
            </button>
          ) : null}
          {o.phone ? (
            <button type="button" onClick={() => share.whatsapp(lyPhone(o.phone), '')} aria-label="WhatsApp" className="flex h-10 w-10 items-center justify-center rounded-xl border border-emerald-400/25 bg-emerald-500/10 text-emerald-200 hover:bg-emerald-500/20">
              <MessageCircle size={15} />
            </button>
          ) : null}
          <button type="button" onClick={remove} aria-label={tr('حذف')} className="flex h-10 w-10 items-center justify-center rounded-xl border border-rose-400/25 bg-rose-500/10 text-rose-200 hover:bg-rose-500/20">
            <Trash2 size={15} />
          </button>
        </div>
      </div>
      {req ? <PartnerForm compact fromOfficeId={o.id} onClose={() => setReq(false)} /> : null}
    </Card>
  )
}

function Directory() {
  const d = useLyData()
  const location = useLocation()
  // رابط دعوة فيه كود مكتب (?partner=CODE) → يفتح نموذج الشراكة جاهزاً
  const invited = useMemo(() => {
    try { return normCode(new URLSearchParams(location.search).get('partner') || '').slice(0, 8) } catch { return '' }
  }, [location.search])
  const [panel, setPanel] = useState(() => (invited ? 'partner' : null)) // 'add' | 'partner' | null
  const toggle = (p) => setPanel((x) => (x === p ? null : p))
  const waitingIds = new Set(d.reqOut.filter((r) => r.status === 'pending' && r.fromOfficeId).map((r) => r.fromOfficeId))

  const btn = (key, Icon, label, tone) => (
    <button
      type="button"
      onClick={() => toggle(key)}
      className={`flex min-h-[52px] items-center justify-center gap-2 rounded-2xl border px-3 text-[13px] font-extrabold transition active:scale-[0.98] ${
        panel === key ? tone.on : tone.off
      }`}
    >
      {panel === key ? <X size={16} /> : <Icon size={16} />}
      {panel === key ? tr('إغلاق') : label}
    </button>
  )

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-2.5">
        {btn('add', Plus, tr('إضافة مكتب'), { on: 'border-white/15 bg-white/[0.08] text-white', off: 'border-amber-300/30 bg-amber-400/10 text-amber-100 hover:bg-amber-400/20' })}
        {btn('partner', Handshake, tr('طلب شراكة'), { on: 'border-white/15 bg-white/[0.08] text-white', off: 'border-sky-400/30 bg-sky-500/10 text-sky-100 hover:bg-sky-500/20' })}
      </div>
      {panel ? (
        <Card className="rise p-4 md:p-5">
          <p className="font-display mb-3 text-[15px] font-extrabold text-white">{panel === 'add' ? tr('إضافة مكتب') : tr('طلب شراكة')}</p>
          {panel === 'add' ? <AddOfficeForm onClose={() => setPanel(null)} /> : <PartnerForm initialCode={invited} onClose={() => setPanel(null)} />}
        </Card>
      ) : null}

      <PartnerRequests />

      <OfficeNameCard />

      <MyCodeCard />

      <InviteCard />

      {d.offices.length ? (
        <div className="grid gap-2.5 md:grid-cols-2">
          {d.offices.map((o) => <OfficeCard key={o.id} o={o} waiting={waitingIds.has(o.id)} />)}
        </div>
      ) : d.offLoading ? (
        <div className="py-10 text-center text-[12px] text-slate-500">{tr('جارٍ...')}</div>
      ) : (
        <EmptyState icon={Building2} title={tr('لا توجد مكاتب بعد')} text={tr('أضف المكاتب التي تتعامل معها في ليبيا، أو أرسل طلب شراكة لمكتب مشترك في التطبيق.')} />
      )}
    </div>
  )
}

/* ───────────────────────── تفعيل الإشعارات على هذا الجهاز ───────────────────────── */
function NotifyCard() {
  const toast = useToast()
  const { userId } = useLy()
  const { prefs } = useNotifyPrefs(userId)
  const [perm, setPerm] = useState(() => push.getPermission())
  const [busy, setBusy] = useState(false)
  // المستخدم أوقف الإشعارات بنفسه من الإعدادات → لا نزعجه بالبطاقة
  if (perm === 'granted' || !prefs || (prefs.ops === false && prefs.sec === false)) return null

  async function enable() {
    if (busy) return
    const diag = push.diagnose()
    if (!diag.canSchedule) {
      toast(diag.hint || tr('الإشعارات لا تعمل في المعاينة — جرّبها من التطبيق المنشور'), 'info')
      return
    }
    setBusy(true)
    try {
      const p = await push.requestPermission()
      setPerm(p)
      if (p !== 'granted') {
        toast(tr('لم يتم السماح بالإشعارات'), 'err')
        return
      }
      await push.subscribe()
      const res = await push.send(null, { title: '✅ ALEGDALY TECH', body: 'إشعارات قسم ليبيا تعمل على هذا الجهاز', url: '#/ly' })
      toast(res?.sent > 0 ? tr('تم تفعيل الإشعارات على هذا الجهاز') : tr('تم السماح، لكن لم يصل إشعار التجربة'), res?.sent > 0 ? undefined : 'info')
    } catch (e) {
      toast(e?.message || tr('حدث خطأ، حاول مرة أخرى'), 'err')
    } finally {
      setBusy(false)
    }
  }

  return (
    <Card className="rise flex flex-wrap items-center gap-3 border-amber-300/25 bg-amber-400/[0.05] p-4">
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-amber-400/15 text-amber-200"><BellRing size={19} /></span>
      <div className="min-w-0 flex-1">
        <p className="text-[13.5px] font-extrabold text-white">{tr('فعّل إشعارات الحوالات')}</p>
        <p className="text-[11.5px] leading-relaxed text-slate-400">
          {tr('يصلك تنبيه فوري بكل حوالة واردة، وتسليم، وإلغاء، ورقم سري خاطئ، وطلب شراكة — حتى والتطبيق مغلق.')}
        </p>
      </div>
      <button type="button" disabled={busy} onClick={enable} className="min-h-[44px] shrink-0 rounded-xl bg-amber-400 px-4 text-[13px] font-extrabold text-[#1a1206] hover:bg-amber-300 disabled:opacity-50">
        {busy ? tr('جارٍ...') : tr('تفعيل')}
      </button>
    </Card>
  )
}

/* ───────────────────────── الرئيسية ───────────────────────── */
function Overview({ go }) {
  const d = useLyData()
  const { ws } = useLy()
  const pendingRows = d.rows.filter((t) => t.status === 'pending' && !(t.linkId && d.linkMap[t.linkId]?.status === 'delivered'))
  return (
    <div className="space-y-5">
      <NotifyCard />
      {d.inPending || d.reqPending || d.psPending ? (
        <div className="grid gap-2.5 md:grid-cols-2">
          {d.psPending ? (
            <button type="button" onClick={() => go('clear')} className="rise flex items-center gap-3 rounded-2xl border border-emerald-400/30 bg-emerald-500/10 px-4 py-3.5 text-start text-[13px] font-extrabold text-emerald-100 hover:bg-emerald-500/20">
              <Wallet size={18} className="shrink-0" />
              <span className="flex-1">{tr('لديك {n} دفعة مقاصة بانتظار تأكيدك', { n: d.psPending })}</span>
              <ChevronLeft size={16} className="ltr:rotate-180" />
            </button>
          ) : null}
          {d.inPending ? (
            <button type="button" onClick={() => go('in')} className="rise flex items-center gap-3 rounded-2xl border border-sky-400/30 bg-sky-500/10 px-4 py-3.5 text-start text-[13px] font-extrabold text-sky-100 hover:bg-sky-500/20">
              <Inbox size={18} className="shrink-0" />
              <span className="flex-1">{tr('لديك {n} حوالة واردة بانتظار التسليم', { n: d.inPending })}</span>
              <ChevronLeft size={16} className="ltr:rotate-180" />
            </button>
          ) : null}
          {d.reqPending ? (
            <button type="button" onClick={() => go('offices')} className="rise flex items-center gap-3 rounded-2xl border border-amber-300/30 bg-amber-400/10 px-4 py-3.5 text-start text-[13px] font-extrabold text-amber-100 hover:bg-amber-400/20">
              <Handshake size={18} className="shrink-0" />
              <span className="flex-1">{tr('لديك {n} طلب شراكة جديد', { n: d.reqPending })}</span>
              <ChevronLeft size={16} className="ltr:rotate-180" />
            </button>
          ) : null}
        </div>
      ) : null}

      <div className="grid grid-cols-2 gap-3">
        <button type="button" onClick={() => go('new')} className="rise group relative overflow-hidden rounded-3xl bg-gradient-to-br from-amber-300 to-amber-500 p-4 text-start text-[#1a1206] shadow-[0_18px_40px_-18px_rgba(251,191,36,0.9)] transition active:scale-[0.98] md:p-5">
          <span className="pointer-events-none absolute -bottom-8 -end-8 h-28 w-28 rounded-full bg-white/25 blur-2xl" />
          <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-[#1a1206]/10"><Plus size={20} /></span>
          <p className="font-display mt-3 text-[16px] font-black">{tr('حوالة جديدة')}</p>
          <p className="text-[11px] font-bold opacity-70">{tr('سجّل وأرسل الرقم السري')}</p>
        </button>
        <button type="button" onClick={() => go('in')} className="rise relative rounded-3xl border border-sky-400/25 bg-sky-500/[0.07] p-4 text-start transition hover:bg-sky-500/[0.12] active:scale-[0.98] md:p-5">
          <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-sky-500/15 text-sky-200"><Inbox size={20} /></span>
          <p className="font-display mt-3 text-[16px] font-black text-white">{tr('الواردة')}</p>
          <p className="text-[11px] font-bold text-sky-200/70">{d.inPending ? tr('{n} بانتظار التسليم', { n: d.inPending }) : tr('من المكاتب الشريكة')}</p>
        </button>
      </div>

      <Profits ws={ws} version={d.version} />

      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <p className="font-display text-[15px] font-extrabold text-white">{tr('بانتظار التسليم')}</p>
          {d.rows.length ? (
            <button type="button" onClick={() => go('list')} className="text-[12px] font-extrabold text-amber-200 hover:text-amber-100">{tr('عرض الكل')}</button>
          ) : null}
        </div>
        {pendingRows.length ? (
          <div className="grid gap-3 lg:grid-cols-2">
            {pendingRows.slice(0, 4).map((t) => <TransferRow key={t.id} t={t} link={t.linkId ? d.linkMap[t.linkId] : null} />)}
          </div>
        ) : (
          <p className="rounded-2xl border border-dashed border-white/10 px-4 py-6 text-center text-[12.5px] text-slate-500">
            {d.loading ? tr('جارٍ...') : tr('لا توجد حوالات بانتظار التسليم')}
          </p>
        )}
      </div>
    </div>
  )
}

/* ───────────────────────── الصفحة ───────────────────────── */
const TITLES = {
  home: 'حوالات ليبيا · دينار',
  list: 'الحوالات',
  new: 'حوالة جديدة',
  in: 'الحوالات الواردة',
  clear: 'المقاصة',
  offices: 'المكاتب والشراكات',
}

export default function Libya() {
  const params = useParams()
  const tab = TITLES[params.tab] ? params.tab : 'home'
  const d = useLyData()
  const { gid } = useLy()
  const navigate = useNavigate()
  const go = (t) => navigate(t === 'home' ? '/ly' : `/ly/${t}`)
  // عند كل انتقال بين صفحات القسم: قراءة جديدة للحوالات حتى لا تبقى قائمة قديمة
  const firstTab = useRef(true)
  const refreshAll = d?.refreshAll
  useEffect(() => {
    if (firstTab.current) { firstTab.current = false; return }
    refreshAll?.()
  }, [tab]) // eslint-disable-line react-hooks/exhaustive-deps
  // إغلاق صفحة الحوالة الجديدة: يرجع للصفحة السابقة داخل قسم ليبيا، وإلا لرئيسية القسم
  const closeNew = () => {
    if ((window.history.state?.idx || 0) > 0) navigate(-1)
    else go('home')
  }

  if (!d) return null

  return (
    <div className="space-y-5">
      <div className={`rise flex items-end justify-between gap-3 ${tab === 'new' ? 'sticky top-0 z-20 -mx-4 bg-[rgb(var(--color-bg)/0.95)] px-4 py-2 backdrop-blur md:-mx-8 md:px-8' : ''}`}>
        <div className="min-w-0">
          <p className="flex items-center gap-1.5 text-[11px] font-bold tracking-[0.18em] text-amber-300/80"><Landmark size={13} />LYD · {tr('قسم ليبيا')}</p>
          <h1 className="font-display truncate text-[24px] font-extrabold tracking-tight text-white md:text-[28px]">{tr(TITLES[tab])}</h1>
          {tab === 'home' ? <p className="mt-1 text-[12px] text-slate-500">{tr('قسم مستقل بالدينار، لا يختلط بالفرنك ولا بأرصدة NITA وAMANA.')}</p> : null}
        </div>
        {tab === 'new' ? (
          <button
            type="button"
            onClick={closeNew}
            aria-label={tr('إغلاق')}
            className="grid h-11 w-11 shrink-0 place-items-center rounded-full border border-amber-300/30 bg-amber-400/10 text-amber-200 transition hover:bg-amber-400/20 active:scale-95"
          >
            <X size={20} strokeWidth={2.5} />
          </button>
        ) : null}
        {tab !== 'new' ? (
          <button type="button" onClick={() => go('new')} className="hidden min-h-[44px] shrink-0 items-center gap-2 rounded-xl bg-amber-400 px-4 text-[13px] font-extrabold text-[#1a1206] hover:bg-amber-300 md:inline-flex">
            <Plus size={16} />{tr('حوالة جديدة')}
          </button>
        ) : null}
      </div>

      {!gid ? (
        <EmptyState icon={Landmark} title={tr('تعذّر تجهيز الجلسة، أعد المحاولة')} />
      ) : (
        <>
          {tab === 'home' && <Overview go={go} />}
          {tab === 'list' && <TransferList rows={d.rows} loading={d.loading} goNew={() => go('new')} linkMap={d.linkMap} />}
          {tab === 'in' && <IncomingList rows={d.incoming} loading={d.inLoading} />}
          {tab === 'new' && <NewTransfer offices={d.offices} goOffices={() => go('offices')} onDone={() => go('list')} />}
          {tab === 'clear' && <Clearing offices={d.offices} version={d.version} setsVersion={d.setsVersion} />}
          {tab === 'offices' && <Directory />}
        </>
      )}
    </div>
  )
}
