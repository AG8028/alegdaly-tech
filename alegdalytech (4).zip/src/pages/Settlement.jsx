import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { HandCoins, Wallet, Users } from 'lucide-react'
import { db } from '../lib/db'
import { useLiveShared } from '../lib/useLive'
import { useSession } from '../components/Session'
import { Card, Field, PrimaryBtn, fieldCls, useToast, SectionTitle } from '../components/ui'
import { fmt, todayKey } from '../components/fees'
import { useAgentStats } from '../hooks/useAgentStats'
import { tr } from '../components/i18n'
import MoneyInput from '../components/MoneyInput'
import { scopeFilter } from '../components/scope'

export default function Settlement() {
  const session = useSession()
  const toast = useToast()
  const navigate = useNavigate()
  const { canManage, roster, gid, user } = session

  const [agentId, setAgentId] = useState(session.selectedAgentId || '')
  const [amount, setAmount] = useState('')
  const [note, setNote] = useState('')
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (canManage) {
      if (!agentId && roster.length) setAgentId(roster[0].userId)
    } else if (user?.id) {
      setAgentId(user.id)
    }
  }, [canManage, roster, user, agentId])

  const { data: live } = useLiveShared(session.txColl, { order: '-createdAt', limit: 30, filters: scopeFilter(session, agentId || null) })
  const version = useMemo(() => (live || []).map((r) => `${r.id}:${r.updatedAt || ''}`).join('|'), [live])
  const stats = useAgentStats(agentId || null, version)
  const agent = roster.find((a) => a.userId === agentId) || null

  async function save() {
    const amt = Number(amount)
    if (!agentId) return toast(tr('اختر الوكيل أولاً'), 'err')
    if (!amt || amt <= 0) return toast(tr('أدخل مبلغاً صحيحاً'), 'err')
    if (!gid) return toast(tr('تعذّر تجهيز الجلسة، أعد المحاولة'), 'err')

    setSaving(true)
    try {
      const row = {
        ...session.stamp,
        agentUserId: agentId,
        agentName: agent?.name || '',
        kind: 'cash',
        amount: amt,
        ref: note.trim() || 'تسليم نقدي',
        date: new Date().toISOString(),
        day: todayKey(),
      }
      await db.insertShared(session.txColl, row, undefined, {
        groupId: gid,
        visibleTo: `user:${agentId}`,
        writableBy: 'admins',
      })
      window.dispatchEvent(new Event('tx-saved'))
      setAmount('')
      setNote('')
      toast(tr('تم تسجيل استلام الكاش'))
      navigate('/')
    } catch (e) {
      toast(e?.message || tr('تعذّر تسجيل العملية'), 'err')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="mx-auto max-w-2xl space-y-5">
      <div className="rise">
        <p className="text-[11px] font-bold tracking-[0.18em] text-sky-400/80">{tr('تصفية')}</p>
        <h1 className="font-display text-[24px] font-extrabold tracking-tight text-white md:text-[28px]">{tr('تسليم كاش')}</h1>
      </div>

      <Card className="rise overflow-hidden">
        <div className="flex items-center gap-2 border-b border-white/[0.06] px-4 py-3">
          <Wallet size={14} className="text-emerald-300" />
          <SectionTitle>{tr('الرصيد الحالي بيد {who}', { who: agent?.name || tr('الوكيل') })}</SectionTitle>
        </div>
        <div className="px-4 py-4">
          <p className="font-display text-[30px] font-black leading-none text-white">
            {stats ? fmt(stats.balance) : '—'}
            <span className="ms-2 align-middle text-[12px] font-bold text-emerald-300/70">FCFA</span>
          </p>
        </div>
      </Card>

      <Card className="rise space-y-4 p-4 md:p-6">
        {canManage ? (
          <Field label={tr('الوكيل')}>
            <div className="relative">
              <select value={agentId} onChange={(e) => setAgentId(e.target.value)} className={`${fieldCls} appearance-none`}>
                {roster.length === 0 ? <option value="">{tr('لا يوجد وكلاء')}</option> : null}
                {roster.map((a) => (
                  <option key={a.userId} value={a.userId} className="bg-[#0b1424]">
                    {a.name}
                  </option>
                ))}
              </select>
              <Users size={15} className="pointer-events-none absolute end-3 top-1/2 -translate-y-1/2 text-slate-500" />
            </div>
          </Field>
        ) : null}

        <Field label={tr('المبلغ النقدي المسلّم (FCFA)')}>
          <MoneyInput
            value={amount}
            onChange={setAmount}
            placeholder="100,000"
            className={`${fieldCls} font-display text-[18px]`}
          />
        </Field>

        <Field label={tr('ملاحظة التصفية')}>
          <input value={note} onChange={(e) => setNote(e.target.value)} placeholder={tr('دفعة كاش')} className={fieldCls} />
        </Field>
      </Card>

      <PrimaryBtn onClick={save} disabled={saving || !roster.length} className="!from-sky-500 !to-sky-400 !text-sky-950 !shadow-[0_10px_30px_-12px_rgba(14,165,233,0.9)]">
        <span className="inline-flex items-center gap-2">
          <HandCoins size={16} />
          {tr(saving ? 'جارٍ الحفظ...' : 'تأكيد استلام الكاش')}
        </span>
      </PrimaryBtn>
      <div className="h-2" />
    </div>
  )
}
