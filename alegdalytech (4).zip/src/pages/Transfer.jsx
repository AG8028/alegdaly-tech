import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Send, Calculator, Users, ChevronDown, X, AlertCircle } from 'lucide-react'
import { db } from '../lib/db'
import { useSession } from '../components/Session'
import { Card, Field, PrimaryBtn, Segmented, fieldCls, useToast, SectionTitle } from '../components/ui'
import { TYPES, DIRECTIONS, CUSTOM_RATE, calcFees, calcInclusive, calcDeposit, fmt, todayKey } from '../components/fees'
import { AppFilter } from '../components/brands'
import { tr } from '../components/i18n'
import MoneyInput from '../components/MoneyInput'

const RATE_CHIPS = [
  { value: 250, label: '250' },
  { value: 150, label: '150' },
  { value: CUSTOM_RATE, label: '✎ يدوي' },
]

export default function Transfer() {
  const session = useSession()
  const toast = useToast()
  const navigate = useNavigate()
  const { canManage, roster, gid } = session

  const [agentId, setAgentId] = useState(session.selectedAgentId || '')
  const [direction, setDirection] = useState('out')
  const [app, setApp] = useState('NITA')
  const [type, setType] = useState('code')
  const [rate, setRate] = useState(250)
  const [manualFee, setManualFee] = useState('')
  const [amount, setAmount] = useState('')
  const [ref, setRef] = useState('')
  const [incl, setIncl] = useState(false)
  const [saving, setSaving] = useState(false)
  const [refOpen, setRefOpen] = useState(false)
  const [inclInfo, setInclInfo] = useState(false)
  const hid = (n) => fmt(n)

  useEffect(() => {
    if (canManage) {
      if (!agentId && roster.length) setAgentId(roster[0].userId)
    }
  }, [canManage, roster, agentId])

  const isIn = direction === 'in'
  const isManual = !isIn && rate === CUSTOM_RATE
  const isIncl = !isIn && incl
  const r = useMemo(() => {
    if (isIn) return calcDeposit({ amount, fee: manualFee })
    const rt = isManual ? manualFee : rate
    return isIncl ? calcInclusive({ total: amount, rate: rt, type }) : calcFees({ amount, rate: rt, type })
  }, [amount, rate, type, manualFee, isManual, isIn, isIncl])
  const agent = roster.find((a) => a.userId === agentId) || null

  async function save() {
    const amt = isIncl ? r.amount : Number(amount)
    if (!agentId) return toast(tr('اختر الوكيل أولاً'), 'err')
    if (!Number(amount) || Number(amount) <= 0) return toast(tr('أدخل مبلغاً صحيحاً'), 'err')
    if (isManual && manualFee === '') return toast(tr('أدخل قيمة العمولة لكل 5000'), 'err')
    if (!amt || amt <= 0) return toast(tr('المبلغ لا يكفي للعمولة'), 'err')
    if (!gid) return toast(tr('تعذّر تجهيز الجلسة، أعد المحاولة'), 'err')

    setSaving(true)
    try {
      const row = {
        ...session.stamp,
        agentUserId: agentId,
        agentName: agent?.name || '',
        kind: 'tx',
        direction,
        app,
        type: isIn ? 'deposit' : type,
        rate: isIn ? 0 : isManual ? Number(manualFee) || 0 : Number(rate),
        feeMode: isIn ? 'deposit' : isIncl ? 'inclusive' : 'per5k',
        customFee: isIn ? Number(manualFee) || 0 : 0,
        cashGiven: isIncl ? r.total : 0,
        change: isIncl ? r.change : 0,
        amount: amt,
        ref: ref.trim() || (isIn ? 'إيداع' : 'حوالة'),
        compFee: r.compFee,
        clientFee: r.clientFee,
        cashInHand: r.cashInHand,
        myProfit: r.myProfit,
        date: new Date().toISOString(),
        day: todayKey(),
        enteredBy: 'owner',
      }
      await db.insertShared(session.txColl, row, undefined, { groupId: gid, visibleTo: `user:${agentId}`, writableBy: 'admins' })
      window.dispatchEvent(new Event('tx-saved'))
      setAmount('')
      setRef('')
      setManualFee('')
      setIncl(false)
      setRefOpen(false)
      toast(tr(isIn ? 'تم حفظ الدخول' : 'تم حفظ الحوالة'))
      navigate('/')
    } catch (e) {
      toast(e?.message || tr('تعذّر حفظ الحوالة'), 'err')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="mx-auto max-w-2xl space-y-5">
      <div className="rise flex items-start justify-between gap-3">
        <div>
          <p className="text-[11px] font-bold tracking-[0.18em] text-emerald-400/80">{tr('تسجيل جديد')}</p>
          <h1 className="font-display text-[24px] font-extrabold tracking-tight text-white md:text-[28px]">{tr('حوالة جديدة')}</h1>
        </div>
        <div className="flex shrink-0 items-center gap-2">
        <button
          type="button"
          onClick={() => navigate('/')}
          aria-label="close"
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-white/10 bg-white/[0.04] text-slate-300 transition hover:bg-white/10 active:scale-95"
        >
          <X size={18} />
        </button>
        </div>
      </div>

      <Card className="rise space-y-4 p-4 md:p-6">
        <Field label={tr('الوكيل')}>
          <div className="relative">
            <select value={agentId} onChange={(e) => setAgentId(e.target.value)} className={`${fieldCls} appearance-none`}>
              {roster.length === 0 ? <option value="">{tr('لا يوجد وكلاء')}</option> : null}
              {roster.map((a) => (
                <option key={a.userId} value={a.userId} className="bg-[#0b1424]">
                  {a.name}
                </option>
              ))}
            </select>
            <Users size={15} className="pointer-events-none absolute end-3 top-1/2 -translate-y-1/2 text-slate-500" />
          </div>
        </Field>

        <div>
          <p className="mb-1.5 text-[11.5px] font-bold tracking-wide text-slate-400">{tr('اتجاه الحركة')}</p>
          <div className="grid grid-cols-2 gap-2">
            {DIRECTIONS.map((d) => {
              const active = direction === d.value
              const tone = d.value === 'in' ? 'border-sky-400/60 bg-sky-500/15 text-sky-200' : 'border-rose-400/50 bg-rose-500/15 text-rose-200'
              return (
                <button
                  key={d.value}
                  type="button"
                  onClick={() => {
                    // عمولة الإيداع وقيمة الـ 5000 اليدوية خانتان مختلفتان — لا ننقل الرقم بينهما
                    if (d.value !== direction) setManualFee('')
                    setDirection(d.value)
                  }}
                  className={`rounded-xl border px-2 py-3 text-[12.5px] font-extrabold transition active:scale-[0.98] ${
                    active ? tone : 'border-white/10 bg-black/25 text-slate-400 hover:border-white/20'
                  }`}
                >
                  {tr(d.label)}
                </button>
              )
            })}
          </div>
          <p className="mt-1.5 text-[11px] leading-relaxed text-slate-500">
            {tr(isIn
              ? 'القيمة دخلت حساب التطبيق ودفع الوكيل مقابلها كاشاً — تُخصم من الكاش الذي في يده'
              : 'الوكيل حوّل من الحساب واستلم كاشاً من الزبون — يُضاف إلى الكاش الذي في يده')}
          </p>
        </div>

        <div>
          <p className="mb-1.5 text-[11.5px] font-bold tracking-wide text-slate-400">{tr('التطبيق')}</p>
          <AppFilter value={app} onChange={setApp} withAll={false} />
        </div>

        {!isIn ? (
          <div>
            <p className="mb-1.5 text-[11.5px] font-bold tracking-wide text-slate-400">{tr('نوع الحوالة')}</p>
            <Segmented options={TYPES.map((x) => ({ ...x, label: tr(x.label) }))} value={type} onChange={setType} />
          </div>
        ) : null}

        <Field label={tr(isIn ? 'المبلغ الداخل للحساب (FCFA)' : isIncl ? 'الكاش الإجمالي من الزبون (شامل العمولة)' : 'مبلغ الحوالة (FCFA)')}>
          <MoneyInput
            value={amount}
            onChange={setAmount}
            placeholder={isIncl ? '35,000' : '140,000'}
            className={`${fieldCls} font-display text-[18px]`}
          />
        </Field>

        {!isIn ? (
          <div className="-mt-1">
            <div className="flex items-center justify-end gap-3">
              <span className={`text-[13px] font-bold ${incl ? 'text-emerald-200' : 'text-slate-300'}`}>{tr('الرسوم متضمنة')}</span>
              <button
                type="button"
                onClick={() => setInclInfo((v) => !v)}
                aria-label={tr('ما معنى الرسوم متضمنة؟')}
                className="grid h-9 w-9 place-items-center rounded-full text-slate-400 transition hover:text-white"
              >
                <AlertCircle size={19} />
              </button>
              <button
                type="button"
                role="switch"
                aria-checked={incl}
                aria-label={tr('الرسوم متضمنة')}
                onClick={() => setIncl((v) => !v)}
                className={`relative h-7 w-12 shrink-0 rounded-full transition ${incl ? 'bg-emerald-500' : 'bg-white/15'}`}
              >
                <span className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow transition-all ${incl ? 'start-6' : 'start-1'}`} />
              </button>
            </div>
            {inclInfo ? (
              <p className="mt-1 text-end text-[11px] leading-relaxed text-slate-500">
                {tr(incl ? 'اكتب الكاش الذي دفعه الزبون والتطبيق يفصل العمولة' : 'اكتب مبلغ الحوالة والعمولة تُضاف فوقه')}
              </p>
            ) : null}
          </div>
        ) : null}

        {isIn ? (
          <Field label={tr('عمولة (اختياري)')} hint={tr('إن أخذت عمولة على هذا الإيداع اكتبها، وإلا اتركها فارغة')}>
            <MoneyInput
              value={manualFee}
              onChange={setManualFee}
              placeholder="0"
              className={`${fieldCls} font-display text-[18px]`}
            />
          </Field>
        ) : (
        <div>
          <p className="mb-1.5 text-[11.5px] font-bold tracking-wide text-slate-400">{tr('عمولة الزبون (لكل 5000)')}</p>
          <div className="grid grid-cols-3 gap-1.5">
            {RATE_CHIPS.map((c) => {
              const active = rate === c.value
              return (
                <button
                  key={String(c.value)}
                  type="button"
                  onClick={() => setRate(c.value)}
                  className={`rounded-xl border px-1 py-2.5 text-[12.5px] font-extrabold transition active:scale-[0.97] ${
                    active
                      ? 'border-emerald-400/60 bg-emerald-500/20 text-emerald-200'
                      : 'border-white/10 bg-black/25 text-slate-400 hover:border-white/20'
                  }`}
                >
                  {tr(c.label)}
                </button>
              )
            })}
          </div>
        </div>
        )}

        {isManual ? (
          <Field label={tr('قيمة العمولة لكل 5000 (FCFA)')} hint={tr('اكتب أي قيمة لكل 5000 وتُحسب العمولة تلقائياً حسب مبلغ الحوالة')}>
            <MoneyInput
              value={manualFee}
              onChange={setManualFee}
              placeholder={tr('مثال: 200')}
              className={`${fieldCls} font-display text-[18px]`}
            />
          </Field>
        ) : null}

        <div className="rounded-2xl border border-white/10 bg-white/[0.03]">
          <button
            type="button"
            onClick={() => setRefOpen((o) => !o)}
            aria-expanded={refOpen}
            className="flex min-h-[44px] w-full items-center justify-between gap-2 px-3.5 py-3 text-start transition hover:bg-white/[0.04]"
          >
            <span className="text-[12px] font-extrabold text-slate-300">
              {tr('كود الحوالة أو اسم المستلم')} <span className="font-bold text-slate-500">({tr('اختياري')})</span>
              {!refOpen && ref.trim() ? <span className="ms-2 text-emerald-300">• {ref.trim()}</span> : null}
            </span>
            <ChevronDown size={16} className={`text-slate-400 transition-transform ${refOpen ? 'rotate-180' : ''}`} />
          </button>
          {refOpen ? (
            <div className="px-3.5 pb-3.5">
              <input autoFocus value={ref} onChange={(e) => setRef(e.target.value)} placeholder="MYNITAB..." className={fieldCls} />
            </div>
          ) : null}
        </div>
      </Card>

      <Card className="rise overflow-hidden">
        <div className="flex items-center gap-2 border-b border-white/[0.06] px-4 py-3">
          <Calculator size={14} className="text-emerald-300" />
          <SectionTitle>{tr('الحساب المباشر')}</SectionTitle>
        </div>
        {isIncl ? (
        <div className="space-y-3 p-4">
          <div className="flex items-center justify-between text-[13px]">
            <span className="text-slate-400">{tr('صافي المبلغ للمستفيد')}</span>
            <span className="font-display text-[16px] font-extrabold text-white">{fmt(r.amount)}</span>
          </div>
          <div className="flex items-center justify-between text-[13px]">
            <span className="text-slate-400">{tr('العمولة المستقطعة')}</span>
            <span className="font-display font-extrabold text-slate-100">{fmt(r.clientFee)}</span>
          </div>
          <div className="flex items-center justify-between border-t border-dashed border-white/10 pt-3 text-[13px]">
            <span className="text-slate-400">{tr('الإجمالي')}</span>
            <span className="font-display text-[16px] font-extrabold text-sky-300">{fmt(r.cashInHand)}</span>
          </div>
          {r.change > 0 ? (
            <div className="flex items-center justify-between rounded-xl bg-amber-500/10 px-3 py-2 text-[13px]">
              <span className="font-bold text-amber-200">{tr('الصرف للزبون')}</span>
              <span className="font-display font-extrabold text-amber-300">{fmt(r.change)}</span>
            </div>
          ) : null}
          <div className="flex items-center justify-between text-[12px]">
            <span className="text-slate-500">{tr('رسوم الشركة المحسومة')}</span>
            <span className="font-display font-bold text-amber-300/90">{hid(r.compFee)}</span>
          </div>
          <div className="flex items-center justify-between rounded-2xl bg-emerald-500/10 px-3.5 py-3">
            <span className="text-[12.5px] font-bold text-emerald-200/90">{tr('صافي مكسب المكتب')}</span>
            <span className="font-display text-[20px] font-black text-emerald-300">{hid(r.myProfit)}</span>
          </div>
        </div>
        ) : (
        <div className="space-y-3 p-4">
          <div className="flex items-center justify-between text-[13px]">
            <span className="text-slate-400">{tr('عمولة الزبون')}</span>
            <span className="font-display font-extrabold text-slate-100">{fmt(r.clientFee)}</span>
          </div>
          <div className="flex items-center justify-between text-[13px]">
            <span className="text-slate-400">{tr('رسوم الشركة المحسومة')}</span>
            <span className="font-display font-extrabold text-amber-300">{hid(r.compFee)}</span>
          </div>
          <div className="flex items-center justify-between border-t border-dashed border-white/10 pt-3 text-[13px]">
            <span className="text-slate-400">{tr(isIn ? 'الكاش الذي يخرج من يد الوكيل' : 'الكاش المستلم نقداً')}</span>
            <span className={`font-display text-[16px] font-extrabold ${isIn ? 'text-rose-300' : 'text-sky-300'}`}>{fmt(Math.abs(r.cashInHand))}</span>
          </div>
          <div className="flex items-center justify-between rounded-2xl bg-emerald-500/10 px-3.5 py-3">
            <span className="text-[12.5px] font-bold text-emerald-200/90">{tr('صافي مكسب المكتب')}</span>
            <span className="font-display text-[20px] font-black text-emerald-300">{hid(r.myProfit)}</span>
          </div>
        </div>
        )}
      </Card>

      <PrimaryBtn onClick={save} disabled={saving || !roster.length}>
        <span className="inline-flex items-center gap-2">
          <Send size={16} />
          {tr(saving ? 'جارٍ الحفظ...' : isIn ? 'حفظ الدخول' : 'حفظ الحوالة')}
        </span>
      </PrimaryBtn>
      <div className="h-2" />
    </div>
  )
}
