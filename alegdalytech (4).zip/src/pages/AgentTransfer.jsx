import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Send, CheckCircle2, AlertCircle } from 'lucide-react'
import { db } from '../lib/db'
import { useSession } from '../components/Session'
import { ACard, AField, ABtn, AChips, aInput } from '../components/agent-ui'
import { useToast } from '../components/ui'
import { TYPES, DIRECTIONS, CUSTOM_RATE, calcFees, calcInclusive, calcDeposit, fmt, todayKey } from '../components/fees'
import { AppFilter } from '../components/brands'
import { tr } from '../components/i18n'
import MoneyInput from '../components/MoneyInput'
import { notifyOwner, agentTxMessage } from '../components/notifyUp'

function InclRow({ incl, setIncl }) {
  const [info, setInfo] = useState(false)
  return (
    <div className="-mt-1">
      <div className="flex items-center justify-end gap-3">
        <span className={`text-[13px] font-extrabold ${incl ? 'text-[#0f766e]' : 'text-[#54655d]'}`}>{tr('الرسوم متضمنة')}</span>
        <button
          type="button"
          onClick={() => setInfo((v) => !v)}
          aria-label={tr('ما معنى الرسوم متضمنة؟')}
          className="grid h-9 w-9 place-items-center rounded-full text-[#8b9a93] transition hover:text-[#0b1a17]"
        >
          <AlertCircle size={19} />
        </button>
        <button
          type="button"
          role="switch"
          aria-checked={incl}
          aria-label={tr('الرسوم متضمنة')}
          onClick={() => setIncl((v) => !v)}
          className={`relative h-7 w-12 shrink-0 rounded-full transition ${incl ? 'bg-[#0f766e]' : 'bg-[#d5ded8]'}`}
        >
          <span className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow transition-all ${incl ? 'start-6' : 'start-1'}`} />
        </button>
      </div>
      {info ? (
        <p className="mt-1 text-end text-[11px] leading-relaxed text-[#8b9a93]">
          {tr(incl ? 'اكتب الكاش الذي دفعه الزبون والتطبيق يفصل العمولة' : 'اكتب مبلغ الحوالة والعمولة تُضاف فوقه')}
        </p>
      ) : null}
    </div>
  )
}
import { ChevronDown } from 'lucide-react'

const RATE_CHIPS = [
  { value: 250, label: '250' },
  { value: 150, label: '150' },
  { value: CUSTOM_RATE, label: '✎ يدوي' },
]

export default function AgentTransfer() {
  const session = useSession()
  const { user, gid, roster } = session
  const toast = useToast()
  const navigate = useNavigate()
  const me = roster[0] || null
  const agentId = user?.id || null

  const [direction, setDirection] = useState('out')
  const [app, setApp] = useState('NITA')
  const [type, setType] = useState('code')
  const [rate, setRate] = useState(250)
  const [manualFee, setManualFee] = useState('')
  const [amount, setAmount] = useState('')
  const [ref, setRef] = useState('')
  const [incl, setIncl] = useState(false)
  const [saving, setSaving] = useState(false)
  const [refOpen, setRefOpen] = useState(false)

  const isIn = direction === 'in'
  const isManual = !isIn && rate === CUSTOM_RATE
  const isIncl = !isIn && incl
  const r = useMemo(() => {
    if (isIn) return calcDeposit({ amount, fee: manualFee })
    const rt = isManual ? manualFee : rate
    return isIncl ? calcInclusive({ total: amount, rate: rt, type }) : calcFees({ amount, rate: rt, type })
  }, [amount, rate, type, manualFee, isManual, isIn, isIncl])

  async function save() {
    const amt = isIncl ? r.amount : Number(amount)
    if (!agentId) return toast(tr('تعذّر تحديد حسابك'), 'err')
    if (!Number(amount) || Number(amount) <= 0) return toast(tr('أدخل مبلغاً صحيحاً'), 'err')
    if (isManual && manualFee === '') return toast(tr('أدخل قيمة العمولة لكل 5000'), 'err')
    if (!amt || amt <= 0) return toast(tr('المبلغ لا يكفي للعمولة'), 'err')
    if (!gid) return toast(tr('تعذّر تجهيز الجلسة، أعد المحاولة'), 'err')

    setSaving(true)
    try {
      const row = {
        ...session.stamp,
        agentUserId: agentId,
        agentName: me?.name || '',
        kind: 'tx',
        direction,
        app,
        type: isIn ? 'deposit' : type,
        rate: isIn ? 0 : isManual ? Number(manualFee) || 0 : Number(rate),
        feeMode: isIn ? 'deposit' : isIncl ? 'inclusive' : 'per5k',
        customFee: isIn ? Number(manualFee) || 0 : 0,
        cashGiven: isIncl ? r.total : 0,
        change: isIncl ? r.change : 0,
        amount: amt,
        ref: ref.trim() || (isIn ? 'إيداع' : 'حوالة'),
        compFee: r.compFee,
        clientFee: r.clientFee,
        cashInHand: r.cashInHand,
        myProfit: r.myProfit,
        date: new Date().toISOString(),
        day: todayKey(),
        enteredBy: 'agent',
      }
      await db.insertShared(session.txColl, row, undefined, { groupId: gid, visibleTo: `user:${agentId}`, writableBy: 'admins' })
      window.dispatchEvent(new Event('tx-saved'))
      notifyOwner(session, agentTxMessage(me?.name, row))
      setAmount('')
      setRef('')
      setRefOpen(false)
      setManualFee('')
      setIncl(false)
      toast(tr(isIn ? 'تم حفظ الدخول' : 'تم حفظ الحوالة'))
      navigate('/history')
    } catch (e) {
      toast(e?.message || tr('تعذّر حفظ الحوالة'), 'err')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="rise">
        <p className="text-[12px] font-extrabold text-[#8b9a93]">{tr('تسجيل جديد')}</p>
        <h1 className="font-display text-[22px] font-black tracking-tight text-[#0b1a17]">{tr('حوالة جديدة')}</h1>
      </div>

      <ACard className="rise space-y-4 p-4 md:p-6">
        <div>
          <p className="mb-2 text-[12px] font-extrabold text-[#54655d]">{tr('اتجاه الحركة')}</p>
          <div className="grid grid-cols-2 gap-2">
            {DIRECTIONS.map((d) => {
              const active = direction === d.value
              const tone = d.value === 'in' ? 'border-[#0369a1] bg-[#0369a1]/10 text-[#0369a1]' : 'border-[#be123c] bg-[#be123c]/10 text-[#be123c]'
              return (
                <button
                  key={d.value}
                  type="button"
                  onClick={() => {
                    if (d.value !== direction) setManualFee('')
                    setDirection(d.value)
                  }}
                  className={`rounded-2xl border-2 px-2 py-3 text-[12.5px] font-extrabold transition ${
                    active ? tone : 'border-[#e6ece7] bg-white text-[#64756d]'
                  }`}
                >
                  {tr(d.label)}
                </button>
              )
            })}
          </div>
          <p className="mt-2 text-[11px] leading-relaxed text-[#8b9a93]">
            {tr(isIn
              ? 'القيمة دخلت حسابك في التطبيق ودفعت مقابلها كاشاً — تُخصم من الكاش الذي في يدك'
              : 'حوّلت من حسابك واستلمت كاشاً من الزبون — يُضاف إلى الكاش الذي في يدك')}
          </p>
        </div>

        <div>
          <p className="mb-2 text-[12px] font-extrabold text-[#54655d]">{tr('التطبيق')}</p>
          <AppFilter value={app} onChange={setApp} theme="light" withAll={false} />
        </div>

        {!isIn ? (
        <div>
          <p className="mb-2 text-[12px] font-extrabold text-[#54655d]">{tr('نوع الحوالة')}</p>
          <div className="grid grid-cols-2 gap-2">
            {TYPES.map((t) => (
              <button
                key={t.value}
                type="button"
                onClick={() => {
                  setType(t.value)
                }}
                className={`rounded-2xl border-2 px-3 py-3 text-[13px] font-extrabold transition ${
                  type === t.value
                    ? 'border-[#0f766e] bg-[#0f766e]/10 text-[#0f766e]'
                    : 'border-[#e6ece7] bg-white text-[#64756d]'
                }`}
              >
                {tr(t.label)}
              </button>
            ))}
          </div>
        </div>
        ) : null}

        <AField label={tr(isIn ? 'المبلغ الداخل للحساب (FCFA)' : isIncl ? 'الكاش الإجمالي من الزبون (شامل العمولة)' : 'مبلغ الحوالة (FCFA)')}>
          <MoneyInput
            value={amount}
            onChange={setAmount}
            placeholder={isIncl ? '35,000' : '140,000'}
            className={`${aInput} font-display text-[20px]`}
          />
        </AField>

        {!isIn ? <InclRow incl={incl} setIncl={setIncl} /> : null}

        {isIn ? (
          <AField label={tr('عمولة (اختياري)')} hint={tr('إن أخذت عمولة على هذا الإيداع اكتبها، وإلا اتركها فارغة')}>
            <MoneyInput
              value={manualFee}
              onChange={setManualFee}
              placeholder="0"
              className={`${aInput} font-display text-[20px]`}
            />
          </AField>
        ) : (
          <div>
            <p className="mb-2 text-[12px] font-extrabold text-[#54655d]">{tr('عمولة الزبون (لكل 5000)')}</p>
            <AChips options={RATE_CHIPS.map((c) => ({ ...c, label: tr(c.label) }))} value={rate} onChange={setRate} />
          </div>
        )}

        {isManual ? (
          <AField label={tr('قيمة العمولة لكل 5000 (FCFA)')} hint={tr('اكتب أي قيمة لكل 5000 وتُحسب العمولة تلقائياً حسب مبلغ الحوالة')}>
            <MoneyInput
              value={manualFee}
              onChange={setManualFee}
              placeholder={tr('مثال: 200')}
              className={`${aInput} font-display text-[20px]`}
            />
          </AField>
        ) : null}

        <div className="rounded-2xl border border-[#e6ece7] bg-white">
          <button
            type="button"
            onClick={() => setRefOpen((v) => !v)}
            aria-expanded={refOpen}
            className="flex w-full items-center justify-between gap-2 px-3.5 py-3 text-start"
          >
            <span className="text-[12.5px] font-extrabold text-[#54655d]">
              {tr('كود الحوالة أو اسم المستلم')} <span className="font-bold text-[#9aa8a1]">({tr('اختياري')})</span>
              {!refOpen && ref.trim() ? <span className="ms-2 text-[#0f766e]">· {ref.trim()}</span> : null}
            </span>
            <ChevronDown size={16} className={`shrink-0 text-[#8b9a93] transition-transform ${refOpen ? 'rotate-180' : ''}`} />
          </button>
          {refOpen ? (
            <div className="px-3.5 pb-3.5">
              <input autoFocus value={ref} onChange={(e) => setRef(e.target.value)} placeholder="MYNITAB..." className={aInput} />
            </div>
          ) : null}
        </div>
      </ACard>

      <ACard className="rise overflow-hidden">
        <div className="border-b border-[#eef2ee] px-4 py-3">
          <p className="font-display text-[14px] font-extrabold text-[#0b1a17]">{tr('ملخّص الحوالة')}</p>
        </div>
        <div className="space-y-3 p-4">
          <div className="flex items-center justify-between text-[13px]">
            <span className="text-[#64756d]">{tr(isIn ? 'المبلغ الداخل' : isIncl ? 'صافي المبلغ للمستفيد' : 'مبلغ الحوالة')}</span>
            <span className="font-display font-black text-[#0b1a17]">{fmt(r.amount)}</span>
          </div>
          <div className="flex items-center justify-between text-[13px]">
            <span className="text-[#64756d]">{tr(isIncl ? 'العمولة المستقطعة' : 'عمولة الزبون')}</span>
            <span className="font-display font-black text-[#0b1a17]">{fmt(r.clientFee)}</span>
          </div>
          {isIncl && r.change > 0 ? (
            <div className="flex items-center justify-between rounded-xl bg-amber-500/10 px-3 py-2 text-[13px]">
              <span className="font-extrabold text-amber-700">{tr('الصرف للزبون')}</span>
              <span className="font-display font-black text-amber-700">{fmt(r.change)}</span>
            </div>
          ) : null}
          {isIn ? (
            <div className="flex items-center justify-between rounded-2xl bg-[#be123c]/10 px-3.5 py-3">
              <span className="text-[12.5px] font-extrabold text-[#be123c]">{tr('الكاش الذي تدفعه')}</span>
              <span className="font-display text-[20px] font-black text-[#be123c]">{fmt(Math.abs(r.cashInHand))}</span>
            </div>
          ) : (
            <div className="flex items-center justify-between rounded-2xl bg-[#0f766e]/10 px-3.5 py-3">
              <span className="text-[12.5px] font-extrabold text-[#0f766e]">{tr(isIncl ? 'الإجمالي' : 'الكاش الذي تستلمه')}</span>
              <span className="font-display text-[20px] font-black text-[#0f766e]">{fmt(r.cashInHand)}</span>
            </div>
          )}
        </div>
      </ACard>

      <ABtn onClick={save} disabled={saving}>
        <span className="inline-flex items-center gap-2">
          <Send size={16} />
          {tr(saving ? 'جارٍ الحفظ...' : isIn ? 'حفظ الدخول' : 'حفظ الحوالة')}
        </span>
      </ABtn>
      <p className="pb-1 text-center text-[10.5px] text-[#9aa8a1]">
        <CheckCircle2 size={11} className="inline align-middle" /> {tr('تُحتسب الحوالة على حسابك مباشرة وتظهر للمكتب')}
      </p>
    </div>
  )
}
