import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { HandCoins, Wallet } from 'lucide-react'
import { db } from '../lib/db'
import { useLiveShared } from '../lib/useLive'
import { useSession } from '../components/Session'
import { useAgentStats } from '../hooks/useAgentStats'
import { ACard, AField, ABtn, aInput } from '../components/agent-ui'
import { useToast } from '../components/ui'
import { fmt, todayKey } from '../components/fees'
import { tr } from '../components/i18n'
import MoneyInput from '../components/MoneyInput'
import { scopeFilter } from '../components/scope'
import { notifyOwner, agentTxMessage } from '../components/notifyUp'

export default function AgentCash() {
  const session = useSession()
  const { user, gid, roster } = session
  const toast = useToast()
  const navigate = useNavigate()
  const me = roster[0] || null
  const agentId = user?.id || null

  const [amount, setAmount] = useState('')
  const [note, setNote] = useState('')
  const [saving, setSaving] = useState(false)

  const { data: live } = useLiveShared(session.txColl, {
    order: '-createdAt',
    limit: 30,
    filters: scopeFilter(session, agentId || '__none__'),
  })
  const version = useMemo(() => (live || []).map((r) => `${r.id}:${r.updatedAt || ''}`).join('|'), [live])
  const stats = useAgentStats(agentId, version)

  async function save() {
    const amt = Number(amount)
    if (!agentId) return toast(tr('تعذّر تحديد حسابك'), 'err')
    if (!amt || amt <= 0) return toast(tr('أدخل مبلغاً صحيحاً'), 'err')
    if (!gid) return toast(tr('تعذّر تجهيز الجلسة، أعد المحاولة'), 'err')

    setSaving(true)
    try {
      const row = {
        ...session.stamp,
        agentUserId: agentId,
        agentName: me?.name || '',
        kind: 'cash',
        amount: amt,
        ref: note.trim() || 'تسليم نقدي',
        date: new Date().toISOString(),
        day: todayKey(),
        enteredBy: 'agent',
      }
      await db.insertShared(session.txColl, row, undefined, { groupId: gid, visibleTo: `user:${agentId}`, writableBy: 'admins' })
      window.dispatchEvent(new Event('tx-saved'))
      notifyOwner(session, agentTxMessage(me?.name, row))
      setAmount('')
      setNote('')
      toast(tr('تم تسجيل تسليم الكاش'))
      navigate('/')
    } catch (e) {
      toast(e?.message || tr('تعذّر تسجيل العملية'), 'err')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="rise">
        <p className="text-[12px] font-extrabold text-[#8b9a93]">{tr('تصفية مع المكتب')}</p>
        <h1 className="font-display text-[22px] font-black tracking-tight text-[#0b1a17]">{tr('تسليم كاش')}</h1>
      </div>

      <div className="rise rounded-[26px] border border-[#fde9c8] bg-[#fffaf0] p-4">
        <div className="flex items-center gap-2 text-[11.5px] font-extrabold text-[#8a5a10]">
          <Wallet size={14} />
          {tr('الرصيد الحالي في يدك')}
        </div>
        <p className="font-display mt-1.5 text-[30px] font-black leading-none text-[#0b1a17]">
          {stats ? fmt(stats.balance) : '—'}
          <span className="ms-1.5 align-middle text-[11px] font-extrabold text-[#b45309]">FCFA</span>
        </p>
      </div>

      <ACard className="rise space-y-4 p-4 md:p-6">
        <AField label={tr('المبلغ المسلَّم للمكتب (FCFA)')}>
          <MoneyInput
            value={amount}
            onChange={setAmount}
            placeholder="100,000"
            className={`${aInput} font-display text-[20px]`}
          />
        </AField>
        <AField label={tr('ملاحظة (اختياري)')}>
          <input value={note} onChange={(e) => setNote(e.target.value)} placeholder={tr('دفعة كاش')} className={aInput} />
        </AField>

        {stats && Number(amount) > 0 ? (
          <p className="rounded-2xl bg-[#f1f6f2] px-3.5 py-2.5 text-[11.5px] font-extrabold text-[#42544c]">
            {tr('سيبقى في يدك بعد التسليم')}: {fmt(Math.max(0, stats.balance - Number(amount)))} FCFA
          </p>
        ) : null}
      </ACard>

      <ABtn tone="amber" onClick={save} disabled={saving}>
        <span className="inline-flex items-center gap-2">
          <HandCoins size={16} />
          {tr(saving ? 'جارٍ الحفظ...' : 'تأكيد تسليم الكاش')}
        </span>
      </ABtn>
      <div className="h-4" />
    </div>
  )
}
