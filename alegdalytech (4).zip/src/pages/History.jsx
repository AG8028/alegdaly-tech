import { useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { Trash2, Receipt, ScrollText } from 'lucide-react'
import { db } from '../lib/db'
import { useLiveShared } from '../lib/useLive'
import { useSession } from '../components/Session'
import { Card, Segmented, Spinner, EmptyState, useToast, useConfirm } from '../components/ui'
import AgentPicker from '../components/AgentPicker'
import { fmt, dateLabel, dayLabel, moveView, signed } from '../components/fees'
import { AppTag, AppFilter, AppSummaryCard, useAppTotals } from '../components/brands'
import { tr } from '../components/i18n'
import { scopeFilter } from '../components/scope'

const TAG_CLS = {
  out: 'bg-rose-500/15 text-rose-300',
  in: 'bg-sky-500/15 text-sky-300',
  cash: 'bg-amber-500/15 text-amber-300',
}

export default function History() {
  const session = useSession()
  const toast = useToast()
  const ask = useConfirm()
  const [params] = useSearchParams()
  const { canManage, roster, selectedAgentId, setSelectedAgentId, user, gid } = session

  const agentId = canManage ? selectedAgentId : user?.id || null
  const [kind, setKind] = useState('all')
  const [app, setApp] = useState(() => {
    const a = params.get('app')
    return a === 'NITA' || a === 'AMANA' ? a : 'all'
  })

  useEffect(() => {
    if (app !== 'all' && kind === 'cash') setKind('all')
  }, [app, kind])

  const FILTERS = [
    { value: 'all', label: tr('الكل') },
    { value: 'tx', label: tr('حوالات') },
    { value: 'cash', label: tr('تصفية') },
  ]

  const filters = useMemo(() => {
    const f = scopeFilter(session, agentId)
    if (app !== 'all') {
      f.kind = 'tx'
      f.app = app
    } else if (kind !== 'all') f.kind = kind
    return f
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [agentId, kind, app, session.base, session.guardIds])

  const { data, loading } = useLiveShared(session.txColl, { order: '-createdAt', limit: 200, filters })
  const rows = data || []

  const version = useMemo(() => rows.map((r) => `${r.id}:${r.updatedAt || ''}`).join('|'), [rows])
  const totals = useAppTotals(agentId, version)

  const grouped = useMemo(() => {
    const map = new Map()
    for (const r of rows) {
      const key = r.day || 'unknown'
      if (!map.has(key)) map.set(key, [])
      map.get(key).push(r)
    }
    return [...map.entries()].sort((a, b) => (a[0] < b[0] ? 1 : -1))
  }, [rows])

  async function remove(t) {
    const mv = moveView(t)
    const ok = await ask({
      title: tr('حذف هذه الحركة نهائياً؟'),
      text: `${[mv.tag, mv.app, `${fmt(Math.abs(mv.value))} FCFA`].filter(Boolean).join(' · ')} — ${tr('لا يمكن التراجع عن الحذف.')}`,
      confirmLabel: tr('حذف الحركة'),
    })
    if (!ok) return
    const id = t.id
    try {
      // مع معرّف المجموعة حتى يعمل الحذف أيضاً عند الدخول بحساب المالك (اسم مستخدم + كلمة مرور)
      const ok = await db.deleteShared(session.txColl, id, gid || undefined)
      if (!ok) throw new Error(tr('تعذّر الحذف'))
      toast(tr('تم حذف الحركة'))
    } catch (e) {
      toast(e?.message || tr('تعذّر الحذف'), 'err')
    }
  }

  return (
    <div className="mx-auto max-w-4xl space-y-5">
      <div className="rise">
        <p className="text-[11px] font-bold tracking-[0.18em] text-emerald-400/80">{tr('السجل')}</p>
        <h1 className="font-display text-[24px] font-extrabold tracking-tight text-white md:text-[28px]">{tr('سجل الحركات')}</h1>
      </div>

      {canManage ? <AgentPicker options={roster} value={selectedAgentId} onChange={setSelectedAgentId} allowAll /> : null}

      <div className="space-y-3">
        <AppFilter value={app} onChange={setApp} />
        {app === 'all' ? (
          <div className="grid grid-cols-2 gap-3">
            <AppSummaryCard app="NITA" t={totals.NITA} showProfit={canManage} onClick={() => setApp('NITA')} />
            <AppSummaryCard app="AMANA" t={totals.AMANA} showProfit={canManage} onClick={() => setApp('AMANA')} />
          </div>
        ) : (
          <AppSummaryCard app={app} t={totals[app]} showProfit={canManage} />
        )}
      </div>

      {app === 'all' ? <Segmented options={FILTERS} value={kind} onChange={setKind} className="max-w-sm" /> : null}

      {loading ? (
        <Spinner />
      ) : grouped.length === 0 ? (
        <Card className="p-4">
          <EmptyState icon={ScrollText} title={tr('لا توجد حركات')} text={tr('ابدأ بتسجيل حوالة أو تصفية كاش لتظهر هنا.')} />
        </Card>
      ) : (
        <div className="space-y-4">
          {grouped.map(([day, items]) => {
            const net = items.reduce((s, r) => s + (r.kind === 'tx' ? Number(r.cashInHand) || 0 : -(Number(r.amount) || 0)), 0)
            return (
              <Card key={day} className="overflow-hidden">
                <div className="flex items-center justify-between border-b border-white/[0.06] bg-white/[0.02] px-4 py-2.5">
                  <span className="text-[12px] font-extrabold text-slate-300">{day === 'unknown' ? tr('بدون تاريخ') : dayLabel(day)}</span>
                  <span className="text-[11.5px] font-bold text-slate-500">
                    {tr('الصافي')}: <span className={net >= 0 ? 'text-emerald-300' : 'text-rose-300'}>{fmt(net)}</span>
                  </span>
                </div>
                <ul className="divide-y divide-white/[0.05]">
                  {items.map((t) => {
                    const isTx = t.kind === 'tx'
                    const mv = moveView(t)
                    return (
                      <li key={t.id} className="flex items-center gap-3 px-4 py-3">
                        <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${TAG_CLS[mv.dir]}`}>
                          <Receipt size={15} />
                        </span>
                        <div className="min-w-0 flex-1">
                          <p className="flex items-center gap-1.5 truncate text-[13px] font-bold text-slate-100">
                            <span className={`shrink-0 rounded-md px-1.5 py-0.5 text-[10px] font-extrabold ${TAG_CLS[mv.dir]}`}>{mv.tag}</span>
                            <AppTag app={mv.app} />
                            <span className="truncate">{mv.title}</span>
                          </p>
                          <p className="mt-0.5 truncate text-[11px] text-slate-500">
                            {canManage && !agentId && t.agentName ? `${t.agentName} · ` : ''}
                            {dateLabel(t.date)}
                            {isTx ? ` · ${tr('مبلغ')} ${fmt(t.amount)}` : ''}
                            {isTx && (t.feeMode === 'manual' || t.feeMode === 'custom') ? ` · ${tr('عمولة يدوية')}` : ''}
                            {isTx && t.cashGiven > 0 ? ` · ${tr('كاش مستلم')} ${fmt(t.cashGiven)}` : ''}
                          </p>
                        </div>
                        <div className="text-end">
                          <p className={`font-display text-[13.5px] font-extrabold ${mv.value >= 0 ? 'text-emerald-300' : 'text-rose-300'}`}>
                            {signed(mv.value)}
                          </p>
                          {isTx ? <p className="text-[10.5px] text-slate-500">{tr('ربح')} {fmt(t.myProfit)}</p> : null}
                        </div>
                        {canManage ? (
                          <button
                            onClick={() => remove(t)}
                            className="ms-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-slate-500 transition hover:bg-rose-500/15 hover:text-rose-300"
                            aria-label={tr('حذف')}
                          >
                            <Trash2 size={15} />
                          </button>
                        ) : null}
                      </li>
                    )
                  })}
                </ul>
              </Card>
            )
          })}
        </div>
      )}
      <div className="h-2" />
    </div>
  )
}
