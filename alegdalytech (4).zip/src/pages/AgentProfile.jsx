import { useState } from 'react'
import { UserRound, KeyRound, Phone, CalendarDays, ShieldCheck, Eye, EyeOff } from 'lucide-react'
import { team } from '../lib/team'
import { foldTypedDigits } from '../lib/_typed-digits.js'
import { useSession } from '../components/Session'
import { ACard, AField, ABtn, aInput } from '../components/agent-ui'
import { useToast } from '../components/ui'
import { fmt } from '../components/fees'
import { tr } from '../components/i18n'

export default function AgentProfile() {
  const { roster, user, isOffice, officeName } = useSession()
  const toast = useToast()
  const me = roster[0] || null

  const [current, setCurrent] = useState('')
  const [next, setNext] = useState('')
  const [busy, setBusy] = useState(false)
  const [showPin, setShowPin] = useState(false)
  const pinDigits = (v) => foldTypedDigits(v).replace(/\D/g, '').slice(0, 6)

  async function changePin() {
    if (!/^\d{6}$/.test(next)) return toast(tr('الرمز الجديد يجب أن يكون 6 أرقام'), 'err')
    setBusy(true)
    try {
      await team.changePassword(current, next)
      setCurrent('')
      setNext('')
      toast(tr('تم تغيير رمزك السري'))
    } catch (e) {
      toast(e?.message || tr('تعذّر تغيير الرمز — تأكد من الرمز الحالي'), 'err')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="rise">
        <p className="text-[12px] font-extrabold text-[#8b9a93]">{tr('ملفي')}</p>
        <h1 className="font-display text-[22px] font-black tracking-tight text-[#0b1a17]">{tr('حسابي')}</h1>
      </div>

      <div className="rise flex items-center gap-3 rounded-[26px] border border-[#e6ece7] bg-white p-4">
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-[#0f766e] font-display text-[22px] font-black text-white">
          {(me?.name || 'و').trim().charAt(0)}
        </div>
        <div className="min-w-0">
          <p className="font-display truncate text-[16px] font-black text-[#0b1a17]">{me?.name || tr('وكيل')}</p>
          <p className="mt-0.5 flex items-center gap-1 text-[11.5px] font-extrabold text-[#0f766e]">
            <UserRound size={12} />
            {isOffice ? me?.email || user?.email || '—' : `@${me?.handle || '—'}`}
          </p>
        </div>
      </div>

      <ACard className="rise divide-y divide-[#f1f5f2]">
        <div className="flex items-center justify-between px-4 py-3.5">
          <span className="flex items-center gap-2 text-[12.5px] font-extrabold text-[#64756d]">
            <Phone size={14} />
            {tr('رقم الهاتف')}
          </span>
          <span dir="ltr" className="text-[13px] font-extrabold text-[#0b1a17]">{me?.phone || tr('غير مسجّل')}</span>
        </div>
        <div className="flex items-center justify-between px-4 py-3.5">
          <span className="flex items-center gap-2 text-[12.5px] font-extrabold text-[#64756d]">
            <CalendarDays size={14} />
            {tr('الراتب الشهري')}
          </span>
          <span className="font-display text-[13px] font-black text-[#0b1a17]">
            {me?.salary ? `${fmt(me.salary)} FCFA` : tr('غير محدّد')}
          </span>
        </div>
        <div className="flex items-center justify-between px-4 py-3.5">
          <span className="flex items-center gap-2 text-[12.5px] font-extrabold text-[#64756d]">
            <ShieldCheck size={14} />
            {tr('نوع الحساب')}
          </span>
          <span className="rounded-full bg-[#0f766e]/10 px-2.5 py-1 text-[11px] font-extrabold text-[#0f766e]">{tr('وكيل')}</span>
        </div>
        {isOffice && officeName ? (
          <div className="flex items-center justify-between px-4 py-3.5">
            <span className="flex items-center gap-2 text-[12.5px] font-extrabold text-[#64756d]">
              <ShieldCheck size={14} />
              {tr('المكتب')}
            </span>
            <span className="text-[13px] font-extrabold text-[#0b1a17]">{officeName}</span>
          </div>
        ) : null}
      </ACard>

      {!isOffice && <ACard className="rise space-y-3 p-4">
        <div className="flex items-center gap-2">
          <KeyRound size={15} className="text-[#0f766e]" />
          <p className="font-display text-[14px] font-extrabold text-[#0b1a17]">{tr('تغيير رمزي السري')}</p>
        </div>
        <AField label={tr('الرمز الحالي')}>
          <input
            type={showPin ? 'text' : 'password'}
            value={current}
            onChange={(e) => setCurrent(pinDigits(e.target.value))}
            inputMode="numeric"
            autoComplete="current-password"
            placeholder="••••••"
            className={aInput}
          />
        </AField>
        <AField label={tr('الرمز الجديد')} hint={tr('6 أرقام')}>
          <input
            type={showPin ? 'text' : 'password'}
            value={next}
            onChange={(e) => setNext(pinDigits(e.target.value))}
            inputMode="numeric"
            autoComplete="new-password"
            placeholder="••••••"
            className={aInput}
          />
        </AField>
        <button
          type="button"
          onClick={() => setShowPin((s) => !s)}
          className="flex items-center gap-1.5 text-[12px] font-extrabold text-[#0f766e]"
        >
          {showPin ? <EyeOff size={14} /> : <Eye size={14} />}
          {tr(showPin ? 'إخفاء الرمز' : 'إظهار الرمز')}
        </button>
        <ABtn tone="soft" onClick={changePin} disabled={busy || !current || !next}>
          {tr(busy ? 'جارٍ الحفظ...' : 'حفظ الرمز الجديد')}
        </ABtn>
        <p className="text-[11px] leading-relaxed text-[#9aa8a1]">
          {tr('إذا نسيت رمزك، اطلب من المكتب إنشاء رمز جديد لك.')}
        </p>
      </ACard>}

      <div className="h-4" />
    </div>
  )
}
