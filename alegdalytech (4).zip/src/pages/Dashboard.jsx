import { useMemo, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Wallet, TrendingUp, Landmark, HandCoins, ArrowLeftRight, Plus, Users, ArrowLeft, Eye, EyeOff } from 'lucide-react'
import { useLiveShared } from '../lib/useLive'
import { useSession } from '../components/Session'
import { Card, SectionTitle, Spinner, EmptyState, GhostBtn } from '../components/ui'
import AgentPicker from '../components/AgentPicker'
import ProfitPanel from '../components/ProfitPanel'
import { fmt, money, dateLabel, moveView, signed } from '../components/fees'
import { useAgentStats, useDailyProfit } from '../hooks/useAgentStats'
import { AppTag, AppSummaryCard, useAppTotals } from '../components/brands'
import { tr } from '../components/i18n'
import { scopeFilter } from '../components/scope'

function Stat({ icon: Icon, label, value, tone }) {
  return (
    <div className="rounded-2xl border border-white/[0.07] bg-white/[0.03] px-3 py-3">
      <div className="mb-1.5 flex items-center gap-1.5">
        <Icon size={13} className={tone} />
        <span className="text-[10.5px] font-bold text-slate-500">{label}</span>
      </div>
      <p className={`font-display text-[15px] font-extrabold leading-none ${tone}`}>{value}</p>
    </div>
  )
}

export default function Dashboard() {
  const session = useSession()
  const navigate = useNavigate()
  const { canManage, roster, selectedAgentId, setSelectedAgentId, user, ready } = session
  const agentId = canManage ? selectedAgentId : user?.id || null

  const filters = scopeFilter(session, agentId)
  const { data: live, loading } = useLiveShared(session.txColl, { order: '-createdAt', limit: 40, filters })

  const version = useMemo(() => (live || []).map((r) => `${r.id}:${r.updatedAt || ''}`).join('|'), [live])
  const stats = useAgentStats(agentId, version)
  const daily = useDailyProfit(agentId, version, 7)
  const appTotals = useAppTotals(agentId, version)

  const activeAgent = roster.find((r) => r.userId === agentId) || null
  const who = agentId ? activeAgent?.name || tr('الوكيل') : tr('جميع الوكلاء')
  const recent = (live || []).slice(0, 5)
  const [hide, setHide] = useState(() => { try { return localStorage.getItem('dash-hide-cash') === '1' } catch { return false } })
  const toggleHide = () => setHide((h) => { const n = !h; try { localStorage.setItem('dash-hide-cash', n ? '1' : '0') } catch {} return n })
  const show = (v) => (hide ? '••••' : v)

  if (!ready) return <Spinner />

  return (
    <div className="space-y-5">
      <div className="rise">
        <div className="mb-3 flex items-end justify-between gap-3">
          <div>
            <p className="text-[11px] font-bold tracking-[0.18em] text-emerald-400/80">{tr('لوحة التحكم')}</p>
            <h1 className="font-display text-[24px] font-extrabold leading-tight tracking-tight text-white md:text-[28px]">
              {who}
            </h1>
          </div>
          <span className="rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5 text-[11px] font-bold text-slate-400">
            {new Date().toLocaleDateString('en-GB')}
          </span>
        </div>
        {canManage ? (
          <AgentPicker options={roster} value={selectedAgentId} onChange={setSelectedAgentId} allowAll />
        ) : null}
      </div>

      {canManage && roster.length === 0 ? (
        <Card className="p-5">
          <EmptyState
            icon={Users}
            title={tr('لا يوجد وكلاء بعد')}
            text={session.isOffice
              ? tr('أرسل رابط الانضمام لوكلائك من شاشة الوكلاء، ثم وافق على طلباتهم.')
              : tr('أضف وكلاءك من شاشة الوكلاء — يتولّد لكل واحد اسم دخول ورمز تلقائياً.')}
            action={<GhostBtn onClick={() => navigate('/team')}>{tr('إضافة وكلاء')}</GhostBtn>}
          />
        </Card>
      ) : null}

      {/* بطاقة الرصيد */}
      <div className="skin-hero rise relative overflow-hidden rounded-3xl border border-emerald-400/20 bg-gradient-to-bl from-emerald-500/[0.18] via-[#0a1a24] to-[#070f1c] p-5 md:p-7">
        <div className="glow-pulse pointer-events-none absolute -left-16 -top-20 h-56 w-56 rounded-full bg-emerald-400/25 blur-3xl" />
        <div className="relative">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-[11.5px] font-bold text-emerald-300/90">
              <Wallet size={14} />
              {tr('الكاش في يد {who}', { who: agentId ? who : tr('الوكلاء') })}
            </div>
            <button
              type="button"
              onClick={toggleHide}
              aria-label={hide ? tr('إظهار') : tr('إخفاء')}
              className={`grid h-11 w-11 shrink-0 place-items-center rounded-full border transition active:scale-95 ${hide ? 'border-white/10 bg-white/[0.04] text-slate-400 hover:bg-white/[0.08]' : 'border-emerald-400/30 bg-emerald-400/15 text-emerald-300 hover:bg-emerald-400/25'}`}
            >
              {hide ? <EyeOff size={18} /> : <Eye size={18} />}
            </button>
          </div>
          <p className="font-display mt-2 text-[38px] font-black leading-none tracking-tight text-white md:text-[46px]">
            {stats ? show(fmt(stats.balance)) : '—'}
            <span className="ms-2 align-middle text-[13px] font-bold text-emerald-300/70">FCFA</span>
          </p>
          <p className="mt-2 text-[11.5px] leading-relaxed text-slate-400">
            {tr('مجموع الحوالات والعمولات نقداً، بعد خصم ما سلّمه الوكيل لك')}
          </p>

          <div className="mt-4 grid grid-cols-3 gap-2">
            <Stat icon={TrendingUp} label={tr('صافي مكسب المكتب')} value={stats ? show(fmt(stats.profit)) : '—'} tone="text-emerald-300" />
            <Stat icon={Landmark} label={tr('رسوم الشركة')} value={stats ? show(fmt(stats.comp)) : '—'} tone="text-amber-300" />
            <Stat icon={HandCoins} label={tr('كاش مسلّم')} value={stats ? show(fmt(stats.handed)) : '—'} tone="text-sky-300" />
          </div>
        </div>
      </div>

      {/* NITA / AMANA — كل تطبيق على حدة */}
      <div className="grid grid-cols-2 gap-3">
        <AppSummaryCard app="NITA" t={appTotals.NITA} showProfit onClick={() => navigate('/history?app=NITA')} />
        <AppSummaryCard app="AMANA" t={appTotals.AMANA} showProfit onClick={() => navigate('/history?app=AMANA')} />
      </div>

      {/* اختصارات */}
      <div className="grid grid-cols-2 gap-3">
        <Link
          to="/transfer"
          className="group flex items-center gap-3 rounded-2xl border border-white/[0.08] bg-white/[0.035] p-4 transition hover:border-emerald-400/40 hover:bg-emerald-500/[0.08]"
        >
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500/15 text-emerald-300">
            <Plus size={18} />
          </span>
          <span className="font-display text-[14px] font-extrabold text-slate-100">{tr('حوالة جديدة')}</span>
        </Link>
        <Link
          to="/cash"
          className="group flex items-center gap-3 rounded-2xl border border-white/[0.08] bg-white/[0.035] p-4 transition hover:border-sky-400/40 hover:bg-sky-500/[0.08]"
        >
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-sky-500/15 text-sky-300">
            <ArrowLeftRight size={18} />
          </span>
          <span className="font-display text-[14px] font-extrabold text-slate-100">{tr('تسليم كاش')}</span>
        </Link>
      </div>

      {/* مركز الأرباح */}
      <ProfitPanel
        total={stats ? stats.profit : null}
        daily={daily}
        nita={appTotals.NITA?.profit}
        amana={appTotals.AMANA?.profit}
      />

      {/* آخر الحركات */}
      <Card className="p-4 md:p-5">
        <div className="mb-1 flex items-center justify-between">
          <SectionTitle>{tr('آخر الحركات')}</SectionTitle>
          <Link to="/history" className="mb-3 flex items-center gap-1 text-[12px] font-bold text-emerald-300/90">
            {tr('الكل')}
            <ArrowLeft size={13} className="rtl:rotate-0 ltr:rotate-180" />
          </Link>
        </div>

        {loading ? (
          <Spinner className="py-8" />
        ) : recent.length === 0 ? (
          <p className="py-8 text-center text-[12.5px] text-slate-500">{tr('لا توجد حركات مسجلة بعد')}</p>
        ) : (
          <ul className="divide-y divide-white/[0.06]">
            {recent.map((t) => {
              const isTx = t.kind === 'tx'
              const mv = moveView(t)
              return (
                <li key={t.id} className="flex items-center justify-between gap-3 py-3">
                  <div className="min-w-0">
                    <p className="truncate text-[13px] font-bold text-slate-100">
                      <span className={`me-1.5 rounded-md px-1.5 py-0.5 text-[10px] font-extrabold ${mv.dir === 'in' ? 'bg-sky-500/15 text-sky-300' : mv.dir === 'out' ? 'bg-rose-500/15 text-rose-300' : 'bg-amber-500/15 text-amber-300'}`}>{mv.tag}</span>
                      <AppTag app={mv.app} className="me-1.5" />
                      {mv.title}
                    </p>
                    <p className="mt-0.5 truncate text-[11px] text-slate-500">
                      {canManage && !agentId ? `${t.agentName || tr('وكيل')} · ` : ''}
                      {dateLabel(t.date)}
                    </p>
                  </div>
                  <div className="text-end">
                    <p className={`font-display text-[13.5px] font-extrabold ${mv.value >= 0 ? 'text-emerald-300' : 'text-rose-300'}`}>
                      {signed(mv.value)}
                    </p>
                    {isTx ? (
                      <p className="text-[10.5px] text-slate-500">{tr('ربح')} {fmt(t.myProfit)}</p>
                    ) : (
                      <p className="text-[10.5px] text-slate-500">{tr('كاش مسلّم')}</p>
                    )}
                  </div>
                </li>
              )
            })}
          </ul>
        )}
      </Card>

      <p className="pb-2 text-center text-[10.5px] text-slate-600">
        {stats ? `${fmt(stats.count)} ${tr('حركة مسجّلة')} · ` : ''}
        {agentId ? money(stats?.balance || 0) : tr('الإجمالي عبر جميع الوكلاء')}
      </p>
    </div>
  )
}
