import { ArrowLeft, ShieldCheck } from 'lucide-react'
import Logo from '../components/Logo'
import { LangSwitcher, useLang } from '../components/i18n'

const UPDATED = '2026-10-29'

const CONTENT = {
  en: {
    title: 'Privacy Policy',
    intro:
      'ALEGDALY TECH is an app for money-transfer offices: it lets an office manage its agents, record NITA and AMANA transfers, calculate fees and commissions, and follow daily cash balances. This policy explains what information the app collects, how it is used, and the choices you have.',
    back: 'Back to the app',
    updated: 'Last updated',
    sections: [
      ['Information we collect', [
        'Account information: your email address and name when you sign in with email or Google. Agents created by an office sign in with a username and PIN.',
        'Office and agent details you enter: office name, city, owner name, agent names and phone numbers, and salaries if you choose to record them.',
        'Transaction records you enter: transfer amounts, codes, application (NITA / AMANA), fees, commissions, settlements and, in the Libya section, sender and receiver names and phone numbers.',
        'Technical information needed to run the app: a device identifier used to confirm new devices, and a notification token if you allow notifications.',
      ]],
      ['How we use it', [
        'To provide the service: show your balances, history, settlements and reports to you and to the people you authorize in your office.',
        'To keep accounts secure: email verification codes when signing in from a new device, and security alerts.',
        'To send notifications you enable (incoming transfers, payouts, partnership requests).',
        'We do not sell your information, and we do not use it for advertising.',
      ]],
      ['Who can see your data', [
        'Office records (transfers, agents, balances) are private to your office: only you and the members you add can see them.',
        'Partner offices you connect with in the Libya section see only the transfers exchanged with them.',
        'Data is stored on secure cloud infrastructure operated by our hosting provider, used only to run this app.',
      ]],
      ['Google sign-in', [
        'If you choose "Continue with Google", we receive only your name, email address and profile picture from Google, solely to create and identify your account. We do not access your Gmail, contacts, Drive or any other Google data.',
      ]],
      ['Retention and deletion', [
        'Your data is kept while your account or office is active. You can delete your account from the account menu inside the app; office owners can delete records they created. You may also ask us to delete your data at any time.',
      ]],
      ['Security', [
        'Connections are encrypted (HTTPS). Passwords and PINs are never stored in readable form, and new devices require email confirmation.',
      ]],
      ['Children', [
        'The app is intended for professional use by adults and is not directed at children under 13.',
      ]],
      ['Changes and contact', [
        'We may update this policy; the date above shows the latest version. For any privacy question or deletion request, contact the ALEGDALY TECH administration through the contact options shown in the app.',
      ]],
    ],
  },
  fr: {
    title: 'Politique de confidentialité',
    intro:
      "ALEGDALY TECH est une application pour les bureaux de transfert d'argent : elle permet de gérer les agents, d'enregistrer les transferts NITA et AMANA, de calculer les frais et commissions et de suivre les soldes quotidiens. Cette politique explique quelles informations sont collectées, comment elles sont utilisées et vos choix.",
    back: "Retour à l'application",
    updated: 'Dernière mise à jour',
    sections: [
      ['Informations collectées', [
        'Compte : votre adresse e-mail et votre nom lors de la connexion par e-mail ou Google. Les agents créés par un bureau se connectent avec un identifiant et un code PIN.',
        "Détails du bureau et des agents saisis par vous : nom du bureau, ville, nom du propriétaire, noms et téléphones des agents, salaires si vous les enregistrez.",
        'Opérations saisies : montants, codes, application (NITA / AMANA), frais, commissions, règlements et, dans la section Libye, noms et téléphones de l’expéditeur et du destinataire.',
        "Informations techniques : un identifiant d'appareil pour confirmer les nouveaux appareils et un jeton de notification si vous les autorisez.",
      ]],
      ['Utilisation', [
        'Fournir le service : afficher soldes, historique, règlements et rapports à vous et aux personnes autorisées de votre bureau.',
        'Sécuriser les comptes : codes de vérification par e-mail pour un nouvel appareil et alertes de sécurité.',
        'Envoyer les notifications que vous activez.',
        'Nous ne vendons pas vos informations et ne les utilisons pas pour la publicité.',
      ]],
      ['Qui voit vos données', [
        'Les données du bureau sont privées : seuls vous et les membres ajoutés les voient.',
        'Les bureaux partenaires (section Libye) ne voient que les transferts échangés avec eux.',
        "Les données sont stockées sur une infrastructure cloud sécurisée, utilisée uniquement pour faire fonctionner l'application.",
      ]],
      ['Connexion Google', [
        "Avec « Continuer avec Google », nous recevons uniquement votre nom, e-mail et photo de profil, pour créer et identifier votre compte. Nous n'accédons à aucune autre donnée Google.",
      ]],
      ['Conservation et suppression', [
        "Les données sont conservées tant que le compte ou le bureau est actif. Vous pouvez supprimer votre compte depuis le menu du compte dans l'application, ou nous demander la suppression à tout moment.",
      ]],
      ['Sécurité', [
        'Connexions chiffrées (HTTPS). Mots de passe et PIN jamais stockés en clair ; les nouveaux appareils exigent une confirmation par e-mail.',
      ]],
      ['Enfants', [
        "Application à usage professionnel pour adultes, non destinée aux enfants de moins de 13 ans.",
      ]],
      ['Modifications et contact', [
        "Cette politique peut être mise à jour ; la date ci-dessus indique la dernière version. Pour toute question ou demande de suppression, contactez l'administration ALEGDALY TECH via les contacts indiqués dans l'application.",
      ]],
    ],
  },
  ar: {
    title: 'سياسة الخصوصية',
    intro:
      'ALEGDALY TECH تطبيق لمكاتب تحويل الأموال: يتيح للمكتب إدارة وكلائه، وتسجيل حوالات نيتا وأمانة، وحساب الرسوم والعمولات، ومتابعة الأرصدة اليومية. توضّح هذه السياسة ما نجمعه من معلومات، وكيف نستخدمها، وما هي خياراتك.',
    back: 'العودة إلى التطبيق',
    updated: 'آخر تحديث',
    sections: [
      ['المعلومات التي نجمعها', [
        'بيانات الحساب: بريدك الإلكتروني واسمك عند الدخول بالبريد أو Google. الوكلاء الذين ينشئهم المكتب يدخلون باسم مستخدم ورمز PIN.',
        'بيانات المكتب والوكلاء التي تُدخلها: اسم المكتب والمدينة واسم المالك، وأسماء الوكلاء وأرقام هواتفهم، والرواتب إن اخترت تسجيلها.',
        'العمليات التي تُدخلها: مبالغ الحوالات والأكواد والتطبيق (نيتا / أمانة) والرسوم والعمولات والتصفيات، وفي قسم ليبيا أسماء وهواتف المرسل والمستلم.',
        'معلومات تقنية لازمة لتشغيل التطبيق: معرّف للجهاز لتأكيد الأجهزة الجديدة، ورمز إشعارات إذا سمحت بالإشعارات.',
      ]],
      ['كيف نستخدمها', [
        'لتقديم الخدمة: عرض الأرصدة والسجل والتصفيات والتقارير لك ولمن تأذن لهم في مكتبك.',
        'لحماية الحسابات: رموز تحقق بالبريد عند الدخول من جهاز جديد، وتنبيهات أمنية.',
        'لإرسال الإشعارات التي تفعّلها (حوالة واردة، تسليم، طلبات شراكة).',
        'لا نبيع معلوماتك، ولا نستخدمها للإعلانات.',
      ]],
      ['من يرى بياناتك', [
        'سجلات المكتب (الحوالات والوكلاء والأرصدة) خاصة بمكتبك: لا يراها إلا أنت والأعضاء الذين تضيفهم.',
        'المكاتب الشريكة في قسم ليبيا ترى فقط الحوالات المتبادلة معها.',
        'تُحفظ البيانات على بنية سحابية آمنة يشغّلها مزوّد الاستضافة، وتُستخدم فقط لتشغيل هذا التطبيق.',
      ]],
      ['الدخول بحساب Google', [
        'عند اختيار «المتابعة مع Google» نستلم فقط اسمك وبريدك وصورة ملفك، لإنشاء حسابك والتعرّف عليه. لا نصل إلى Gmail أو جهات الاتصال أو Drive أو أي بيانات أخرى في Google.',
      ]],
      ['الاحتفاظ والحذف', [
        'نحتفظ بالبيانات ما دام حسابك أو مكتبك نشطاً. يمكنك حذف حسابك من قائمة الحساب داخل التطبيق، ولمالك المكتب حذف السجلات التي أنشأها، ويمكنك طلب حذف بياناتك في أي وقت.',
      ]],
      ['الأمان', [
        'الاتصال مشفّر (HTTPS). كلمات المرور ورموز PIN لا تُخزَّن بشكل مقروء، والأجهزة الجديدة تحتاج تأكيداً بالبريد.',
      ]],
      ['الأطفال', [
        'التطبيق مخصّص للاستخدام المهني من البالغين، وليس موجّهاً للأطفال دون 13 سنة.',
      ]],
      ['التعديلات والتواصل', [
        'قد نحدّث هذه السياسة، والتاريخ أعلاه يبيّن آخر نسخة. لأي سؤال عن الخصوصية أو طلب حذف، تواصل مع إدارة ALEGDALY TECH عبر وسائل التواصل الظاهرة في التطبيق.',
      ]],
    ],
  },
}

function goHome() {
  try {
    const p = window.location.pathname.replace(/\/+$/, '')
    if (p.endsWith('/privacy')) window.location.href = p.slice(0, -'/privacy'.length) + '/'
    else window.location.hash = ''
  } catch { /* ignore */ }
}

export default function Privacy() {
  const { lang } = useLang()
  const c = CONTENT[lang] || CONTENT.en
  const rtl = lang === 'ar'
  return (
    <div dir={rtl ? 'rtl' : 'ltr'} className="h-full overflow-y-auto bg-[#060b18] text-slate-200">
      <header className="sticky top-0 z-20 border-b border-white/[0.07] bg-[#081120]/95 pt-[env(safe-area-inset-top,0px)] backdrop-blur-xl">
        <div className="mx-auto flex w-full max-w-3xl items-center justify-between gap-3 px-4 py-3 md:px-8">
          <button type="button" onClick={goHome} className="inline-flex min-h-[44px] items-center gap-2 rounded-xl px-2 text-[13px] font-bold text-slate-300 hover:bg-white/[0.06]">
            <ArrowLeft size={17} className={rtl ? '-scale-x-100' : ''} />
            {c.back}
          </button>
          <LangSwitcher compact />
        </div>
      </header>
      <main className="mx-auto w-full max-w-3xl px-5 pb-[calc(env(safe-area-inset-bottom,0px)+40px)] pt-8 md:px-8">
        <div className="flex items-center gap-3">
          <Logo className="h-14 w-14 shrink-0" />
          <div>
            <p className="text-[11px] font-bold tracking-[0.3em] text-amber-200/80">ALEGDALY TECH</p>
            <h1 className="font-display text-[26px] font-black text-white md:text-[32px]">{c.title}</h1>
          </div>
        </div>
        <p className="mt-2 text-[12px] text-slate-500">{c.updated}: {UPDATED} · www.alegdaly.app</p>
        <p className="mt-6 rounded-2xl border border-emerald-400/20 bg-emerald-500/[0.06] p-4 text-[14px] leading-relaxed text-slate-200">
          <ShieldCheck size={18} className="mb-1 inline text-emerald-300" /> {c.intro}
        </p>
        <div className="mt-8 space-y-7">
          {c.sections.map(([h, items]) => (
            <section key={h}>
              <h2 className="font-display text-[18px] font-extrabold text-amber-100">{h}</h2>
              <ul className="mt-3 list-disc space-y-2 ps-5 text-[14px] leading-relaxed text-slate-300">
                {items.map((t) => <li key={t}>{t}</li>)}
              </ul>
            </section>
          ))}
        </div>
        <p className="mt-10 border-t border-white/[0.07] pt-4 text-center text-[11px] tracking-[0.2em] text-slate-500">© {new Date().getFullYear()} ALEGDALY TECH</p>
      </main>
    </div>
  )
}
