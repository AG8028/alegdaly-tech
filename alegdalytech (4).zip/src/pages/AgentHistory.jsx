import { useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { ReceiptText, HandCoins, Send } from 'lucide-react'
import { useLiveShared } from '../lib/useLive'
import { useSession } from '../components/Session'
import { ACard } from '../components/agent-ui'
import { fmt, dateLabel, dayLabel, moveView, signed, appKey } from '../components/fees'
import { AppTag, AppFilter, AppSummaryCard, useAppTotals } from '../components/brands'
import { tr } from '../components/i18n'
import { scopeFilter } from '../components/scope'

const TAG_CLS = {
  out: 'bg-[#be123c]/10 text-[#be123c]',
  in: 'bg-[#0369a1]/10 text-[#0369a1]',
  cash: 'bg-[#f59e0b]/15 text-[#b45309]',
}

export default function AgentHistory() {
  const session = useSession()
  const { user } = session
  const [params] = useSearchParams()
  const agentId = user?.id || null
  const [kind, setKind] = useState('all')
  const [app, setApp] = useState(() => {
    const a = params.get('app')
    return a === 'NITA' || a === 'AMANA' ? a : 'all'
  })

  const FILTERS = [
    { value: 'all', label: tr('الكل') },
    { value: 'tx', label: tr('حوالات') },
    { value: 'cash', label: tr('تسليم') },
  ]

  const { data, loading } = useLiveShared(session.txColl, {
    order: '-createdAt',
    limit: 300,
    filters: scopeFilter(session, agentId || '__none__'),
  })

  const version = useMemo(() => (data || []).map((r) => `${r.id}:${r.updatedAt || ''}`).join('|'), [data])
  const totals = useAppTotals(agentId, version)

  const rows = useMemo(
    () =>
      (data || []).filter((r) => {
        if (app !== 'all') return r.kind === 'tx' && appKey(r) === app
        return kind === 'all' || r.kind === kind
      }),
    [data, kind, app],
  )

  const grouped = useMemo(() => {
    const map = new Map()
    for (const r of rows) {
      const key = r.day || 'unknown'
      if (!map.has(key)) map.set(key, [])
      map.get(key).push(r)
    }
    return [...map.entries()].sort((a, b) => (a[0] < b[0] ? 1 : -1))
  }, [rows])

  return (
    <div className="space-y-4">
      <div className="rise">
        <p className="text-[12px] font-extrabold text-[#8b9a93]">{tr('كل حركاتي')}</p>
        <h1 className="font-display text-[22px] font-black tracking-tight text-[#0b1a17]">{tr('سجلي')}</h1>
      </div>

      <div className="rise space-y-3">
        <AppFilter value={app} onChange={setApp} theme="light" />
        {app === 'all' ? (
          <div className="grid grid-cols-2 gap-3">
            <AppSummaryCard app="NITA" t={totals.NITA} theme="light" onClick={() => setApp('NITA')} />
            <AppSummaryCard app="AMANA" t={totals.AMANA} theme="light" onClick={() => setApp('AMANA')} />
          </div>
        ) : (
          <AppSummaryCard app={app} t={totals[app]} theme="light" />
        )}
      </div>

      {app === 'all' ? (
        <div className="rise flex gap-2">
          {FILTERS.map((f) => (
            <button
              key={f.value}
              onClick={() => setKind(f.value)}
              className={`flex-1 rounded-2xl border-2 px-3 py-2.5 text-[12.5px] font-extrabold transition ${
                kind === f.value ? 'border-[#0f766e] bg-[#0f766e]/10 text-[#0f766e]' : 'border-[#e6ece7] bg-white text-[#64756d]'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      ) : null}

      {loading ? (
        <p className="py-10 text-center text-[12.5px] text-[#9aa8a1]">{tr('جارٍ التحميل...')}</p>
      ) : grouped.length === 0 ? (
        <ACard className="flex flex-col items-center px-6 py-12 text-center">
          <ReceiptText size={28} className="mb-3 text-[#c3cfc8]" />
          <p className="font-display text-[15px] font-extrabold text-[#42544c]">{tr('لا توجد حركات')}</p>
          <p className="mt-1.5 text-[12px] text-[#9aa8a1]">{tr('سجّل حوالة أو تسليم كاش لتظهر هنا')}</p>
        </ACard>
      ) : (
        <div className="space-y-3">
          {grouped.map(([day, items]) => {
            const net = items.reduce((s, r) => s + (r.kind === 'tx' ? Number(r.cashInHand) || 0 : -(Number(r.amount) || 0)), 0)
            return (
              <ACard key={day} className="overflow-hidden">
                <div className="flex items-center justify-between border-b border-[#eef2ee] bg-[#f8fbf9] px-4 py-2.5">
                  <span className="text-[12px] font-extrabold text-[#42544c]">{day === 'unknown' ? tr('بدون تاريخ') : dayLabel(day)}</span>
                  <span className="text-[11px] font-extrabold text-[#8b9a93]">
                    {tr('الصافي')}: <span className={net >= 0 ? 'text-[#0f766e]' : 'text-[#b45309]'}>{fmt(net)}</span>
                  </span>
                </div>
                <ul className="divide-y divide-[#f1f5f2]">
                  {items.map((t) => {
                    const isTx = t.kind === 'tx'
                    const mv = moveView(t)
                    return (
                      <li key={t.id} className="flex items-center gap-3 px-4 py-3">
                        <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${TAG_CLS[mv.dir]}`}>
                          {isTx ? <Send size={15} /> : <HandCoins size={15} />}
                        </span>
                        <div className="min-w-0 flex-1">
                          <p className="flex items-center gap-1.5 truncate text-[13px] font-extrabold text-[#0b1a17]">
                            <span className={`shrink-0 rounded-md px-1.5 py-0.5 text-[10px] font-extrabold ${TAG_CLS[mv.dir]}`}>{mv.tag}</span>
                            <AppTag app={mv.app} theme="light" />
                            <span className="truncate">{mv.title}</span>
                          </p>
                          <p className="mt-0.5 text-[10.5px] text-[#9aa8a1]">
                            {dateLabel(t.date)}
                            {isTx ? ` · ${tr('مبلغ')} ${fmt(t.amount)}` : ''}
                            {isTx && t.feeMode === 'manual' ? ` · ${tr('عمولة يدوية')}` : ''}
                            {isTx && t.cashGiven > 0 ? ` · ${tr('كاش مستلم')} ${fmt(t.cashGiven)}` : ''}
                          </p>
                        </div>
                        <p className={`font-display shrink-0 text-[13.5px] font-black ${mv.value >= 0 ? 'text-[#0f766e]' : 'text-[#be123c]'}`}>
                          {signed(mv.value)}
                        </p>
                      </li>
                    )
                  })}
                </ul>
              </ACard>
            )
          })}
        </div>
      )}
      <div className="h-4" />
    </div>
  )
}
