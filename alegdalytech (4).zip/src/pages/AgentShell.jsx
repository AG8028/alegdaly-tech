import { useEffect, useRef } from 'react'
import { NavLink, Routes, Route, Navigate, useLocation } from 'react-router-dom'
import { Home, Send, HandCoins, ReceiptText, UserRound } from 'lucide-react'
import { useSession } from '../components/Session'
import AgentHome from './AgentHome'
import AgentTransfer from './AgentTransfer'
import AgentCash from './AgentCash'
import AgentHistory from './AgentHistory'
import AgentProfile from './AgentProfile'
import Logo from '../components/Logo'
import { tr, LangSwitcher } from '../components/i18n'
import { useMode, ThemeToggle, ModeScope } from '../components/theme'
import SignOutButton from '../components/SignOut'
import { SettingsButton } from '../components/SettingsSheet'
import { useTyping } from '../hooks/useTyping'

const NAV_DEF = [
  { to: '/', label: 'الرئيسية', icon: Home, end: true },
  { to: '/new', label: 'حوالة', icon: Send },
  { to: '/cash', label: 'تسليم', icon: HandCoins },
  { to: '/history', label: 'سجلي', icon: ReceiptText },
  { to: '/me', label: 'حسابي', icon: UserRound },
]

function ScrollReset({ scrollRef }) {
  const { pathname } = useLocation()
  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = 0
  }, [pathname, scrollRef])
  return null
}

export default function AgentShell() {
  const { roster, user, isOffice, officeName } = useSession()
  const me = roster[0] || null
  const spaceLabel = isOffice && officeName ? officeName : tr('مساحة الوكيل')
  const name = me?.name || user?.displayName || tr('وكيل')
  const NAV = NAV_DEF.map((n) => ({ ...n, label: tr(n.label) }))

  const scrollRef = useRef(null)
  const typing = useTyping()
  const { mode, toggle } = useMode('light')

  return (
    <ModeScope mode={mode}>
    <div className="skin-light flex h-full bg-[#f4f7f4] text-[#0b1a17]" data-mode={mode}>
      {/* شريط جانبي — الشاشات الكبيرة */}
      <aside className="hidden h-full min-h-0 w-60 shrink-0 flex-col overflow-y-auto overscroll-contain [&>*]:shrink-0 border-e border-[#e3ebe6] bg-white px-4 pb-6 pt-[calc(env(safe-area-inset-top,0px)+22px)] md:flex">
        <div className="flex items-center gap-2.5 px-1">
          <Logo className="h-12 w-12" />
          <div className="leading-tight">
            <p className="font-display text-[14px] font-extrabold text-[#0b1a17]">{isOffice && officeName ? officeName : tr('الأقدالي للتقنية')}</p>
            <p className="text-[9.5px] font-bold tracking-[0.12em] text-[#0f766e]">{tr('مساحة الوكيل')}</p>
          </div>
        </div>

        <nav className="mt-8 flex flex-col gap-1.5">
          {NAV.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `flex items-center gap-3 rounded-2xl px-3 py-2.5 text-[13.5px] font-extrabold transition ${
                  isActive ? 'bg-[#0f766e] text-white' : 'text-[#5b6b63] hover:bg-[#f1f6f2]'
                }`
              }
            >
              <item.icon size={17} />
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="mt-auto space-y-3">
          <LangSwitcher theme="light" />
          <ThemeToggle mode={mode} onToggle={toggle} withLabel />
          <SettingsButton mode={mode} variant="side" />
          <div className="rounded-2xl bg-[#f1f6f2] p-3">
            <p className="text-[10.5px] font-extrabold text-[#8b9a93]">{tr('الوكيل')}</p>
            <p className="font-display truncate text-[15px] font-extrabold text-[#0b1a17]">{name}</p>
          </div>
          <SignOutButton variant="side" mode={mode} />
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        {typing ? <div className="app-top-gap shrink-0 md:hidden" /> : (
        <header className="relative z-20 shrink-0 border-b border-[#e3ebe6] bg-[#f4f7f4]/95 px-4 pb-3 app-top-safe backdrop-blur md:hidden">
          <div className="flex items-center justify-between gap-2">
            <div className="flex min-w-0 flex-1 items-center gap-2.5">
              <Logo className="h-11 w-11 shrink-0" />
              <div className="min-w-0 leading-tight">
                <p className="font-display truncate text-[14px] font-extrabold text-[#0b1a17]">{name}</p>
                <p className="truncate text-[10px] font-bold text-[#0f766e]">{spaceLabel}</p>
              </div>
            </div>
            <div className="flex shrink-0 items-center gap-1.5">
              <SettingsButton mode={mode} />
              <ThemeToggle mode={mode} onToggle={toggle} />
              <SignOutButton mode={mode} />
            </div>
          </div>
          <div className="mt-2 flex justify-end">
            <LangSwitcher theme="light" compact />
          </div>
        </header>
        )}

        <main ref={scrollRef} className="min-h-0 flex-1 overflow-y-auto">
          <ScrollReset scrollRef={scrollRef} />
          <div className={`mx-auto w-full max-w-3xl px-4 py-4 md:px-8 md:py-8 md:pb-10 ${typing ? 'pb-[45vh]' : 'pb-[calc(6rem+env(safe-area-inset-bottom,0px))]'}`}>
            <Routes>
              <Route path="/" element={<AgentHome />} />
              <Route path="/new" element={<AgentTransfer />} />
              <Route path="/cash" element={<AgentCash />} />
              <Route path="/history" element={<AgentHistory />} />
              <Route path="/me" element={<AgentProfile />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </div>
        </main>
      </div>

      {typing ? null : (
      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-[#e3ebe6] bg-white/95 pb-[env(safe-area-inset-bottom,0px)] backdrop-blur-xl md:hidden">
        <div className="flex items-stretch">
          {NAV.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `flex flex-1 flex-col items-center gap-1 py-2.5 text-[10px] font-extrabold transition ${
                  isActive ? 'text-[#0f766e]' : 'text-[#9aa8a1]'
                }`
              }
            >
              {({ isActive }) => (
                <>
                  <span className={`flex h-8 w-12 items-center justify-center rounded-xl transition ${isActive ? 'bg-[#0f766e]/10' : ''}`}>
                    <item.icon size={18} />
                  </span>
                  {item.label}
                </>
              )}
            </NavLink>
          ))}
        </div>
      </nav>
      )}
    </div>
    </ModeScope>
  )
}
