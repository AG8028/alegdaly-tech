import { useEffect } from 'react'

/**
 * سلوك موحّد لكل خانات الإدخال في التطبيق:
 * 1) عند لمس خانة تظهر فوق لوحة المفاتيح تلقائياً (ومعها زر التأكيد إن اتسعت الشاشة).
 * 2) Enter / «التالي» ينقل للخانة التالية، وفي آخر خانة يرسل النموذج.
 * 3) السهمان ↑ ↓ على الكمبيوتر ينقلان بين الخانات.
 */

const NON_TEXT = new Set([
  'checkbox', 'radio', 'button', 'submit', 'reset', 'range', 'color', 'file',
  'date', 'datetime-local', 'month', 'time', 'week', 'image', 'hidden',
])

const FIELD_SEL = [
  'input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]):not([type="reset"]):not([type="file"]):not([type="range"]):not([disabled]):not([readonly])',
  'select:not([disabled])',
  'textarea:not([disabled]):not([readonly])',
].join(',')

const isTextInput = (el) =>
  !!el && ((el.tagName === 'INPUT' && !NON_TEXT.has((el.type || 'text').toLowerCase())) || el.tagName === 'TEXTAREA')

const isVisible = (el) => !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length)

const inApp = (el) => {
  const root = document.getElementById('root')
  return !!root && root.contains(el)
}

const scopeOf = (el) =>
  el.closest('form, [role="dialog"], [data-flow], .confirm-card') || el.closest('main') || document.getElementById('root')

const fieldsIn = (scope) => (scope ? [...scope.querySelectorAll(FIELD_SEL)].filter(isVisible) : [])

function scrollerOf(el) {
  let p = el.parentElement
  while (p && p !== document.body) {
    const oy = getComputedStyle(p).overflowY
    if ((oy === 'auto' || oy === 'scroll') && p.scrollHeight > p.clientHeight + 1) return p
    p = p.parentElement
  }
  return null
}

function submitOf(el) {
  const form = el.closest('form')
  if (!form) return null
  const btn = form.querySelector('button[type="submit"], button:not([type]), input[type="submit"]')
  return btn && isVisible(btn) ? btn : null
}

/** حرّك أقرب منطقة تمرير حتى تظهر الخانة (وزر الإرسال إن أمكن) داخل الجزء المرئي فوق لوحة المفاتيح */
function reveal(el) {
  if (!el || document.activeElement !== el) return
  const sc = scrollerOf(el)
  if (!sc) return
  const vh = window.visualViewport ? window.visualViewport.height : window.innerHeight
  const box = sc.getBoundingClientRect()
  const top = Math.max(box.top, 0) + 16
  const bottom = Math.min(box.bottom, vh) - 16
  if (bottom - top < 60) return
  const r = el.getBoundingClientRect()
  let wantBottom = r.bottom
  const sub = submitOf(el)
  if (sub) {
    const sr = sub.getBoundingClientRect()
    if (sr.bottom > r.bottom && sr.bottom - r.top <= bottom - top) wantBottom = sr.bottom
  }
  let delta = 0
  if (wantBottom > bottom) delta = wantBottom - bottom
  if (r.top - delta < top) delta = r.top - top
  if (Math.abs(delta) > 2) {
    try { sc.scrollBy({ top: delta, behavior: 'smooth' }) } catch { sc.scrollTop += delta }
  }
}

function focusField(el) {
  try { el.focus({ preventScroll: true }) } catch { el.focus() }
  if (isTextInput(el) && typeof el.select === 'function' && el.tagName === 'INPUT') {
    try { const n = el.value.length; el.setSelectionRange(n, n) } catch { /* بعض الأنواع لا تدعم */ }
  }
  ;[60, 320].forEach((ms) => setTimeout(() => reveal(el), ms))
}

/** يضبط زر لوحة المفاتيح على «التالي» أو «تم» حسب موقع الخانة */
function setEnterHint(el) {
  if (!el || el.tagName !== 'INPUT' || el.hasAttribute('data-hint-fixed')) return
  if (el.hasAttribute('enterkeyhint') && !el.hasAttribute('data-hint-auto')) return
  const list = fieldsIn(scopeOf(el))
  const i = list.indexOf(el)
  const hint = i >= 0 && i < list.length - 1 ? 'next' : el.form ? 'go' : 'done'
  el.setAttribute('enterkeyhint', hint)
  el.setAttribute('data-hint-auto', '')
}

export function useFormFlow() {
  useEffect(() => {
    let timers = []
    const clear = () => { timers.forEach(clearTimeout); timers = [] }

    const onFocusIn = (e) => {
      const el = e.target
      if (!(el instanceof HTMLElement) || !inApp(el) || !el.matches(FIELD_SEL)) return
      setEnterHint(el)
      clear()
      // لوحة المفاتيح تظهر تدريجياً — نعيد الضبط أكثر من مرة حتى تستقر
      timers = [120, 350, 700].map((ms) => setTimeout(() => reveal(el), ms))
    }

    const onPointerDown = (e) => {
      const el = e.target
      if (el instanceof HTMLElement && el.tagName === 'INPUT' && inApp(el)) setEnterHint(el)
    }

    let vvTimer = null
    const onViewport = () => {
      clearTimeout(vvTimer)
      vvTimer = setTimeout(() => {
        const el = document.activeElement
        if (el instanceof HTMLElement && inApp(el) && isTextInput(el)) reveal(el)
      }, 80)
    }

    const onKey = (e) => {
      const el = e.target
      if (!(el instanceof HTMLElement) || !inApp(el)) return
      if (e.defaultPrevented || e.isComposing || e.altKey || e.ctrlKey || e.metaKey) return
      const tag = el.tagName
      if (tag !== 'INPUT' && tag !== 'SELECT') return // الخانات متعددة الأسطر تحتفظ بـ Enter
      if (el.hasAttribute('data-no-flow') || el.type === 'search') return
      const enter = e.key === 'Enter'
      const down = e.key === 'ArrowDown'
      const up = e.key === 'ArrowUp'
      if (!enter && !down && !up) return
      // الأسهم: فقط في خانات الكتابة العادية (القوائم والتواريخ تستعمل الأسهم لنفسها)
      if ((down || up) && !isTextInput(el)) return

      const list = fieldsIn(scopeOf(el))
      const i = list.indexOf(el)
      if (i < 0) return

      if (up) {
        if (i > 0) { e.preventDefault(); focusField(list[i - 1]) }
        return
      }
      const next = list[i + 1]
      if (next) {
        e.preventDefault()
        focusField(next)
        return
      }
      if (enter && !el.form) {
        // آخر خانة خارج نموذج: نضغط زر الإجراء الرئيسي إن وُجد، وإلا نغلق لوحة المفاتيح
        e.preventDefault()
        const btn = scopeOf(el)?.querySelector('[data-flow-submit]')
        if (btn) btn.click()
        else el.blur()
      }
      // آخر خانة داخل نموذج: يترك المتصفح يرسل النموذج كالمعتاد
    }

    document.addEventListener('focusin', onFocusIn)
    document.addEventListener('pointerdown', onPointerDown, true)
    document.addEventListener('keydown', onKey)
    window.visualViewport?.addEventListener('resize', onViewport)
    return () => {
      clear()
      clearTimeout(vvTimer)
      document.removeEventListener('focusin', onFocusIn)
      document.removeEventListener('pointerdown', onPointerDown, true)
      document.removeEventListener('keydown', onKey)
      window.visualViewport?.removeEventListener('resize', onViewport)
    }
  }, [])
}

/** مكوّن صغير يُركَّب مرة واحدة في جذر التطبيق */
export function FormFlow() {
  useFormFlow()
  return null
}
