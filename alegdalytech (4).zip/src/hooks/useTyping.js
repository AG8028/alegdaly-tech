import { useEffect, useState } from 'react'

// أنواع الخانات التي لا تفتح لوحة المفاتيح
const NON_TEXT = new Set([
  'checkbox', 'radio', 'button', 'submit', 'reset', 'range', 'color', 'file',
  'date', 'datetime-local', 'month', 'time', 'week', 'image', 'hidden',
])

function isTextField(el) {
  if (!el) return false
  if (el.isContentEditable) return true
  const tag = el.tagName
  if (tag === 'TEXTAREA') return !el.readOnly && !el.disabled
  if (tag === 'INPUT') return !el.readOnly && !el.disabled && !NON_TEXT.has((el.type || 'text').toLowerCase())
  return false
}

/**
 * true أثناء الكتابة في أي خانة على الهاتف (لوحة المفاتيح ظاهرة).
 * يُستعمل لإخفاء الترويسة وشريط الأزرار السفلي حتى تأخذ الخانة كل المساحة.
 */
export function useTyping() {
  const [typing, setTyping] = useState(false)

  useEffect(() => {
    const touch = window.matchMedia ? window.matchMedia('(pointer: coarse)').matches : false
    if (!touch) return undefined

    let outTimer = null
    let active = false
    let sawOpen = false
    const vv = window.visualViewport
    let fullH = vv ? vv.height : window.innerHeight

    const set = (v) => {
      active = v
      if (!v) sawOpen = false
      setTyping(v)
    }

    // إظهار الخانة فوق لوحة المفاتيح يتولاه FormFlow على مستوى التطبيق كله

    const onIn = (e) => {
      if (!isTextField(e.target)) return
      clearTimeout(outTimer)
      set(true)
    }
    const onOut = () => {
      clearTimeout(outTimer)
      outTimer = setTimeout(() => {
        if (!isTextField(document.activeElement)) set(false)
      }, 140)
    }

    // إغلاق لوحة المفاتيح بزر الرجوع مع بقاء المؤشر في الخانة
    const onVv = () => {
      if (!vv) return
      if (!active) {
        fullH = Math.max(fullH, vv.height)
        return
      }
      if (vv.height < fullH - 120) sawOpen = true
      else if (sawOpen && vv.height > fullH - 80) {
        const el = document.activeElement
        set(false)
        try { if (isTextField(el)) el.blur() } catch { /* ignore */ }
      }
    }
    const onRotate = () => {
      setTimeout(() => { fullH = vv ? vv.height : window.innerHeight }, 400)
    }

    document.addEventListener('focusin', onIn)
    document.addEventListener('focusout', onOut)
    vv?.addEventListener('resize', onVv)
    window.addEventListener('orientationchange', onRotate)
    return () => {
      clearTimeout(outTimer)
      document.removeEventListener('focusin', onIn)
      document.removeEventListener('focusout', onOut)
      vv?.removeEventListener('resize', onVv)
      window.removeEventListener('orientationchange', onRotate)
    }
  }, [])

  return typing
}
