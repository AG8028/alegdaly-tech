import { useEffect, useState } from 'react'
import { db } from '../lib/db'
import { useSession } from '../components/Session'
import { scopeFilter } from '../components/scope'

/**
 * إجماليات الوكيل (أو الجميع عند تمرير null) — محسوبة على الخادم حتى تبقى دقيقة
 * مهما كبر عدد الحركات. `version` يعيد الحساب عند أي تحديث حيّ.
 * تتبع المساحة الحالية (ALEGDALY أو مكتب مشترك) تلقائياً.
 */
/**
 * يعيد الحساب فور حفظ أي حركة (حدث 'tx-saved')، ثم مرة واحدة بعد لحظة
 * لتغطية تأخر وصول الصف الجديد إلى التجميع — بدون أي تكرار دوري.
 */
function useTxTick() {
  const [tick, setTick] = useState(0)
  useEffect(() => {
    const timers = []
    const on = () => {
      setTick((t) => t + 1)
      timers.push(setTimeout(() => setTick((t) => t + 1), 1200))
    }
    window.addEventListener('tx-saved', on)
    return () => {
      window.removeEventListener('tx-saved', on)
      timers.forEach(clearTimeout)
    }
  }, [])
  return tick
}

export function useAgentStats(agentId, version) {
  const session = useSession()
  const coll = session.txColl
  const f = scopeFilter(session, agentId)
  const fKey = JSON.stringify(f)
  const [stats, setStats] = useState(null)
  const tick = useTxTick()
  const [retry, setRetry] = useState(0)

  // عند وصول تحديث حيّ: إعادة حساب ثانية بعد لحظة حتى لا يبقى الرصيد متأخراً
  useEffect(() => {
    if (!version) return
    const t = setTimeout(() => setRetry((n) => n + 1), 1200)
    return () => clearTimeout(t)
  }, [version])

  useEffect(() => {
    let alive = true
    Promise.all([
      db.sumShared(coll, 'cashInHand', { ...f, kind: 'tx' }),
      db.sumShared(coll, 'amount', { ...f, kind: 'cash' }),
      db.sumShared(coll, 'myProfit', { ...f, kind: 'tx' }),
      db.sumShared(coll, 'compFee', { ...f, kind: 'tx' }),
      db.countShared(coll, f),
    ])
      .then(([cashIn, handed, profit, comp, count]) => {
        if (!alive) return
        const c = Number(cashIn) || 0
        const h = Number(handed) || 0
        setStats({
          cashIn: c,
          handed: h,
          profit: Number(profit) || 0,
          comp: Number(comp) || 0,
          count: Number(count) || 0,
          balance: c - h,
        })
      })
      .catch(() => {
        if (!alive) return
        setStats((prev) => prev || { cashIn: 0, handed: 0, profit: 0, comp: 0, count: 0, balance: 0 })
      })
    return () => {
      alive = false
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [coll, fKey, version, tick, retry])

  return stats
}

/** أرباح الأيام الأخيرة — تجميع على الخادم حسب اليوم */
export function useDailyProfit(agentId, version, days = 7) {
  const session = useSession()
  const coll = session.txColl
  const f = scopeFilter(session, agentId)
  const fKey = JSON.stringify(f)
  const [rows, setRows] = useState([])
  const tick = useTxTick()

  useEffect(() => {
    let alive = true
    db.groupByShared(coll, 'day', { agg: 'sum', field: 'myProfit', filters: { ...f, kind: 'tx' } })
      .then((res) => {
        if (!alive) return
        // آخر N أيام تقويمية فعلية (اليوم الذي بلا حركات = 0) — وليس آخر N أيام فيها نشاط
        const byKey = {}
        for (const r of res || []) if (r.key) byKey[r.key] = Number(r.value) || 0
        const out = []
        const now = new Date()
        for (let i = days - 1; i >= 0; i--) {
          const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - i, 12)
          const key = d.toLocaleDateString('en-CA')
          out.push({ key, value: byKey[key] || 0 })
        }
        setRows(out.some((r) => r.value !== 0) ? out : [])
      })
      .catch(() => {
        if (alive) setRows([])
      })
    return () => {
      alive = false
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [coll, fKey, version, days, tick])

  return rows
}
