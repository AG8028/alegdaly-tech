// أدوار الفريق — تُستخدم في شاشة إدارة الفريق
export const ROLES = [
  { name: 'agent', label: 'وكيل' },
  { name: 'manager', label: 'مدير', admin: true },
]
