import { useState } from 'react'
import { ShieldCheck, Activity, ArrowLeftRight, Building2, LogIn, UserPlus, KeyRound, ChevronDown, Mail, Lock, MailCheck } from 'lucide-react'
import { auth } from '../lib/auth'
import TeamLogin from './TeamLogin'
import LuxLogin from './LuxLogin'
import AndroidDownload from './AndroidDownload'
import Logo from './Logo'
import { LangSwitcher, tr, useLang, loginLabels } from './i18n'
import { useMode, ThemeToggle, ModeScope } from './theme'

/** خلفية فاخرة: توهّج زمردي وذهبي + شبكة دقيقة + خط صاعد ذهبي (خلف المحتوى، لا تستقبل اللمس) */
function Backdrop() {
  return (
    <div aria-hidden="true" className="pointer-events-none absolute inset-0 z-0 overflow-hidden">
      <div className="lux-base absolute inset-0 bg-[#050a16]" />
      <div className="lux-orb absolute -top-40 start-[-10%] h-[520px] w-[520px] rounded-full bg-emerald-500/20 blur-[120px]" />
      <div className="lux-orb lux-orb-2 absolute bottom-[-180px] end-[-8%] h-[560px] w-[560px] rounded-full bg-amber-400/15 blur-[130px]" />
      <div className="absolute left-1/2 top-1/3 h-[380px] w-[380px] -translate-x-1/2 rounded-full bg-blue-700/20 blur-[120px]" />
      <div className="lux-grid absolute inset-0" />
      <svg className="absolute inset-x-0 bottom-0 h-40 w-full opacity-40 md:h-72 md:opacity-60" viewBox="0 0 1200 300" preserveAspectRatio="none">
        <defs>
          <linearGradient id="luxLine" x1="0" x2="1" y1="0" y2="0">
            <stop offset="0" stopColor="#f5c45e" stopOpacity="0" />
            <stop offset="0.5" stopColor="#f5c45e" stopOpacity="0.9" />
            <stop offset="1" stopColor="#34d399" stopOpacity="0.8" />
          </linearGradient>
          <linearGradient id="luxFill" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0" stopColor="#f5c45e" stopOpacity="0.12" />
            <stop offset="1" stopColor="#f5c45e" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path d="M0 260 C120 250 180 210 280 220 S440 170 540 180 S700 110 800 130 S980 60 1200 30 L1200 300 L0 300 Z" fill="url(#luxFill)" />
        <path className="lux-draw" d="M0 260 C120 250 180 210 280 220 S440 170 540 180 S700 110 800 130 S980 60 1200 30" fill="none" stroke="url(#luxLine)" strokeWidth="2.2" />
      </svg>
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-amber-300/40 to-transparent" />
    </div>
  )
}

function Feature({ icon: Icon, children, delay }) {
  return (
    <div className={`rise flex items-center gap-2.5 rounded-2xl border border-white/[0.08] bg-white/[0.03] px-3.5 py-2.5 ${delay}`}>
      <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-amber-300/25 to-amber-500/5 text-amber-300">
        <Icon size={16} />
      </span>
      <span className="text-[12.5px] font-bold text-slate-200">{children}</span>
    </div>
  )
}

function Step({ n, children }) {
  return (
    <li className="flex items-start gap-2.5">
      <span className="lux-latin mt-px flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-amber-400/15 text-[11.5px] font-black text-amber-200">{n}</span>
      <span className="text-[12.5px] leading-relaxed text-slate-300">{children}</span>
    </li>
  )
}

/** بطاقة دخول بسيطة: اسم المستخدم + كلمة المرور ظاهرين مباشرة، ثم خيار البريد/Google */
function AccountCard() {
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState(null)
  async function open() {
    if (busy) return
    setErr(null)
    setBusy(true)
    try { await auth.signIn() } catch (e) { setErr(e?.message || tr('حدث خطأ، حاول مرة أخرى')) } finally { setBusy(false) }
  }
  return (
    <div className="relative">
      <div className="pointer-events-none absolute -inset-px rounded-[1.6rem] bg-gradient-to-b from-amber-300/40 via-white/5 to-emerald-400/30" />
      <div className="relative rounded-[1.55rem] bg-gradient-to-b from-[#101a30] to-[#080e1c] px-6 pb-6 pt-6 shadow-[0_40px_90px_-30px_rgba(0,0,0,.85)]">
        <h2 className="font-display text-[24px] font-black leading-tight text-white">{tr('تسجيل الدخول')}</h2>
        <p className="mt-1 mb-5 text-[13px] leading-relaxed text-slate-400">{tr('أدخل بياناتك للوصول إلى حسابك')}</p>
        <LuxLogin />
        <div className="my-5 flex items-center gap-3 text-[12px] font-bold text-slate-500">
          <span className="h-px flex-1 bg-white/10" />{tr('أو')}<span className="h-px flex-1 bg-white/10" />
        </div>
        <button type="button" onClick={open} disabled={busy} className="flex w-full touch-manipulation items-center justify-center gap-2 rounded-full border border-white/15 bg-white/[0.04] py-3 text-[14px] font-extrabold text-slate-100 transition hover:bg-white/[0.08] active:scale-[0.99] disabled:opacity-60">
          {busy ? <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" /> : <Mail size={16} className="text-amber-300" />}
          {tr('الدخول بالبريد الإلكتروني أو Google')}
        </button>
        <p className="mt-4 text-center text-[12.5px] text-slate-500">
          {tr('ليس لديك حساب؟')}{' '}
          <button type="button" onClick={open} className="font-extrabold text-amber-200 hover:text-amber-100">{tr('أنشئ حساباً')}</button>
        </p>
        {err ? <p role="alert" className="mt-3 rounded-xl border border-rose-400/30 bg-rose-500/10 px-3 py-2 text-[12px] font-bold text-rose-200">{err}</p> : null}
        <p className="mt-4 flex items-center justify-center gap-1.5 border-t border-white/[0.06] pt-3 text-[11px] text-slate-500">
          <Lock size={12} className="text-emerald-400/70" />{tr('اتصال آمن ومشفّر')}
        </p>
      </div>
    </div>
  )
}

/** (قديم — غير مستخدم) */
function OldAccountCard() {
  const [tab, setTab] = useState('login')
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState(null)

  async function open() {
    if (busy) return
    setErr(null)
    setBusy(true)
    try {
      await auth.signIn()
    } catch (e) {
      setErr(e?.message || tr('حدث خطأ، حاول مرة أخرى'))
    } finally {
      setBusy(false)
    }
  }

  const flip = typeof document !== 'undefined' && document.documentElement.dir === 'rtl' ? '-scale-x-100' : ''
  const spin = <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
  const tabCls = (on) =>
    `flex flex-1 touch-manipulation items-center justify-center gap-1.5 rounded-xl py-2.5 text-[13.5px] font-extrabold transition ${
      on ? 'bg-gradient-to-b from-white/[0.12] to-white/[0.05] text-white shadow-[inset_0_1px_0_rgba(255,255,255,.08)]' : 'text-slate-400 hover:text-slate-200'
    }`

  return (
    <div className="relative">
      <div className="pointer-events-none absolute -inset-px rounded-[1.6rem] bg-gradient-to-b from-amber-300/40 via-white/5 to-emerald-400/30" />
      <div className="relative rounded-[1.55rem] bg-gradient-to-b from-[#101a30] to-[#080e1c] px-6 pb-6 pt-6 shadow-[0_40px_90px_-30px_rgba(0,0,0,.85)]">
        <div className="flex gap-1 rounded-2xl border border-white/[0.07] bg-black/30 p-1">
          <button type="button" onClick={() => { setTab('login'); setErr(null) }} className={tabCls(tab === 'login')}>
            <LogIn size={15} className={flip} /> {tr('تسجيل الدخول')}
          </button>
          <button type="button" onClick={() => { setTab('signup'); setErr(null) }} className={tabCls(tab === 'signup')}>
            <UserPlus size={15} /> {tr('إنشاء حساب')}
          </button>
        </div>

        {tab === 'login' ? (
          <div key="login" className="rise">
            <h2 className="font-display mt-5 text-[22px] font-black leading-tight text-white">{tr('أهلاً بعودتك')}</h2>
            <p className="mt-1.5 text-[13px] leading-relaxed text-slate-400">{tr('ادخل بالبريد الإلكتروني وكلمة المرور التي أنشأت بها حسابك.')}</p>
            <div className="mt-4 space-y-2 rounded-2xl border border-white/[0.06] bg-white/[0.02] p-3">
              <p className="flex items-center gap-2 text-[12.5px] font-bold text-slate-300"><Mail size={14} className="text-amber-300" />{tr('البريد الإلكتروني = اسم المستخدم')}</p>
              <p className="flex items-center gap-2 text-[12.5px] font-bold text-slate-300"><Lock size={14} className="text-amber-300" />{tr('كلمة المرور')}</p>
            </div>
            <button
              type="button"
              onClick={open}
              disabled={busy}
              className="mt-4 flex w-full touch-manipulation items-center justify-center gap-2 rounded-full bg-gradient-to-br from-[#fbe3a1] via-[#f0b847] to-[#c98a22] py-3.5 text-[15.5px] font-black text-[#1a1206] shadow-[0_14px_32px_-12px_rgba(240,184,71,.6)] transition hover:brightness-105 active:scale-[0.99] disabled:opacity-60"
            >
              {busy ? spin : <LogIn size={18} className={flip} />} {tr('تسجيل الدخول')}
            </button>
            <p className="mt-3 text-center text-[12px] text-slate-500">
              {tr('ليس لديك حساب؟')}{' '}
              <button type="button" onClick={() => setTab('signup')} className="font-extrabold text-amber-200 hover:text-amber-100">{tr('أنشئ حساباً')}</button>
            </p>
          </div>
        ) : (
          <div key="signup" className="rise">
            <h2 className="font-display mt-5 text-[22px] font-black leading-tight text-white">{tr('حساب جديد')}</h2>
            <ol className="mt-3 space-y-2.5">
              <Step n="1">{tr('اضغط «إنشاء حساب» ثم اكتب بريدك وكلمة مرور جديدة (أو اختر Google).')}</Step>
              <Step n="2">{tr('يصلك رمز تأكيد على البريد — مرة واحدة فقط.')}</Step>
              <Step n="3">{tr('اختر: صاحب مكتب أو وكيل، وابدأ العمل.')}</Step>
            </ol>
            <button
              type="button"
              onClick={open}
              disabled={busy}
              className="mt-5 flex w-full touch-manipulation items-center justify-center gap-2 rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600 py-3.5 text-[15.5px] font-black text-[#04140d] shadow-[0_14px_32px_-12px_rgba(16,185,129,.55)] transition hover:brightness-105 active:scale-[0.99] disabled:opacity-60"
            >
              {busy ? spin : <UserPlus size={18} />} {tr('إنشاء حساب')}
            </button>
            <p className="mt-2 text-center text-[11.5px] text-slate-500">{tr('في النافذة اضغط رابط «إنشاء حساب» في الأسفل.')}</p>
            <p className="mt-3 text-center text-[12px] text-slate-500">
              {tr('لديك حساب؟')}{' '}
              <button type="button" onClick={() => setTab('login')} className="font-extrabold text-amber-200 hover:text-amber-100">{tr('سجّل دخولك')}</button>
            </p>
          </div>
        )}

        {err ? (
          <p role="alert" className="mt-3 rounded-xl border border-rose-400/30 bg-rose-500/10 px-3 py-2 text-[12px] font-bold text-rose-200">{err}</p>
        ) : null}

        <p className="mt-4 flex items-start gap-2 border-t border-white/[0.06] pt-3 text-[11.5px] leading-relaxed text-slate-500">
          <MailCheck size={14} className="mt-0.5 shrink-0 text-emerald-400/70" />
          {tr('نسيت كلمة المرور؟ اضغط «تسجيل الدخول» ثم «نسيت كلمة المرور»، يصلك رمز على البريد.')}
        </p>
      </div>
    </div>
  )
}

/** دخول وكلاء ALEGDALY القدامى باسم المستخدم — مطوي افتراضياً */
function ClassicLogin() {
  const [open, setOpen] = useState(false)
  return (
    <div className="mt-3 rounded-2xl border border-white/[0.08] bg-[#0a1222]">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex w-full touch-manipulation items-center justify-between gap-3 px-4 py-3.5 text-start"
      >
        <span className="flex items-center gap-2.5">
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-amber-400/10 text-amber-300">
            <KeyRound size={15} />
          </span>
          <span>
            <span className="block text-[13px] font-extrabold text-slate-100">{tr('دخول باسم مستخدم من الإدارة')}</span>
            <span className="block text-[11px] font-bold text-slate-500">{tr('لوكلاء ALEGDALY الذين أعطتهم الإدارة اسماً ورمزاً')}</span>
          </span>
        </span>
        <ChevronDown size={18} className={`shrink-0 text-slate-400 transition ${open ? 'rotate-180' : ''}`} />
      </button>
      {open ? (
        <div className="border-t border-white/[0.06] px-4 pb-4 pt-3.5">
          <LuxLogin />
        </div>
      ) : null}
    </div>
  )
}

export default function LuxGate() {
  const { lang } = useLang()
  const { mode, toggle } = useMode('dark')
  const year = new Date().getFullYear()
  let inviting = false
  try { inviting = !!new URLSearchParams(window.location.search).get('join') } catch { /* ignore */ }

  return (
    <ModeScope mode={mode}>
      <div className="lux-gate skin-dark relative h-full overflow-hidden" data-dir={lang === 'ar' ? 'rtl' : 'ltr'} data-mode={mode}>
        <Backdrop />

        <div className="relative z-10 h-full overflow-y-auto">
          <div className="mx-auto flex min-h-full w-full max-w-6xl flex-col px-5 pb-[calc(env(safe-area-inset-bottom,0px)+20px)] pt-[calc(env(safe-area-inset-top,0px)+16px)] md:px-10">
            <header className={`flex items-center justify-between gap-3 ${lang === 'ar' ? 'flex-row-reverse' : ''}`}>
              <div className="flex items-center gap-2">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 shadow-[0_0_10px_2px_rgba(52,211,153,0.6)]" />
                <span className="lux-latin text-[11px] font-bold tracking-[0.32em] text-amber-200/70">ALEGDALY</span>
              </div>
              <div className="flex items-center gap-1.5">
                <ThemeToggle mode={mode} onToggle={toggle} />
                <LangSwitcher compact />
              </div>
            </header>

            <div className="flex flex-1 flex-col items-center justify-center gap-8 py-8 md:grid md:grid-cols-2 md:items-center md:gap-16 md:py-12">
              <section className="flex w-full max-w-md flex-col items-center text-center md:max-w-none md:items-start md:text-start">
                <div className="rise relative">
                  <div className="glow-pulse pointer-events-none absolute inset-0 rounded-full bg-amber-400/25 blur-3xl" />
                  <div className="lux-ring relative rounded-[2rem] p-[1.5px]">
                    <div className="lux-logo-inner rounded-[calc(2rem-1.5px)] bg-[#081226]/80 p-3">
                      <Logo className="h-20 w-20 md:h-28 md:w-28" />
                    </div>
                  </div>
                </div>

                <h1 className="rise mt-5 font-display text-[30px] font-black leading-[1.3] text-white [animation-delay:120ms] md:text-[52px]">
                  {tr('عالم التحويلات')}
                  <br />
                  <span className="lux-gold-text">{tr('بأناقة واحترافية')}</span>
                </h1>

                <div className="rise mt-3 flex items-center gap-3 [animation-delay:180ms]">
                  <span className="h-px w-8 bg-gradient-to-r from-transparent to-amber-300/70" />
                  <span className="lux-latin text-[12px] font-bold tracking-[0.45em] text-amber-200/90">ALEGDALY TECH</span>
                  <span className="h-px w-8 bg-gradient-to-l from-transparent to-amber-300/70" />
                </div>

                <p className="rise mt-4 max-w-sm text-[13px] leading-relaxed text-slate-300 [animation-delay:240ms] md:max-w-md md:text-[14.5px]">
                  {tr('تطبيق لمكاتب تحويل الأموال: إدارة الوكلاء، تسجيل حوالات نيتا وأمانة، حساب الرسوم والعمولات، ومتابعة الأرصدة اليومية.')}
                </p>

                <div className="mt-6 hidden w-full max-w-sm flex-col gap-2.5 md:flex">
                  <Feature icon={ArrowLeftRight} delay="[animation-delay:320ms]">
                    <span className="text-orange-400">NITA</span>
                    <span className="mx-1.5 text-slate-500">·</span>
                    <span className="text-emerald-400">AMANA</span>
                  </Feature>
                  <Feature icon={Activity} delay="[animation-delay:380ms]">{tr('أرصدة لحظية')}</Feature>
                  <Feature icon={Building2} delay="[animation-delay:440ms]">{tr('مساحة خاصة لكل مكتب')}</Feature>
                </div>
              </section>

              <section className="flex w-full justify-center md:justify-end">
                <div className="w-full max-w-sm">
                  {inviting ? (
                    <div className="lux-card relative">
                      <TeamLogin appName={tr('الأقدالي للتقنية')} labels={loginLabels(lang)} />
                    </div>
                  ) : (
                    <>
                      <AccountCard />
                    </>
                  )}
                  <button
                    type="button"
                    onClick={() => { window.location.hash = '#/offices' }}
                    className="mt-4 flex w-full touch-manipulation items-center justify-center gap-2 py-2 text-[12.5px] font-bold text-amber-200/80 hover:text-amber-100"
                  >
                    <Building2 size={15} /> {tr('تملك مكتب تحويل؟ شاهد الباقات')}
                  </button>
                  <AndroidDownload />
                </div>
              </section>
            </div>

            <footer className="flex flex-col items-center justify-center gap-1 text-center text-[11px] text-slate-500 md:flex-row md:gap-2">
              <span className="lux-latin tracking-[0.2em] text-slate-400">© {year} ALEGDALY TECH</span>
              <span className="hidden md:inline">·</span>
              <span>{tr('جميع الحقوق محفوظة')}</span>
              <span className="hidden md:inline">·</span>
              <a href="/privacy" className="inline-flex min-h-[32px] items-center font-bold text-amber-200/90 underline underline-offset-4 hover:text-amber-100">{tr('سياسة الخصوصية')}</a>
            </footer>
          </div>
        </div>
      </div>
    </ModeScope>
  )
}
