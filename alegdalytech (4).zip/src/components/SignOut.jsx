import { useState } from 'react'
import { createPortal } from 'react-dom'
import { LogOut } from 'lucide-react'
import { auth } from '../lib/auth'
import { tr } from './i18n'
import { forgetOtp } from './OtpGate'

/** زر تسجيل الخروج — مع تأكيد قبل الخروج */
export default function SignOutButton({ variant = 'compact', mode = 'dark' }) {
  const [ask, setAsk] = useState(false)
  const light = mode === 'light'

  const base =
    variant === 'full'
      ? 'flex w-full items-center justify-center gap-2 rounded-2xl px-4 py-3 text-[14px] font-extrabold'
      : variant === 'side'
        ? 'flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-[13px] font-bold'
        : 'flex h-9 items-center gap-1.5 rounded-xl px-2.5 text-[12px] font-extrabold'

  const tone = light
    ? 'border border-rose-200 bg-rose-50 text-rose-700 hover:bg-rose-100'
    : 'border border-rose-400/25 bg-rose-500/10 text-rose-300 hover:bg-rose-500/20'

  return (
    <>
      <button type="button" onClick={() => setAsk(true)} className={`signout-btn ${base} ${tone} transition active:scale-[0.97]`}>
        <LogOut size={16} className="rtl:rotate-180" />
        <span>{variant === 'compact' ? tr('خروج') : tr('تسجيل الخروج')}</span>
      </button>

      {ask ? createPortal(
        <div
          className={`fixed inset-0 z-40 flex items-center justify-center bg-black/60 p-5 backdrop-blur-sm`}
          style={{ height: 'var(--visual-height, 100dvh)' }}
          onClick={() => setAsk(false)}
        >
          <div
            dir={document.documentElement.dir || 'rtl'}
            onClick={(e) => e.stopPropagation()}
            className={`rise w-full max-w-sm rounded-3xl p-5 shadow-2xl ${
              light ? 'bg-white text-slate-900' : 'border border-white/10 bg-[#0b1424] text-slate-100'
            }`}
          >
            <span className={`mx-auto flex h-12 w-12 items-center justify-center rounded-2xl ${light ? 'bg-rose-50 text-rose-600' : 'bg-rose-500/15 text-rose-300'}`}>
              <LogOut size={22} className="rtl:rotate-180" />
            </span>
            <p className="font-display mt-3 text-center text-[18px] font-black">{tr('تسجيل الخروج')}</p>
            <p className={`mt-1 text-center text-[13px] ${light ? 'text-slate-500' : 'text-slate-400'}`}>
              {tr('هل تريد الخروج من حسابك على هذا الجهاز؟')}
            </p>
            <div className="mt-5 grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setAsk(false)}
                className={`rounded-2xl py-3 text-[14px] font-bold ${light ? 'bg-slate-100 text-slate-700' : 'bg-white/[0.06] text-slate-200'}`}
              >
                {tr('إلغاء')}
              </button>
              <button
                type="button"
                onClick={() => { setAsk(false); forgetOtp(auth.getCurrentUser()?.id); auth.signOut() }}
                className="keep-color rounded-2xl bg-rose-600 py-3 text-[14px] font-extrabold text-white hover:bg-rose-500"
              >
                {tr('خروج')}
              </button>
            </div>
          </div>
        </div>,
        document.body
      ) : null}
    </>
  )
}
