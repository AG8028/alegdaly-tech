import { Users } from 'lucide-react'
import { tr } from './i18n'

export default function AgentPicker({ options, value, onChange, allowAll = true }) {
  const items = allowAll ? [{ userId: null, name: tr('الجميع') }, ...options] : options
  if (!options.length) return null

  return (
    <div className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-1 md:mx-0 md:flex-wrap md:overflow-visible md:px-0">
      {items.map((a) => {
        const active = a.userId === value
        return (
          <button
            key={a.userId || 'all'}
            type="button"
            onClick={() => onChange(a.userId)}
            className={`flex shrink-0 items-center gap-1.5 rounded-full border px-3.5 py-2 text-[12.5px] font-bold transition active:scale-[0.97] ${
              active
                ? 'border-emerald-400/60 bg-emerald-500/15 text-emerald-200'
                : 'border-white/10 bg-white/[0.03] text-slate-400 hover:border-white/20 hover:text-slate-200'
            }`}
          >
            <Users size={13} className={active ? 'text-emerald-300' : 'text-slate-500'} />
            {a.name}
          </button>
        )
      })}
    </div>
  )
}
