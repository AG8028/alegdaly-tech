// مكوّنات واجهة الوكيل — تصميم فاتح مختلف عن لوحة الإدارة

export const aInput =
  'w-full rounded-2xl border-2 border-[#dfe8e2] bg-white px-4 py-3.5 text-[15px] font-bold text-[#0b1a17] outline-none transition placeholder:font-normal placeholder:text-[#9aa8a1] focus:border-[#0f766e] focus:ring-4 focus:ring-[#0f766e]/10'

export function ACard({ children, className = '', ...rest }) {
  return (
    <div className={`rounded-[26px] border border-[#e6ece7] bg-white shadow-[0_10px_30px_-24px_rgba(6,40,32,0.55)] ${className}`} {...rest}>
      {children}
    </div>
  )
}

export function AField({ label, hint, children }) {
  return (
    <label className="block">
      <span className="mb-2 block text-[12px] font-extrabold text-[#54655d]">{label}</span>
      {children}
      {hint ? <span className="mt-1.5 block text-[11.5px] leading-relaxed text-[#8b9a93]">{hint}</span> : null}
    </label>
  )
}

export function ABtn({ children, tone = 'primary', className = '', ...rest }) {
  const tones = {
    primary:
      'bg-[#0f766e] text-white shadow-[0_14px_30px_-16px_rgba(15,118,110,0.95)] hover:bg-[#0d6a63]',
    amber: 'bg-[#f59e0b] text-[#3a2400] shadow-[0_14px_30px_-16px_rgba(245,158,11,0.9)] hover:bg-[#e5900a]',
    soft: 'bg-[#eef4f0] text-[#0f766e] hover:bg-[#e3ede8]',
    ghost: 'border-2 border-[#e3ebe6] bg-white text-[#42544c] hover:bg-[#f6faf7]',
    danger: 'bg-[#fef2f2] text-[#b91c1c] border-2 border-[#fbd5d5] hover:bg-[#fee2e2]',
  }
  return (
    <button
      className={`w-full rounded-2xl px-4 py-3.5 text-[15px] font-extrabold transition active:scale-[0.985] disabled:opacity-50 ${tones[tone]} ${className}`}
      {...rest}
    >
      {children}
    </button>
  )
}

export function AChips({ options, value, onChange }) {
  return (
    <div className={`grid gap-2 ${options.length === 3 ? 'grid-cols-3' : 'grid-cols-2'}`}>
      {options.map((o) => {
        const active = o.value === value
        return (
          <button
            key={String(o.value)}
            type="button"
            onClick={() => onChange(o.value)}
            className={`rounded-2xl border-2 px-3 py-3 text-[13px] font-extrabold transition active:scale-[0.98] ${
              active
                ? 'border-[#0f766e] bg-[#0f766e]/10 text-[#0f766e]'
                : 'border-[#e6ece7] bg-white text-[#64756d] hover:border-[#cfdcd5]'
            }`}
          >
            {o.label}
          </button>
        )
      })}
    </div>
  )
}

export function AStat({ label, value, tone = 'text-[#0b1a17]', sub }) {
  return (
    <div className="rounded-2xl border border-[#e6ece7] bg-white px-3 py-3">
      <p className="text-[10.5px] font-extrabold text-[#8b9a93]">{label}</p>
      <p className={`mt-1 text-[16px] font-black leading-none ${tone}`}>{value}</p>
      {sub ? <p className="mt-1 text-[10px] text-[#9aa8a1]">{sub}</p> : null}
    </div>
  )
}
