import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react'
import { CheckCircle2, AlertTriangle, Info, Trash2, ShieldAlert } from 'lucide-react'
import Logo from './Logo'
import { tr } from './i18n'

const ToastCtx = createContext(() => {})
export const useToast = () => useContext(ToastCtx)

/**
 * نافذة تأكيد بتصميم التطبيق — بديل نوافذ النظام القديمة (التي لا تعمل أحياناً في تطبيق الأندرويد).
 * const ask = useConfirm(); if (!(await ask({ title, text, confirmLabel, danger: true }))) return
 */
const ConfirmCtx = createContext(async () => false)
export const useConfirm = () => useContext(ConfirmCtx)

function ConfirmHost({ req, onClose }) {
  const okRef = useRef(null)
  useEffect(() => {
    if (!req) return undefined
    const t = setTimeout(() => okRef.current?.focus(), 50)
    const onKey = (e) => { if (e.key === 'Escape') onClose(false) }
    window.addEventListener('keydown', onKey)
    return () => { clearTimeout(t); window.removeEventListener('keydown', onKey) }
  }, [req, onClose])
  if (!req) return null
  const danger = req.danger !== false
  const Icon = req.icon || (danger ? Trash2 : ShieldAlert)
  return (
    <div
      className="confirm-backdrop fixed inset-0 z-40 flex items-end justify-center bg-[#02050c]/75 px-4 pb-[calc(env(safe-area-inset-bottom,0px)+16px)] backdrop-blur-md md:items-center md:pb-4"
      style={{ height: 'var(--visual-height, 100dvh)' }}
      onClick={() => onClose(false)}
      role="dialog"
      aria-modal="true"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="confirm-card relative w-full max-w-sm overflow-hidden rounded-[1.75rem] border border-white/10 bg-gradient-to-b from-[#0f1a2e] to-[#070d1a] p-5 text-slate-100 shadow-[0_30px_80px_-20px_rgba(0,0,0,0.9)]"
      >
        <div className={`pointer-events-none absolute -top-24 start-1/2 h-48 w-48 -translate-x-1/2 rounded-full blur-3xl ${danger ? 'bg-rose-500/25' : 'bg-emerald-500/25'}`} />
        <div className="relative flex items-center justify-between">
          <Logo className="h-9 w-9 opacity-90" />
          <span className="text-[9.5px] font-extrabold tracking-[0.18em] text-emerald-400/70">ALEGDALY TECH</span>
        </div>
        <div className="relative mt-4 flex flex-col items-center text-center">
          <span className={`flex h-16 w-16 items-center justify-center rounded-2xl border ${danger ? 'border-rose-400/30 bg-rose-500/15 text-rose-300' : 'border-emerald-400/30 bg-emerald-500/15 text-emerald-300'}`}>
            <Icon size={28} />
          </span>
          <p className="font-display mt-4 text-[18px] font-black leading-snug text-white">{req.title}</p>
          {req.text ? <p className="mt-2 text-[12.5px] leading-relaxed text-slate-400">{req.text}</p> : null}
        </div>
        <div className="relative mt-5 grid grid-cols-2 gap-2.5">
          <button
            type="button"
            onClick={() => onClose(false)}
            className="rounded-2xl border border-white/12 bg-white/[0.05] py-3.5 text-[14px] font-extrabold text-slate-200 transition hover:bg-white/[0.09] active:scale-[0.98]"
          >
            {req.cancelLabel || tr('إلغاء')}
          </button>
          <button
            ref={okRef}
            type="button"
            onClick={() => onClose(true)}
            className={`rounded-2xl py-3.5 text-[14px] font-extrabold transition active:scale-[0.98] ${
              danger
                ? 'bg-gradient-to-l from-rose-600 to-rose-500 text-white shadow-[0_10px_30px_-12px_rgba(244,63,94,0.9)] hover:from-rose-500 hover:to-rose-400'
                : 'bg-gradient-to-l from-emerald-500 to-emerald-400 text-emerald-950 shadow-[0_10px_30px_-12px_rgba(16,185,129,0.9)]'
            }`}
          >
            {req.confirmLabel || tr(danger ? 'حذف' : 'تأكيد')}
          </button>
        </div>
      </div>
    </div>
  )
}

const ICONS = {
  ok: CheckCircle2,
  err: AlertTriangle,
  info: Info,
}
const TONES = {
  // خلفية صلبة داكنة حتى تبقى الرسالة مقروءة فوق أي واجهة (فاتحة أو داكنة)
  ok: 'toast-ok border-emerald-400/50 bg-[#05261f] text-emerald-50',
  err: 'toast-err border-rose-400/50 bg-[#2a0b14] text-rose-50',
  info: 'toast-info border-amber-400/50 bg-[#2a1d06] text-amber-50',
}

export function ToastProvider({ children }) {
  const [items, setItems] = useState([])

  const push = useCallback((msg, kind = 'ok') => {
    const id = Math.random().toString(36).slice(2)
    setItems((x) => [...x, { id, msg, kind }])
    setTimeout(() => setItems((x) => x.filter((i) => i.id !== id)), 3600)
  }, [])

  const [req, setReq] = useState(null)
  const ask = useCallback((opts) => new Promise((resolve) => {
    setReq({ ...(typeof opts === 'string' ? { title: opts } : opts), resolve })
  }), [])
  const closeConfirm = useCallback((v) => {
    setReq((r) => { r?.resolve(v); return null })
  }, [])

  return (
    <ToastCtx.Provider value={push}>
    <ConfirmCtx.Provider value={ask}>
      {children}
      <ConfirmHost req={req} onClose={closeConfirm} />
      <div className="pointer-events-none fixed inset-x-0 top-[calc(env(safe-area-inset-top,0px)+10px)] z-40 flex flex-col items-center gap-2 px-4">
        {items.map((i) => {
          const Icon = ICONS[i.kind] || Info
          return (
            <div
              key={i.id}
              className={`rise flex w-full max-w-sm items-center gap-2.5 rounded-2xl border px-4 py-3 text-[13px] font-bold shadow-2xl backdrop-blur-xl ${TONES[i.kind] || TONES.info}`}
            >
              <Icon size={18} className="shrink-0" />
              <span className="leading-snug">{i.msg}</span>
            </div>
          )
        })}
      </div>
    </ConfirmCtx.Provider>
    </ToastCtx.Provider>
  )
}

export function Card({ children, className = '', ...rest }) {
  return (
    <div
      className={`rounded-3xl border border-white/[0.08] bg-white/[0.035] backdrop-blur-sm ${className}`}
      {...rest}
    >
      {children}
    </div>
  )
}

export function SectionTitle({ children, hint }) {
  return (
    <div className="mb-3 flex items-baseline justify-between gap-3">
      <h2 className="font-display text-[17px] font-extrabold tracking-tight text-slate-100">{children}</h2>
      {hint ? <span className="text-[11px] font-bold text-slate-500">{hint}</span> : null}
    </div>
  )
}

export function Segmented({ options, value, onChange, className = '' }) {
  return (
    <div className={`flex gap-1.5 rounded-2xl border border-white/[0.07] bg-black/25 p-1.5 ${className}`}>
      {options.map((o) => {
        const active = o.value === value
        return (
          <button
            key={o.value}
            type="button"
            onClick={() => onChange(o.value)}
            className={`flex-1 rounded-xl px-2 py-2 text-[12.5px] font-bold transition active:scale-[0.98] ${
              active
                ? 'bg-emerald-500/20 text-emerald-200 shadow-[inset_0_0_0_1px_rgba(16,185,129,0.45)]'
                : 'text-slate-400 hover:bg-white/[0.05] hover:text-slate-200'
            }`}
          >
            {o.label}
          </button>
        )
      })}
    </div>
  )
}

export function Field({ label, children, hint }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-[11.5px] font-bold tracking-wide text-slate-400">{label}</span>
      {children}
      {hint ? <span className="mt-1 block text-[11px] text-slate-500">{hint}</span> : null}
    </label>
  )
}

export const fieldCls =
  'w-full rounded-xl border border-white/10 bg-black/25 px-3.5 py-3 text-[15px] font-bold text-slate-100 outline-none transition placeholder:font-normal placeholder:text-slate-600 focus:border-emerald-400/60 focus:bg-black/40'

export function PrimaryBtn({ children, className = '', ...rest }) {
  return (
    <button
      className={`w-full rounded-xl bg-gradient-to-l from-emerald-500 to-emerald-400 px-4 py-3.5 text-[15px] font-extrabold text-emerald-950 shadow-[0_10px_30px_-12px_rgba(16,185,129,0.9)] transition active:scale-[0.985] disabled:opacity-50 ${className}`}
      {...rest}
    >
      {children}
    </button>
  )
}

export function GhostBtn({ children, className = '', ...rest }) {
  return (
    <button
      className={`rounded-xl border border-white/12 bg-white/[0.04] px-4 py-2.5 text-[13px] font-bold text-slate-200 transition hover:bg-white/[0.08] active:scale-[0.98] ${className}`}
      {...rest}
    >
      {children}
    </button>
  )
}

export function Spinner({ className = '' }) {
  return (
    <div className={`flex items-center justify-center py-16 ${className}`}>
      <div className="h-7 w-7 animate-spin rounded-full border-2 border-white/15 border-t-emerald-400" />
    </div>
  )
}

export function EmptyState({ icon: Icon, title, text, action }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-3xl border border-dashed border-white/10 px-6 py-12 text-center">
      {Icon ? <Icon size={30} className="mb-3 text-slate-600" /> : null}
      <p className="font-display text-[15px] font-extrabold text-slate-200">{title}</p>
      {text ? <p className="mt-1.5 max-w-xs text-[12.5px] leading-relaxed text-slate-500">{text}</p> : null}
      {action ? <div className="mt-4">{action}</div> : null}
    </div>
  )
}
