import { useState } from 'react'
import { Smartphone, Download } from 'lucide-react'
import { download } from '../lib/download'
import { tr } from './i18n'

/** زر «تحميل تطبيق أندرويد» — يجلب أحدث APK لحظة الضغط من نطاق التطبيق */
export default function AndroidDownload() {
  const [busy, setBusy] = useState(false)
  const [msg, setMsg] = useState(null)

  // داخل التطبيق المثبّت نفسه لا داعي للزر
  let native = false
  try { native = !!window.Capacitor?.isNativePlatform?.() } catch { native = false }
  if (native) return null

  async function get() {
    if (busy) return
    setBusy(true)
    setMsg(null)
    try {
      const app = await download.androidApp()
      if (!app) {
        setMsg(tr('تطبيق أندرويد غير متاح حالياً'))
        return
      }
      await download.saveFile(app.url, app.fileName || 'alegdaly.apk')
      setMsg(tr('بدأ التحميل — افتح الملف بعد اكتماله لتثبيت التطبيق.'))
    } catch {
      setMsg(tr('تعذّر التحميل، حاول مرة أخرى'))
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="mt-4 w-full">
      <button
        type="button"
        onClick={get}
        disabled={busy}
        className="group flex w-full items-center gap-3 rounded-2xl border border-emerald-400/25 bg-emerald-500/[0.07] px-4 py-3 text-start backdrop-blur transition hover:border-emerald-300/50 hover:bg-emerald-500/[0.12] disabled:opacity-60"
      >
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-emerald-400/15 text-emerald-300">
          {busy ? (
            <span className="h-4 w-4 animate-spin rounded-full border-2 border-emerald-300/30 border-t-emerald-300" />
          ) : (
            <Smartphone size={19} />
          )}
        </span>
        <span className="min-w-0 flex-1">
          <span className="block text-[13.5px] font-extrabold text-emerald-100">{tr('تحميل تطبيق أندرويد')}</span>
          <span className="block text-[11px] text-slate-400">{tr('أحدث نسخة · يتحدّث تلقائياً')}</span>
        </span>
        <Download size={17} className="shrink-0 text-emerald-300 transition group-hover:translate-y-0.5" />
      </button>
      {msg && <p className="mt-2 text-center text-[11.5px] font-bold text-slate-400">{msg}</p>}
    </div>
  )
}
