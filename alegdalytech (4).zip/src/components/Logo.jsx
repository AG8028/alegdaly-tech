import { useState } from 'react'

/** الشعار بخلفية شفافة — بدون أي إطار أبيض */
export const LOGO_URL =
  'https://api.whacka.app/storage/v1/object/public/app-images/5f7f7eca-f5e4-4c02-830d-fa88b7a3b0df/images/alegdaly_logo_clean.png?v=cc483d54b3'

/** شعار الأقدالي — مع بديل أنيق إن تعذّر تحميل الصورة */
export default function Logo({ className = 'h-11 w-11', rounded = 'rounded-2xl' }) {
  const [failed, setFailed] = useState(false)
  if (failed) {
    return (
      <div
        className={`flex shrink-0 items-center justify-center bg-gradient-to-bl from-[#0f5a4a] to-[#14245a] font-display font-black text-amber-300 ${rounded} ${className}`}
      >
        A
      </div>
    )
  }
  return (
    <img
      src={LOGO_URL}
      alt="ALEGDALY"
      onError={() => setFailed(true)}
      className={`shrink-0 select-none object-contain drop-shadow-[0_8px_18px_rgba(0,0,0,0.35)] ${className}`}
      draggable={false}
    />
  )
}
