import { useState } from 'react'
import { Eye, EyeOff, LogIn } from 'lucide-react'
import { team } from '../lib/team'
import { foldTypedDigits } from '../lib/_typed-digits.js'
import { teamFailureKey } from '../lib/_team-answers.js'
import { tr, useLang } from './i18n'

const ERR = {
  wrongPin: 'اسم المستخدم أو الرمز السري غير صحيح',
  wrongPassword: 'اسم المستخدم أو كلمة المرور غير صحيحة',
  tooManyTries: 'محاولات كثيرة، حاول بعد قليل',
  pendingApproval: 'حسابك بانتظار موافقة الإدارة',
  offline: 'لا يوجد اتصال بالإنترنت',
  genericError: 'حدث خطأ، حاول مرة أخرى',
}

const INPUT =
  'w-full rounded-[0.9rem] border border-white/10 bg-white/[0.035] px-3.5 py-3 text-[15px] text-slate-50 outline-none transition placeholder:text-slate-500 focus:border-amber-300/60 focus:bg-white/[0.06] focus:ring-4 focus:ring-amber-300/10'

/** دخول وكلاء ALEGDALY القدامى باسم المستخدم والرمز السري (أو كلمة مرور المالك) */
export default function LuxLogin() {
  const [handle, setHandle] = useState('')
  const [secret, setSecret] = useState('')
  const [show, setShow] = useState(false)
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState(null)
  const { lang } = useLang()
  const dir = lang === 'ar' ? 'rtl' : 'ltr'

  async function submit(e) {
    e.preventDefault()
    if (busy) return
    setErr(null)
    const h = foldTypedDigits(handle).trim().toLowerCase()
    const raw = secret
    const p = /^[\d٠-٩۰-۹\s]+$/.test(raw) ? foldTypedDigits(raw).trim() : raw
    if (!h || !p) return
    setBusy(true)
    try {
      await team.login({ handle: h, password: p })
    } catch (e2) {
      const key = teamFailureKey(e2, 'login', /^\d+$/.test(p))
      setErr(tr(ERR[key] || ERR.genericError))
    } finally {
      setBusy(false)
    }
  }

  return (
    <form dir={dir} onSubmit={submit} className="space-y-3.5">
      <label className="block">
        <span className="mb-1.5 block text-[12.5px] font-bold text-slate-300">{tr('اسم المستخدم')}</span>
        <input
          value={handle}
          onChange={(e) => setHandle(e.target.value)}
          autoCapitalize="none"
          autoCorrect="off"
          autoComplete="username"
          dir={dir}
          placeholder={tr('اسم المستخدم')}
          className={`${INPUT} text-start`}
          required
        />
      </label>

      <label className="block">
        <span className="mb-1.5 block text-[12.5px] font-bold text-slate-300">{tr('الرمز السري أو كلمة المرور')}</span>
        <div className="relative">
          <input
            type={show ? 'text' : 'password'}
            value={secret}
            onChange={(e) => setSecret(e.target.value)}
            autoComplete="current-password"
            dir={dir}
            placeholder={tr('الرمز السري أو كلمة المرور')}
            className={`${INPUT} text-start`}
            style={{ paddingInlineEnd: '3rem' }}
            required
          />
          <button
            type="button"
            onClick={() => setShow((s) => !s)}
            aria-label={show ? tr('إخفاء') : tr('إظهار')}
            className="absolute inset-y-0 flex w-12 items-center justify-center text-slate-400 transition hover:text-amber-200"
            style={dir === 'rtl' ? { left: 0 } : { right: 0 }}
          >
            {show ? <EyeOff size={18} /> : <Eye size={18} />}
          </button>
        </div>
      </label>

      {err && (
        <p role="alert" className="rounded-xl border border-rose-400/30 bg-rose-500/10 px-3.5 py-2.5 text-[13px] font-bold text-rose-200">
          {err}
        </p>
      )}

      <button
        type="submit"
        disabled={busy}
        className="!mt-5 flex w-full touch-manipulation items-center justify-center gap-2 rounded-full bg-gradient-to-br from-[#fbe3a1] via-[#f0b847] to-[#c98a22] py-3.5 text-[15.5px] font-black text-[#1a1206] shadow-[0_14px_32px_-12px_rgba(240,184,71,.6)] transition hover:brightness-105 active:scale-[0.99] disabled:opacity-60"
      >
        {busy ? <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" /> : <LogIn size={18} className={dir === 'rtl' ? '-scale-x-100' : ''} />}
        {busy ? tr('جارٍ الدخول...') : tr('تسجيل الدخول')}
      </button>
    </form>
  )
}
