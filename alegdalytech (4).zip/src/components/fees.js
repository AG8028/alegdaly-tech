// حسابات الرسوم والعمولات — منطق العمل الأساسي للتطبيق
import { tr } from './i18n'

export const COMPANY_FEE_PER_5K = 150

/** عدد الشرائح: من 1 إلى 5000 = 1، من 5001 إلى 10000 = 2 ... */
export const tiers = (amt) => (Number(amt) > 0 ? Math.ceil(Number(amt) / 5000 - 1e-9) : 0)

export const RATES = [
  { value: 250, label: '250 — العادي' },
  { value: 220, label: '220 — تخفيض' },
  { value: 200, label: '200 — حساب لحساب' },
  { value: 180, label: '180 — مساعدة' },
]

export const CUSTOM_RATE = 'custom'

/** خيارات التسعيرة + الخيار المخصص */
export const RATE_OPTIONS = [...RATES, { value: CUSTOM_RATE, label: 'مخصص — أكتب المبلغ بنفسك' }]

export const APPS = [
  { value: 'NITA', label: 'NITA' },
  { value: 'AMANA', label: 'AMANA' },
]

export const appKey = (t) => (t?.app === 'AMANA' ? 'AMANA' : 'NITA')

export const TYPES = [
  { value: 'code', label: 'تحويل عادي' },
  { value: 'acc', label: 'من حساب لحساب' },
]

/** جدول رسوم NITA و AMANA الرسمي (حتى مليون) — قيمة ثابتة لكل نطاق */
export const COMPANY_FEE_TABLE = [
  { min: 1, max: 5000, fee: 150 },
  { min: 5001, max: 10000, fee: 300 },
  { min: 10001, max: 20000, fee: 600 },
  { min: 20001, max: 50000, fee: 1500 },
  { min: 50001, max: 100000, fee: 3000 },
  { min: 100001, max: 200000, fee: 5600 },
  { min: 200001, max: 300000, fee: 8400 },
  { min: 300001, max: 400000, fee: 10400 },
  { min: 400001, max: 500000, fee: 12000 },
  { min: 500001, max: 600000, fee: 13200 },
  { min: 600001, max: 700000, fee: 15400 },
  { min: 700001, max: 800000, fee: 16000 },
  { min: 800001, max: 900000, fee: 18000 },
  { min: 900001, max: 1000000, fee: 10000 },
]

/** رسوم الشركة لكود عادي: بحث في الجدول حتى مليون، وفوق المليون 1% */
export function tableFee(amount) {
  const amt = Number(amount) || 0
  if (amt <= 0) return 0
  if (amt > 1000000) return Math.round(amt * 0.01)
  const row = COMPANY_FEE_TABLE.find((r) => amt <= r.max)
  return row ? row.fee : 0
}

/** رسوم الشركة المحسومة */
export function companyFee(amount, type) {
  const amt = Number(amount) || 0
  if (type === 'code') return tableFee(amt)
  if (amt <= 300000) return 100
  if (amt <= 999999) return 300
  return 1000
}

/**
 * feeOverride: مبلغ عمولة مخصص بالكامل (يُستخدم في الحوالات التي نساعد فيها)
 * إن مُرِّر، يتجاهل تسعيرة الـ 5000 ويأخذ المبلغ كما هو.
 */
export function calcFees({ amount, rate, type, feeOverride }) {
  const amt = Number(amount) || 0
  const compFee = companyFee(amt, type)
  const hasOverride = feeOverride !== undefined && feeOverride !== null && feeOverride !== ''
  const clientFee = hasOverride
    ? Math.max(0, Math.round(Number(feeOverride) || 0))
    : tiers(amt) * (Number(rate) || 0)
  const cashInHand = amt + clientFee
  const myProfit = clientFee - compFee
  return { amount: amt, compFee, clientFee, cashInHand, myProfit, custom: hasOverride }
}

/**
 * المبلغ الشامل: الزبون دفع مبلغاً إجمالياً يشمل العمولة.
 * نبحث عن أكبر مبلغ حوالة يكون مجموعه مع عمولته (كل 5000 بدأت = شريحة) ≤ الكاش.
 * مثال: 35,000 → حوالة 33,250 + عمولة 1,750.
 * مثال: 5,500 → حوالة 5,000 + عمولة 250 = 5,250، والصرف 250 للزبون.
 */
export function calcInclusive({ total, rate, type }) {
  const T = Math.max(0, Math.round(Number(total) || 0))
  const rt = Math.max(0, Number(rate) || 0)
  let best = 0
  const maxK = Math.ceil(T / 5000) + 1
  for (let k = 1; k <= maxK; k++) {
    const a = Math.min(T - k * rt, 5000 * k)
    if (a > 5000 * (k - 1) && a > best) best = a
  }
  const base = calcFees({ amount: best, rate: rt, type })
  return { ...base, total: T, change: Math.max(0, T - base.cashInHand), inclusive: true }
}

/** اتجاه الحركة */
export const DIRECTIONS = [
  { value: 'out', label: '↑ خروج — حوالة صادرة' },
  { value: 'in', label: '↓ دخول — إيداع للحساب' },
]

/**
 * دخول للحساب: القيمة دخلت حساب التطبيق، والوكيل دفع مقابلها كاشاً للزبون.
 * يُخصم المبلغ من الكاش الذي في يد الوكيل، وتبقى العمولة (إن وُجدت) معه.
 */
export function calcDeposit({ amount, fee }) {
  const amt = Number(amount) || 0
  const clientFee = Math.max(0, Math.round(Number(fee) || 0))
  return { amount: amt, compFee: 0, clientFee, cashInHand: clientFee - amt, myProfit: clientFee, custom: true }
}

/** طريقة عرض أي حركة: دخول / خروج / تسليم كاش */
export function moveView(t) {
  if (t.kind === 'cash') {
    return { dir: 'cash', app: null, tag: tr('تسليم كاش'), title: tr(t.ref || 'تسليم نقدي'), value: -(Number(t.amount) || 0) }
  }
  const app = appKey(t)
  if (t.direction === 'in') {
    return { dir: 'in', app, tag: tr('↓ دخول'), title: tr(t.ref || 'إيداع'), value: Number(t.cashInHand) || 0 }
  }
  return { dir: 'out', app, tag: tr('↑ خروج'), title: tr(t.ref || 'حوالة'), value: Number(t.cashInHand) || 0 }
}

export const signed = (v) => `${v < 0 ? '−' : '+'}${fmt(Math.abs(v))}`

export const fmt = (n) => Math.round(Number(n) || 0).toLocaleString('en-US')

export const money = (n) => `${fmt(n)} FCFA`

export const todayKey = () => new Date().toLocaleDateString('en-CA')

export function dateLabel(iso) {
  if (!iso) return ''
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return ''
  const dd = String(d.getDate()).padStart(2, '0')
  const mm = String(d.getMonth() + 1).padStart(2, '0')
  const hh = String(d.getHours()).padStart(2, '0')
  const mi = String(d.getMinutes()).padStart(2, '0')
  return `${dd}/${mm}/${d.getFullYear()} · ${hh}:${mi}`
}

export function dayLabel(key) {
  if (!key) return ''
  const d = new Date(`${key}T12:00:00`)
  if (Number.isNaN(d.getTime())) return key
  const dd = String(d.getDate()).padStart(2, '0')
  const mm = String(d.getMonth() + 1).padStart(2, '0')
  return `${dd}/${mm}/${d.getFullYear()}`
}

export function dayShort(key) {
  if (!key) return ''
  const d = new Date(`${key}T12:00:00`)
  if (Number.isNaN(d.getTime())) return key
  return `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}`
}
