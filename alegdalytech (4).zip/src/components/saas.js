// اشتراكات المكاتب — الثوابت والدوال المشتركة بين صفحة الاشتراك ولوحة المالك

export const CFG_COLL = 'saas_config'
export const CFG_ID = 'main'
export const REQ_COLL = 'office_requests'
export const OFFICE_COLL = 'offices'
export const CODE_COLL = 'payment_codes'

export const OFFICES_LINK = 'https://www.alegdaly.app/#/offices'

// مساحات المكاتب المشتركة — منفصلة تماماً عن بيانات ALEGDALY الأساسية
export const MEMBER_COLL = 'office_members' // طلبات انضمام وكلاء المكاتب + ملفاتهم
export const STATUS_COLL = 'office_status' // حالة الاشتراك العامة (الاسم + الانتهاء) — يكتبها مالك المنصة فقط
export const OFFICE_TX_COLL = 'office_tx' // حوالات وتصفيات المكاتب
export const JOIN_BASE = 'https://www.alegdaly.app/#/join/'
export const joinLink = (officeId) => `${JOIN_BASE}${officeId}`

/** كود انضمام قصير للمكتب (أول 6 خانات من معرّفه) — يكتبه الوكيل بيده بدل الرابط */
export const officeCode = (officeId) => String(officeId || '').replace(/-/g, '').slice(0, 6).toUpperCase()

/**
 * يحوّل ما كتبه الوكيل (كود المكتب أو رابط الانضمام كاملاً) إلى معرّف المكتب.
 * يرجع { id } أو { error: 'notFound' | 'ambiguous' | 'empty' }
 */
export async function resolveOfficeInput(input, db) {
  const raw = String(input || '').trim()
  if (!raw) return { error: 'empty' }
  const m = raw.match(/\/join\/([^/?#\s]+)/)
  if (m) return { id: decodeURIComponent(m[1]) }
  const code = raw.replace(/[\s-]/g, '').toLowerCase()
  if (code.length < 6) return { error: 'notFound' }
  const rows = await db.selectShared(STATUS_COLL, {}, { limit: 1000 }).catch(() => [])
  const hits = (rows || []).filter((r) => String(r.id || '').replace(/-/g, '').toLowerCase().startsWith(code))
  if (hits.length === 1) return { id: hits[0].id }
  if (hits.length > 1) return { error: 'ambiguous' }
  return { error: 'notFound' }
}

/** الباقات: المدة بالأشهر + اسم خانة السعر في الإعدادات */
export const PLANS = [
  { key: 'm1', months: 1, label: 'شهر واحد', priceField: 'price1' },
  { key: 'm3', months: 3, label: '3 أشهر', priceField: 'price3' },
  { key: 'm12', months: 12, label: 'سنة كاملة', priceField: 'price12' },
]

export const planOf = (key) => PLANS.find((p) => p.key === key) || PLANS[0]

export const priceOf = (cfg, key) => Number(cfg?.[planOf(key).priceField]) || 0

/** هل فتح المالك الاشتراكات وحدد سعراً واحداً على الأقل */
export function salesOpen(cfg) {
  return !!cfg?.open && PLANS.some((p) => priceOf(cfg, p.key) > 0)
}

/** رقم واتساب صالح للفتح: رقم محلي من 8 أرقام يأخذ رمز النيجر 227 تلقائياً */
export function waNumber(raw) {
  let d = String(raw || '').replace(/[^\d]/g, '')
  if (d.startsWith('00')) d = d.slice(2)
  if (d.length === 8) d = `227${d}`
  return d
}

export function addMonths(fromIso, months) {
  const d = new Date(fromIso)
  const day = d.getDate()
  d.setMonth(d.getMonth() + months)
  if (d.getDate() < day) d.setDate(0)
  return d.toISOString()
}

/** تاريخ اليوم فقط (YYYY-MM-DD) — تقرؤه تذكيرات الانتهاء على السيرفر */
export function dayOf(iso) {
  if (!iso) return ''
  const d = new Date(iso)
  const p = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`
}

export function daysLeft(expiresAt) {
  if (!expiresAt) return 0
  return Math.ceil((new Date(expiresAt).getTime() - Date.now()) / 86400000)
}

/** حالة المكتب للعرض: active · ending (7 أيام أو أقل) · expired · suspended */
export function officeState(office) {
  if (!office) return 'none'
  if (office.status === 'suspended') return 'suspended'
  const d = daysLeft(office.expiresAt)
  if (d <= 0) return 'expired'
  if (d <= 7) return 'ending'
  return 'active'
}

/**
 * الترخيص الرسمي للمكتب — يُحفظ داخل إعدادات المالك (لا يكتبها إلا أنت).
 * أي سجل اشتراك لا يقابله ترخيص هنا يُعامل كمكتب غير مشترك، حتى لو صنعه أحد بنفسه.
 */
export function licenseOf(cfg, officeId) {
  const lic = officeId ? cfg?.licenses?.[officeId] : null
  return lic && lic.expiresAt ? lic : null
}

/** حالة الاشتراك المعتمدة: من الترخيص الرسمي فقط */
export function verifiedStatus(row, cfg, officeId) {
  const lic = licenseOf(cfg, officeId)
  if (!lic) return null
  return { ...(row || {}), expiresAt: lic.expiresAt, status: lic.status || 'active' }
}

export const fmtNum = (n) => (Number(n) || 0).toLocaleString('en-US')

export function fmtDate(iso, lang) {
  if (!iso) return '—'
  try {
    return new Date(iso).toLocaleDateString(lang === 'ar' ? 'ar-u-nu-latn' : lang === 'fr' ? 'fr-FR' : 'en-GB', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    })
  } catch {
    return iso.slice(0, 10)
  }
}
