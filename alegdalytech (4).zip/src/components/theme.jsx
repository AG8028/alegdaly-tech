import { createContext, useCallback, useContext, useEffect, useState } from 'react'
import { Sun, Moon } from 'lucide-react'
import { tr } from './i18n'

/**
 * الوضع الليلي / النهاري — اختيار المستخدم يُحفظ على جهازه.
 * null = الافتراضي لكل واجهة (المالك وشاشة الدخول: ليلي · الوكيل: نهاري)
 */
const KEY = 'alegdaly-theme'

function readPref() {
  try {
    const v = localStorage.getItem(KEY)
    if (v === 'dark' || v === 'light') return v
  } catch { /* ignore */ }
  return null
}

const ThemeCtx = createContext({ pref: null, setPref: () => {}, mode: null })

export function ThemeProvider({ children }) {
  const [pref, setPrefState] = useState(readPref)
  const setPref = useCallback((v) => {
    try { localStorage.setItem(KEY, v) } catch { /* ignore */ }
    setPrefState(v)
  }, [])
  return <ThemeCtx.Provider value={{ pref, setPref, mode: null }}>{children}</ThemeCtx.Provider>
}

/** اختيار المستخدم المحفوظ فقط (بدون تطبيقه على الصفحة) */
export const usePref = () => useContext(ThemeCtx).pref

/** الوضع الفعلي لواجهة معيّنة حسب افتراضيّها */
export function useMode(defaultMode = 'dark') {
  const { pref, setPref } = useContext(ThemeCtx)
  const mode = pref || defaultMode
  // لون خلفية الصفحة وشريط الحالة يتبعان الوضع
  useEffect(() => {
    try {
      document.documentElement.dataset.mode = mode
      document.documentElement.style.setProperty('--color-bg', mode === 'light' ? '246 244 238' : '6 11 24')
    } catch { /* ignore */ }
  }, [mode])
  const toggle = useCallback(() => setPref(mode === 'light' ? 'dark' : 'light'), [mode, setPref])
  return { mode, toggle }
}

export { ModeScope, useScopeMode } from './modeScope'

/** زر تبديل الوضع ☾ / ☀ */
export function ThemeToggle({ mode, onToggle, withLabel = false, className = '' }) {
  const light = mode === 'light'
  const label = light ? tr('الوضع الليلي') : tr('الوضع النهاري')
  return (
    <button
      type="button"
      onClick={onToggle}
      aria-label={label}
      title={label}
      className={`theme-toggle inline-flex items-center justify-center gap-2 rounded-xl border transition active:scale-95 ${
        light
          ? 'border-slate-300/70 bg-white text-slate-700 hover:bg-slate-50'
          : 'border-white/10 bg-white/[0.04] text-amber-200 hover:bg-white/[0.08]'
      } ${withLabel ? 'w-full px-3 py-2.5 text-[13px] font-bold' : 'h-9 w-9'} ${className}`}
    >
      {light ? <Moon size={16} /> : <Sun size={16} />}
      {withLabel ? <span>{label}</span> : null}
    </button>
  )
}
