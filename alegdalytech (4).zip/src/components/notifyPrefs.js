import { useEffect, useState } from 'react'
import { db } from '../lib/db'

// تفضيلات إشعارات كل مستخدم: سجل واحد باسمه، فيه فقط «مشغّل/موقوف» (لا بيانات شخصية).
// يقرأه المكتب المرسل قبل أن يرسل الإشعار، ولا يعدّله إلا صاحبه.
const COLL = 'notify_prefs'
const DEFAULTS = { ops: true, sec: true }
const cache = new Map() // userId → { at, prefs }
const TTL = 60_000

export async function getNotifyPrefs(userId) {
  if (!userId) return DEFAULTS
  const hit = cache.get(userId)
  if (hit && Date.now() - hit.at < TTL) return hit.prefs
  let prefs = DEFAULTS
  try {
    const row = await db.getShared(COLL, userId)
    if (row) prefs = { ops: row.ops !== false, sec: row.sec !== false }
  } catch { /* لا يمنع الإشعار إذا تعذّرت القراءة */ }
  cache.set(userId, { at: Date.now(), prefs })
  return prefs
}

export async function setNotifyPrefs(userId, prefs) {
  if (!userId) return
  const next = { ops: prefs.ops !== false, sec: prefs.sec !== false }
  await db.upsertShared(COLL, next, userId)
  cache.set(userId, { at: Date.now(), prefs: next })
}

export function useNotifyPrefs(userId) {
  const [prefs, setPrefs] = useState(() => cache.get(userId)?.prefs || null)
  useEffect(() => {
    let alive = true
    getNotifyPrefs(userId).then((p) => { if (alive) setPrefs(p) })
    return () => { alive = false }
  }, [userId])
  async function update(patch) {
    const next = { ...(prefs || DEFAULTS), ...patch }
    const prev = prefs
    setPrefs(next)
    try {
      await setNotifyPrefs(userId, next)
    } catch (e) {
      setPrefs(prev)
      throw e
    }
  }
  return { prefs, update }
}
