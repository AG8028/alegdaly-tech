import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import { auth } from '../lib/auth'
import { team } from '../lib/team'
import { db } from '../lib/db'
import { social } from '../lib/social'
import { useLiveShared } from '../lib/useLive'
import { OFFICE_COLL, MEMBER_COLL, STATUS_COLL, OFFICE_TX_COLL, CFG_COLL, CFG_ID, officeState, verifiedStatus } from './saas'

const SessionCtx = createContext(null)

/**
 * المساحات:
 *  main         — ALEGDALY نفسها (المالك + وكلاء الفريق)
 *  office       — صاحب مكتب مشترك (يدير وكلاءه وحوالاته فقط)
 *  officeAgent  — وكيل تابع لمكتب مشترك
 *  none         — حساب مسجّل لا ينتمي لأي مساحة بعد
 */
const EMPTY = { mode: 'main', gid: null, canManage: false, member: null, members: [], office: null, membership: null, officeStatus: null, verified: null, error: null }

// نسخة مؤقتة من آخر جلسة على هذا الجهاز — يفتح التطبيق فوراً ثم يتحقق من الخادم في الخلفية.
// (الصلاحيات الفعلية يفرضها الخادم دائماً، هذه النسخة للعرض فقط)
const CACHE = (uid) => `alg_session_v1_${uid}`
function readCache(uid) {
  if (!uid) return null
  try {
    const v = JSON.parse(localStorage.getItem(CACHE(uid)) || 'null')
    return v && v.mode && v.mode !== 'none' ? { ...EMPTY, ...v, error: null } : null
  } catch { return null }
}
function writeCache(uid, v) {
  if (!uid) return
  try { localStorage.setItem(CACHE(uid), JSON.stringify({ ...v, error: null })) } catch { /* ignore */ }
}

export function SessionProvider({ children }) {
  const [user, setUser] = useState(() => auth.getCurrentUser())
  const [info, setInfoRaw] = useState(() => readCache(auth.getCurrentUser()?.id) || EMPTY)
  const [ready, setReady] = useState(() => !!readCache(auth.getCurrentUser()?.id))
  const [selectedAgentId, setSelectedAgentId] = useState(null)

  useEffect(() => auth.onAuthChange((u) => setUser(u)), [])

  const userId = user?.id || null

  const setInfo = useCallback(
    (next) => {
      setInfoRaw((prev) => {
        const v = typeof next === 'function' ? next(prev) : next
        if (!v.error) writeCache(userId, v)
        return v
      })
    },
    [userId],
  )

  // إخفاء وكيل محذوف فوراً من القائمة دون انتظار إعادة التحميل
  const dropMember = useCallback(
    (uid) => setInfo((p) => ({ ...p, members: (p.members || []).filter((m) => m.userId !== uid) })),
    [setInfo],
  )

  const refresh = useCallback(async () => {
    if (!userId) {
      setReady(true)
      return
    }
    try {
      // كل الفحوصات معاً في دفعة واحدة بدل الانتظار خطوة بخطوة (أسرع بكثير على الشبكات الضعيفة)
      const [canManage, member, office, cfg, memberRows] = await Promise.all([
        team.canManage().catch(() => false),
        team.currentMember().catch(() => null),
        db.getShared(OFFICE_COLL, userId).catch(() => null),
        db.getShared(CFG_COLL, CFG_ID).catch(() => null),
        db.selectShared(MEMBER_COLL, { userId }).catch(() => []),
      ])

      // ① المساحة الأساسية: المالك أو حساب من فريق ALEGDALY
      if (canManage || member) {
        const [gid, members] = await Promise.all([
          team.groupId(),
          canManage ? team.listMembers().catch(() => []) : Promise.resolve([]),
        ])
        setInfo({ ...EMPTY, mode: 'main', gid, canManage, member, members })
        return
      }

      // ② صاحب مكتب مشترك
      if (office && office.status !== 'deleted') {
        const canAdmin = office.groupId ? await social.canAdmin(office.groupId).catch(() => false) : false
        setInfo({ ...EMPTY, mode: 'office', gid: office.groupId || null, canManage: canAdmin, office, verified: verifiedStatus(office, cfg, userId) })
        return
      }

      // ③ وكيل تابع لمكتب مشترك
      const rows = memberRows
      // وكيل حذفه صاحب المكتب = حساب بلا مساحة (يستطيع الانضمام لمكتب آخر أو العودة بطلب جديد)
      const alive = (rows || []).filter((r) => r.status !== 'deleted')
      const pick =
        alive.find((r) => r.status === 'approved') || alive.find((r) => r.status === 'pending') || alive[0] || null
      if (pick) {
        const st = await db.getShared(STATUS_COLL, pick.ws).catch(() => null)
        setInfo({ ...EMPTY, mode: 'officeAgent', gid: pick.groupId || null, membership: pick, officeStatus: st, verified: verifiedStatus(st, cfg, pick.ws) })
        return
      }

      setInfo({ ...EMPTY, mode: 'none' })
    } catch (e) {
      setInfo((p) => ({ ...p, error: e?.message || 'تعذّر تحميل الجلسة' }))
    } finally {
      setReady(true)
    }
  }, [userId, setInfo])

  useEffect(() => {
    const cached = readCache(userId)
    if (cached) {
      setInfoRaw(cached)
      setReady(true)
    } else {
      setInfoRaw(EMPTY)
      setReady(false)
    }
    refresh()
  }, [refresh, userId])

  const mode = info.mode
  const officeId = mode === 'office' ? info.office?.id || userId : mode === 'officeAgent' ? info.membership?.ws || null : null

  // ملفات الوكلاء — كل مساحة تقرأ ملفاتها فقط
  const profColl = mode === 'main' ? 'agents' : MEMBER_COLL
  const profOpts =
    mode === 'office' ? { filters: { ws: officeId || '__none__' } }
      : mode === 'officeAgent' ? { filters: { userId: userId || '__none__' } }
        : mode === 'none' ? { filters: { userId: '__none__' } }
          : {}
  const { data: profiles } = useLiveShared(profColl, profOpts)

  const profileMap = useMemo(() => {
    const map = {}
    if (mode !== 'main') return map
    for (const p of profiles || []) map[p.id] = p
    return map
  }, [profiles, mode])

  const build = useCallback(
    (m) => {
      const p = profileMap[m.userId] || {}
      return {
        userId: m.userId,
        name: p.name || m.displayName || m.handle || 'وكيل',
        phone: p.phone || '',
        salary: Number(p.salary) || 0,
        pin: p.pin || '',
        note: p.note || '',
        handle: m.handle || '',
        role: m.role,
        active: m.status !== 'disabled',
        lastLoginAt: m.lastLoginAt || null,
      }
    },
    [profileMap],
  )

  const fromMember = (p) => ({
    userId: p.userId,
    memberId: p.id,
    name: p.name || 'وكيل',
    phone: p.phone || '',
    salary: Number(p.salary) || 0,
    pin: '',
    note: p.note || '',
    handle: p.email || '',
    email: p.email || '',
    role: 'agent',
    status: p.status,
    active: p.status === 'approved',
    lastLoginAt: null,
  })

  // حسابات الإدارة (دخول المالك باسم مستخدم وكلمة مرور) — لا تظهر ضمن الوكلاء
  const isManagerSeat = (m) => m.role === 'manager' || m.role === 'admin' || m.disabledRole === 'manager'
  const managers = useMemo(() => (mode === 'main' ? (info.members || []).filter(isManagerSeat) : []), [info.members, mode])

  // عضوية الوكيل الحالية (تتحدّث لحظياً عند الموافقة أو الإيقاف)
  const membership = useMemo(() => {
    if (mode !== 'officeAgent') return null
    const live = (profiles || []).find((p) => p.id === info.membership?.id)
    return live || info.membership
  }, [mode, profiles, info.membership])

  const allAgents = useMemo(() => {
    if (!userId) return []
    if (mode === 'office') {
      return (profiles || []).filter((p) => p.status === 'approved' || p.status === 'removed').map(fromMember)
    }
    if (mode === 'officeAgent') return membership ? [fromMember(membership)] : []
    if (mode === 'none') return []
    if (info.canManage) return (info.members || []).filter((m) => !isManagerSeat(m)).map(build)
    const p = profileMap[userId] || {}
    return [
      {
        userId,
        name: p.name || info.member?.displayName || user?.displayName || 'وكيل',
        phone: p.phone || '',
        salary: Number(p.salary) || 0,
        pin: p.pin || '',
        note: p.note || '',
        handle: info.member?.handle || '',
        role: info.member?.role || null,
        active: true,
        lastLoginAt: null,
      },
    ]
  }, [info, profileMap, profiles, membership, mode, userId, user, build])

  const roster = useMemo(() => allAgents.filter((a) => a.active), [allAgents])
  const inactive = useMemo(() => allAgents.filter((a) => !a.active), [allAgents])
  const pendingMembers = useMemo(
    () => (mode === 'office' ? (profiles || []).filter((p) => p.status === 'pending') : []),
    [profiles, mode],
  )

  // حالة المساحة: ok · locked (اشتراك منتهي/موقوف) · pending · removed · broken · none
  // الحالة المعتمدة تأتي من ترخيص المالك فقط — لا من سجل يمكن أن يصنعه المكتب بنفسه
  const officeStatusRow = mode === 'office' || mode === 'officeAgent' ? info.verified : null
  const subState = mode === 'office' || mode === 'officeAgent' ? officeState(officeStatusRow) : 'active'
  let workspace = 'ok'
  if (mode === 'none') workspace = 'none'
  else if (mode === 'office') {
    if (!info.gid || !info.canManage) workspace = 'broken'
    else if (subState === 'expired' || subState === 'suspended' || subState === 'none') workspace = 'locked'
  } else if (mode === 'officeAgent') {
    if (membership?.status === 'pending') workspace = 'pending'
    else if (membership?.status !== 'approved') workspace = 'removed'
    else if (!info.gid) workspace = 'broken'
    else if (subState === 'expired' || subState === 'suspended' || subState === 'none') workspace = 'locked'
  }

  const isOffice = mode === 'office' || mode === 'officeAgent'
  const officeName =
    mode === 'office' ? info.office?.officeName || '' : mode === 'officeAgent' ? info.officeStatus?.officeName || membership?.officeName || '' : ''

  const openTeamAdmin = useCallback(
    async (opts) => {
      await team.openAdmin(opts)
      await refresh()
    },
    [refresh],
  )

  const value = {
    user,
    ready,
    mode,
    isOffice,
    workspace,
    officeId,
    officeName,
    office: info.office,
    officeStatus: officeStatusRow,
    subState,
    membership,
    gid: info.gid,
    canManage: info.canManage,
    member: info.member,
    error: info.error,
    roster,
    inactive,
    managers,
    allAgents,
    pendingMembers,
    profileMap,
    selectedAgentId,
    setSelectedAgentId,
    refresh,
    dropMember,
    openTeamAdmin,
    // نطاق الحوالات
    txColl: isOffice ? OFFICE_TX_COLL : 'transactions',
    base: isOffice ? { ws: officeId || '__none__' } : {},
    stamp: isOffice ? { ws: officeId } : {},
    guardIds: mode === 'office' ? allAgents.map((a) => a.userId) : null,
  }

  return <SessionCtx.Provider value={value}>{children}</SessionCtx.Provider>
}

export function useSession() {
  const ctx = useContext(SessionCtx)
  if (!ctx) throw new Error('useSession outside provider')
  return ctx
}

/** معرّف الوكيل الحالي (الثابت للوكيل، والقابل للتبديل للمدير) */
export function useActiveAgent() {
  const session = useSession()
  const agentId = session.canManage ? session.selectedAgentId : session.user?.id || null
  const agent = session.roster.find((r) => r.userId === agentId) || null
  return { agentId, agent, roster: session.roster, canManage: session.canManage }
}
