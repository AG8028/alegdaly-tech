import { useEffect, useState } from 'react'
import { db } from '../lib/db'
import { fmt } from './fees'
import { tr } from './i18n'
import { useScopeMode } from './modeScope'
import { useSession } from './Session'
import { scopeFilter } from './scope'

/**
 * هوية كل تطبيق تحويل بلونه الأصلي:
 * NITA — برتقالي ، AMANA — أخضر
 */
export const BRANDS = {
  NITA: {
    name: 'NITA',
    dark: { text: 'text-[#ff9a2e]', chip: 'bg-[#ff9a2e]/15 text-[#ffb25c] ring-1 ring-[#ff9a2e]/35', dot: 'bg-[#ff9a2e]', card: 'border-[#ff9a2e]/30 bg-gradient-to-bl from-[#ff9a2e]/[0.16] to-transparent', active: 'border-[#ff9a2e]/70 bg-[#ff9a2e]/20 text-[#ffc07a]' },
    light: { text: 'text-[#e06d00]', chip: 'bg-[#ff8a00]/12 text-[#d06200] ring-1 ring-[#ff8a00]/30', dot: 'bg-[#ff8a00]', card: 'border-[#ffd2a3] bg-gradient-to-bl from-[#fff1e0] to-white', active: 'border-[#ff8a00] bg-[#ff8a00]/10 text-[#d06200]' },
  },
  AMANA: {
    name: 'AMANA',
    dark: { text: 'text-[#2fd27a]', chip: 'bg-[#16b364]/15 text-[#4ade90] ring-1 ring-[#16b364]/35', dot: 'bg-[#16b364]', card: 'border-[#16b364]/30 bg-gradient-to-bl from-[#16b364]/[0.16] to-transparent', active: 'border-[#16b364]/70 bg-[#16b364]/20 text-[#6ee7a6]' },
    light: { text: 'text-[#0a8f4a]', chip: 'bg-[#16a34a]/12 text-[#0a8f4a] ring-1 ring-[#16a34a]/30', dot: 'bg-[#16a34a]', card: 'border-[#bfe8cf] bg-gradient-to-bl from-[#e7f8ee] to-white', active: 'border-[#16a34a] bg-[#16a34a]/10 text-[#0a8f4a]' },
  },
}

const skin = (app, theme) => (BRANDS[app] || BRANDS.NITA)[theme === 'light' ? 'light' : 'dark']

/** شارة صغيرة باسم التطبيق بلونه */
export function AppTag({ app, theme: themeProp = 'dark', className = '' }) {
  const theme = useScopeMode(themeProp)
  if (!app) return null
  const s = skin(app, theme)
  return (
    <span dir="ltr" className={`inline-flex shrink-0 items-center gap-1 rounded-md px-1.5 py-0.5 font-display text-[10px] font-black tracking-[0.08em] ${s.chip} ${className}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${s.dot}`} />
      {BRANDS[app]?.name || app}
    </span>
  )
}

/** اسم التطبيق كشعار نصي بلونه */
export function AppWord({ app, theme: themeProp = 'dark', className = '' }) {
  const theme = useScopeMode(themeProp)
  const s = skin(app, theme)
  return (
    <span dir="ltr" className={`font-display font-black tracking-[0.06em] ${s.text} ${className}`}>
      {BRANDS[app]?.name || app}
    </span>
  )
}

/** اختيار التطبيق (الكل / NITA / AMANA) */
export function AppFilter({ value, onChange, theme: themeProp = 'dark', withAll = true }) {
  const theme = useScopeMode(themeProp)
  const opts = withAll ? ['all', 'NITA', 'AMANA'] : ['NITA', 'AMANA']
  const light = theme === 'light'
  return (
    <div className={`grid gap-2 ${opts.length === 3 ? 'grid-cols-3' : 'grid-cols-2'}`}>
      {opts.map((o) => {
        const active = value === o
        let cls
        if (o === 'all') {
          cls = active
            ? light ? 'border-[#0f766e] bg-[#0f766e]/10 text-[#0f766e]' : 'border-white/40 bg-white/10 text-white'
            : light ? 'border-[#e6ece7] bg-white text-[#64756d]' : 'border-white/10 bg-black/25 text-slate-400'
        } else {
          const s = skin(o, theme)
          cls = active ? s.active : light ? `border-[#e6ece7] bg-white ${s.text}` : `border-white/10 bg-black/25 ${s.text}`
        }
        return (
          <button
            key={o}
            type="button"
            onClick={() => onChange(o)}
            className={`flex items-center justify-center gap-1.5 rounded-2xl border-2 px-2 py-2.5 text-[13px] font-extrabold transition active:scale-[0.98] ${cls}`}
          >
            {o === 'all' ? tr('الكل') : (
              <>
                <span className={`h-2 w-2 rounded-full ${skin(o, theme).dot}`} />
                <span dir="ltr" className="font-display font-black tracking-[0.08em]">{BRANDS[o].name}</span>
              </>
            )}
          </button>
        )
      })}
    </div>
  )
}

const EMPTY = { count: 0, amount: 0, inAmount: 0, outAmount: 0, cash: 0, profit: 0 }

/** إجماليات كل تطبيق على حدة — محسوبة على الخادم */
export function useAppTotals(agentId, version) {
  const session = useSession()
  const coll = session.txColl
  const scoped = scopeFilter(session, agentId)
  const fKey = JSON.stringify(scoped)
  const [totals, setTotals] = useState({ NITA: { ...EMPTY }, AMANA: { ...EMPTY } })

  useEffect(() => {
    let alive = true
    const f = { ...scoped, kind: 'tx' }
    Promise.all([
      db.groupByShared(coll, 'app', { agg: 'sum', field: 'amount', filters: f }),
      db.groupByShared(coll, 'app', { agg: 'sum', field: 'amount', filters: { ...f, direction: 'in' } }),
      db.groupByShared(coll, 'app', { agg: 'sum', field: 'cashInHand', filters: f }),
      db.groupByShared(coll, 'app', { agg: 'sum', field: 'myProfit', filters: f }),
    ])
      .then(([amt, inAmt, cash, profit]) => {
        if (!alive) return
        const out = { NITA: { ...EMPTY }, AMANA: { ...EMPTY } }
        const k = (key) => (key === 'AMANA' ? 'AMANA' : 'NITA')
        for (const r of amt || []) {
          out[k(r.key)].count += Number(r.count) || 0
          out[k(r.key)].amount += Number(r.value) || 0
        }
        for (const r of inAmt || []) out[k(r.key)].inAmount += Number(r.value) || 0
        for (const r of cash || []) out[k(r.key)].cash += Number(r.value) || 0
        for (const r of profit || []) out[k(r.key)].profit += Number(r.value) || 0
        for (const a of ['NITA', 'AMANA']) out[a].outAmount = out[a].amount - out[a].inAmount
        setTotals(out)
      })
      .catch(() => {})
    return () => {
      alive = false
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [coll, fKey, version])

  return totals
}

/** بطاقة ملخّص تطبيق واحد */
export function AppSummaryCard({ app, t, theme: themeProp = 'dark', showProfit = false, onClick }) {
  const theme = useScopeMode(themeProp)
  const s = skin(app, theme)
  const light = theme === 'light'
  const muted = light ? 'text-[#8b9a93]' : 'text-slate-500'
  const strong = light ? 'text-[#0b1a17]' : 'text-white'
  const Tag = onClick ? 'button' : 'div'
  return (
    <Tag
      type={onClick ? 'button' : undefined}
      onClick={onClick}
      className={`w-full rounded-[22px] border p-4 text-start transition ${s.card} ${onClick ? 'hover:brightness-110 active:scale-[0.99]' : ''}`}
    >
      <div className="flex items-center justify-between">
        <AppWord app={app} theme={theme} className="text-[18px]" />
        <span className={`text-[10.5px] font-extrabold ${muted}`}>
          {fmt(t.count)} {tr('حركة')}
        </span>
      </div>
      <div className="mt-3 grid grid-cols-2 gap-2">
        <div>
          <p className={`text-[10px] font-extrabold ${muted}`}>{tr('↑ خروج')}</p>
          <p className={`font-display text-[15px] font-black ${strong}`}>{fmt(t.outAmount)}</p>
        </div>
        <div>
          <p className={`text-[10px] font-extrabold ${muted}`}>{tr('↓ دخول')}</p>
          <p className={`font-display text-[15px] font-black ${strong}`}>{fmt(t.inAmount)}</p>
        </div>
      </div>
      {showProfit ? (
        <p className={`mt-2 text-[10.5px] font-extrabold ${muted}`}>
          {tr('مكسب المكتب')}: <span className={s.text}>{fmt(t.profit)}</span>
        </p>
      ) : null}
    </Tag>
  )
}
