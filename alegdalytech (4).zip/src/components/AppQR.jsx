import { useState } from 'react'
import { QRCodeSVG } from 'qrcode.react'
import { QrCode, Copy, Check, MessageCircle, X, ChevronDown } from 'lucide-react'
import { share } from '../lib/share'
import { copyText } from './credentials'
import { tr } from './i18n'

export const APP_LINK = 'https://www.alegdaly.app'

/** بطاقة QR تفتح موقع التطبيق على النطاق الخاص — للطباعة أو الإرسال للوكلاء */
export default function AppQR() {
  const [copied, setCopied] = useState(false)
  const [open, setOpen] = useState(() => {
    try { return localStorage.getItem('appqr-open') !== '0' } catch { return true }
  })
  function toggle(v) {
    setOpen(v)
    try { localStorage.setItem('appqr-open', v ? '1' : '0') } catch { /* ignore */ }
  }

  async function copy() {
    const ok = await copyText(APP_LINK)
    if (ok !== false) {
      setCopied(true)
      setTimeout(() => setCopied(false), 1800)
    }
  }

  function sendWhatsApp() {
    share.whatsapp('', `${tr('حمّل تطبيق الأقدالي للتقنية من هنا:')} ${APP_LINK}`)
  }

  if (!open) {
    return (
      <button
        type="button"
        onClick={() => toggle(true)}
        className="skin-gold flex w-full items-center justify-between gap-2 rounded-2xl border border-amber-300/20 bg-gradient-to-br from-[#14203a] to-[#0a1222] px-4 py-3 text-amber-200 transition hover:border-amber-300/40"
      >
        <span className="flex items-center gap-2 text-[13px] font-extrabold">
          <QrCode size={15} />
          {tr('رمز QR للتطبيق')}
        </span>
        <ChevronDown size={16} className="text-amber-300/80" />
      </button>
    )
  }

  return (
    <div className="skin-gold relative overflow-hidden rounded-2xl border border-amber-300/20 bg-gradient-to-br from-[#14203a] to-[#0a1222] p-4 md:p-5">
      <div className="pointer-events-none absolute -top-16 end-0 h-40 w-40 rounded-full bg-amber-400/10 blur-3xl" />
      <button
        type="button"
        onClick={() => toggle(false)}
        aria-label="close"
        className="absolute top-3 end-3 z-10 flex h-8 w-8 items-center justify-center rounded-full border border-white/10 bg-white/[0.05] text-slate-300 transition hover:bg-white/[0.12] hover:text-white"
      >
        <X size={16} />
      </button>
      <div className="relative flex flex-col items-center gap-4 sm:flex-row sm:items-center">
        <div className="shrink-0 rounded-2xl bg-white p-3 shadow-[0_18px_40px_-18px_rgba(240,184,71,.55)] ring-2 ring-amber-300/40">
          <QRCodeSVG value={APP_LINK} size={148} level="M" fgColor="#0a1222" bgColor="#ffffff" />
        </div>
        <div className="min-w-0 flex-1 text-center sm:text-start">
          <p className="flex items-center justify-center gap-1.5 text-[11px] font-extrabold tracking-wider text-amber-300/90 sm:justify-start">
            <QrCode size={13} />
            {tr('رمز QR للتطبيق')}
          </p>
          <h3 className="font-display mt-1 text-[17px] font-extrabold text-white">{tr('شارك تطبيقك برابطك الخاص')}</h3>
          <p className="mt-1 text-[12px] leading-relaxed text-slate-400">
            {tr('يفتح موقعك مباشرة، ومنه يحمّل الوكيل تطبيق أندرويد بضغطة.')}
          </p>
          <p dir="ltr" className="lux-latin mt-2 text-[13px] font-bold tracking-wide text-amber-200">www.alegdaly.app</p>
          <div className="mt-3 flex flex-wrap justify-center gap-2 sm:justify-start">
            <button
              type="button"
              onClick={copy}
              className="inline-flex items-center gap-1.5 rounded-full border border-white/12 bg-white/[0.04] px-3.5 py-2 text-[12px] font-bold text-slate-200 transition hover:border-amber-300/45 hover:text-amber-100"
            >
              {copied ? <Check size={14} /> : <Copy size={14} />}
              {copied ? tr('تم النسخ') : tr('نسخ الرابط')}
            </button>
            <button
              type="button"
              onClick={sendWhatsApp}
              className="inline-flex items-center gap-1.5 rounded-full border border-emerald-400/30 bg-emerald-500/10 px-3.5 py-2 text-[12px] font-bold text-emerald-200 transition hover:bg-emerald-500/20"
            >
              <MessageCircle size={14} />
              {tr('إرسال عبر واتساب')}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
