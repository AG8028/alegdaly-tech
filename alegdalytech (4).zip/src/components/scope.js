/**
 * نطاق البيانات حسب المساحة الحالية:
 * - المساحة الأساسية (ALEGDALY): مجموعة 'transactions' بدون فلتر إضافي
 * - مساحة مكتب مشترك: مجموعة 'office_tx' مع فلتر ws = معرّف المكتب،
 *   وفي عرض «الجميع» تُقصر النتائج على وكلاء المكتب المعتمدين فقط.
 */
export function scopeFilter(session, agentId) {
  const f = { ...(session?.base || {}) }
  if (agentId) f.agentUserId = agentId
  else if (session?.guardIds) f.agentUserId = { in: session.guardIds.length ? session.guardIds : ['__none__'] }
  return f
}
