import { TrendingUp, CalendarDays, Trophy, Gauge, Sparkles } from 'lucide-react'
import Chart from './Chart'
import { fmt, dayShort, todayKey } from './fees'
import { tr } from './i18n'

function Metric({ icon: Icon, label, value, sub, tone = 'text-slate-100', ring = 'from-white/10 to-white/0' }) {
  return (
    <div className="skin-metric relative overflow-hidden rounded-2xl border border-white/[0.07] bg-[#0a1322]/70 p-3.5">
      <div className={`pointer-events-none absolute -end-6 -top-6 h-20 w-20 rounded-full bg-gradient-to-br ${ring} blur-2xl`} />
      <div className="relative">
        <div className="mb-2 flex items-center gap-1.5">
          <span className="flex h-6 w-6 items-center justify-center rounded-lg bg-white/[0.06]">
            <Icon size={13} className={tone} />
          </span>
          <span className="text-[10.5px] font-bold text-slate-400">{label}</span>
        </div>
        <p className={`font-display text-[18px] font-black leading-none tabular-nums ${tone}`}>{value}</p>
        {sub ? <p className="mt-1.5 text-[10px] font-bold text-slate-500">{sub}</p> : null}
      </div>
    </div>
  )
}

/** مركز الأرباح: إجمالي المكسب، اليوم، الأسبوع، أفضل يوم، توزيع NITA/AMANA، ورسم الأيام */
export default function ProfitPanel({ total, daily = [], nita = 0, amana = 0 }) {
  const values = daily.map((d) => Math.max(0, Math.round(Number(d.value) || 0)))
  const today = Math.round(Number(daily.find((d) => d.key === todayKey())?.value) || 0)
  const week = values.reduce((a, b) => a + b, 0) // max 7 server-aggregated buckets
  const avg = values.length ? Math.round(week / values.length) : 0
  let bestIdx = -1
  values.forEach((v, i) => { if (bestIdx < 0 || v > values[bestIdx]) bestIdx = i })
  const best = bestIdx >= 0 ? { key: daily[bestIdx].key, value: values[bestIdx] } : null

  const n = Math.max(0, Number(nita) || 0)
  const a = Math.max(0, Number(amana) || 0)
  const split = n + a
  const nPct = split ? Math.round((n / split) * 100) : 0
  const aPct = split ? 100 - nPct : 0

  const chartSpec = values.length
    ? {
        kind: 'bar',
        labels: daily.map((d) => dayShort(d.key)),
        series: [{ name: tr('الربح'), data: values, color: '#f5c45e' }],
      }
    : null

  return (
    <section className="skin-gold rise relative overflow-hidden rounded-3xl border border-amber-300/20 bg-gradient-to-br from-[#1a1508] via-[#0b1220] to-[#06101c] p-4 md:p-6">
      <div className="glow-pulse pointer-events-none absolute -top-24 start-1/3 h-60 w-60 rounded-full bg-amber-400/15 blur-3xl" />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-amber-300/50 to-transparent" />

      <div className="relative">
        {/* العنوان + الإجمالي */}
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="flex items-center gap-1.5 text-[11px] font-extrabold tracking-[0.18em] text-amber-300/80">
              <Sparkles size={12} />
              {tr('مركز الأرباح')}
            </p>
            <p className="mt-2 text-[11.5px] font-bold text-slate-400">{tr('صافي مكسب المكتب')}</p>
            <p className="font-display mt-1 text-[34px] font-black leading-none tracking-tight tabular-nums md:text-[42px]">
              <span className="lux-gold-text">{total == null ? '—' : fmt(total)}</span>
              <span className="ms-2 align-middle text-[12px] font-bold text-amber-200/60">FCFA</span>
            </p>
          </div>
          <span className="rounded-full border border-amber-300/25 bg-amber-400/10 px-3 py-1.5 text-[11px] font-extrabold text-amber-200">
            {tr('آخر 7 أيام')}: {fmt(week)}
          </span>
        </div>

        {/* المؤشرات */}
        <div className="mt-5 grid grid-cols-2 gap-2.5 md:grid-cols-4">
          <Metric icon={TrendingUp} label={tr('ربح اليوم')} value={fmt(today)} tone="text-emerald-300" ring="from-emerald-400/30 to-transparent" />
          <Metric icon={CalendarDays} label={tr('ربح الأسبوع')} value={fmt(week)} tone="text-amber-200" ring="from-amber-400/30 to-transparent" />
          <Metric icon={Gauge} label={tr('متوسط اليوم')} value={fmt(avg)} tone="text-sky-300" ring="from-sky-400/30 to-transparent" />
          <Metric
            icon={Trophy}
            label={tr('أفضل يوم')}
            value={best ? fmt(best.value) : '—'}
            sub={best ? dayShort(best.key) : null}
            tone="text-amber-300"
            ring="from-amber-300/30 to-transparent"
          />
        </div>

        {/* توزيع الأرباح حسب التطبيق */}
        <div className="mt-5 rounded-2xl border border-white/[0.07] bg-black/20 p-3.5">
          <div className="mb-2.5 flex items-center justify-between text-[11.5px] font-bold">
            <span className="text-slate-300">{tr('توزيع الأرباح حسب التطبيق')}</span>
          </div>
          <div className="flex h-2.5 w-full overflow-hidden rounded-full bg-white/[0.06]">
            {split ? (
              <>
                <div className="h-full bg-gradient-to-r from-orange-500 to-orange-400 transition-all duration-700" style={{ width: `${nPct}%` }} />
                <div className="h-full bg-gradient-to-r from-emerald-500 to-emerald-400 transition-all duration-700" style={{ width: `${aPct}%` }} />
              </>
            ) : null}
          </div>
          <div className="mt-2.5 flex items-center justify-between text-[11.5px]">
            <span className="flex items-center gap-1.5 font-extrabold text-orange-300">
              <span className="h-2 w-2 rounded-full bg-orange-400" />
              NITA · <span className="tabular-nums">{fmt(n)}</span>
              <span className="text-slate-500">({nPct}%)</span>
            </span>
            <span className="flex items-center gap-1.5 font-extrabold text-emerald-300">
              <span className="h-2 w-2 rounded-full bg-emerald-400" />
              AMANA · <span className="tabular-nums">{fmt(a)}</span>
              <span className="text-slate-500">({aPct}%)</span>
            </span>
          </div>
        </div>

        {/* الرسم البياني */}
        <div className="mt-5">
          <p className="mb-2 text-[11.5px] font-bold text-slate-300">{tr('الأرباح اليومية')}</p>
          {chartSpec ? (
            <div className="rounded-2xl border border-white/[0.06] bg-white/[0.02] p-2 md:p-3">
              <Chart spec={chartSpec} />
            </div>
          ) : (
            <p className="rounded-2xl border border-dashed border-white/10 py-8 text-center text-[12px] text-slate-500">
              {tr('لا توجد أرباح مسجّلة بعد')}
            </p>
          )}
        </div>
      </div>
    </section>
  )
}
