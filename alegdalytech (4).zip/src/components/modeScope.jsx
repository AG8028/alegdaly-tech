import { createContext, useContext } from 'react'

/** الوضع الحالي (ليلي/نهاري) داخل شجرة واجهة — للمكوّنات المشتركة */
const ModeCtx = createContext(null)
export const ModeScope = ({ mode, children }) => <ModeCtx.Provider value={mode}>{children}</ModeCtx.Provider>
export const useScopeMode = (fallback) => useContext(ModeCtx) || fallback
