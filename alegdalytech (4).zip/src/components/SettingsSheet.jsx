import { useEffect, useState } from 'react'
import { createPortal } from 'react-dom'
import { Settings, X, Lock, Fingerprint, KeyRound, Users, Copy, Check, Eye, EyeOff, Mail, BellRing, ShieldAlert } from 'lucide-react'
import { push } from '../lib/push'
import { useNotifyPrefs } from './notifyPrefs'
import { team } from '../lib/team'
import { db } from '../lib/db'
import { foldTypedDigits } from '../lib/_typed-digits.js'
import { useSession } from './Session'
import { useToast } from './ui'
import { tr } from './i18n'
import { generatePin, pinLabel, copyText, credentialsMessage } from './credentials'
import { getLock, setLockPin, clearLock, bioAvailable, enableBio, disableBio, bioErrorText, inAndroidApp } from './AppLock'

const digits = (v, n = 6) => foldTypedDigits(v).replace(/\D/g, '').slice(0, n)

/** زر الإعدادات (ترس) — يفتح لوحة الإعدادات */
export function SettingsButton({ mode = 'dark', variant = 'compact' }) {
  const [open, setOpen] = useState(false)
  const light = mode === 'light'
  const cls =
    variant === 'side'
      ? `flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-[13px] font-bold transition ${light ? 'text-[#5b6b63] hover:bg-[#f1f6f2]' : 'text-slate-400 hover:bg-white/[0.05] hover:text-slate-200'}`
      : `flex h-9 w-9 items-center justify-center rounded-xl border transition active:scale-95 ${light ? 'border-[#e3ebe6] bg-white text-[#0f766e] hover:bg-[#f1f6f2]' : 'border-white/[0.08] bg-white/[0.04] text-amber-200 hover:bg-white/[0.08]'}`
  return (
    <>
      <button type="button" onClick={() => setOpen(true)} aria-label={tr('الإعدادات')} className={cls}>
        <Settings size={variant === 'side' ? 17 : 16} />
        {variant === 'side' ? <span>{tr('الإعدادات')}</span> : null}
      </button>
      {open ? createPortal(<SettingsSheet light={light} onClose={() => setOpen(false)} />, document.body) : null}
    </>
  )
}

function SettingsSheet({ light, onClose }) {
  const s = useSession()
  const uid = s.user?.id
  const isHandleLogin = !!s.member?.handle
  const P = light
    ? { card: 'bg-white text-slate-900', sec: 'border-slate-200 bg-slate-50', mute: 'text-slate-500', input: 'border-slate-200 bg-white text-slate-900', soft: 'bg-slate-100 text-slate-700 hover:bg-slate-200' }
    : { card: 'border border-white/10 bg-[#0b1424] text-slate-100', sec: 'border-white/[0.07] bg-white/[0.03]', mute: 'text-slate-400', input: 'border-white/10 bg-[#060b18] text-white', soft: 'bg-white/[0.06] text-slate-200 hover:bg-white/[0.1]' }

  return (
    <div
      className="fixed inset-0 z-40 flex items-end justify-center bg-black/60 backdrop-blur-sm md:items-center md:p-6"
      style={{ height: 'var(--visual-height, 100dvh)' }}
      onClick={onClose}
    >
      <div
        dir={document.documentElement.dir || 'rtl'}
        onClick={(e) => e.stopPropagation()}
        className={`rise w-full max-w-lg overflow-y-auto rounded-t-[28px] p-5 pb-[calc(env(safe-area-inset-bottom,0px)+20px)] shadow-2xl md:rounded-[28px] md:pb-5 ${P.card}`}
        style={{ maxHeight: 'calc(var(--visual-height, 100dvh) - 1.5rem)' }}
      >
        <div className="flex items-center justify-between">
          <p className="font-display flex items-center gap-2 text-[19px] font-black">
            <Settings size={18} className="text-amber-400" /> {tr('الإعدادات')}
          </p>
          <button type="button" onClick={onClose} aria-label={tr('إغلاق')} className={`flex h-9 w-9 items-center justify-center rounded-full ${P.soft}`}>
            <X size={17} />
          </button>
        </div>

        <div className="mt-4 space-y-3">
          <LockSection uid={uid} name={s.user?.displayName || s.member?.displayName} P={P} />
          <NotifySection uid={uid} P={P} />
          <PasswordSection isHandleLogin={isHandleLogin} email={s.user?.email} P={P} />
          {s.canManage && s.mode === 'main' ? <AgentsSection P={P} /> : null}
          {s.canManage && s.mode === 'office' ? (
            <Section icon={Users} title={tr('كلمات مرور الوكلاء')} P={P}>
              <p className={`text-[12.5px] leading-relaxed ${P.mute}`}>
                {tr('وكلاء المكتب يدخلون بالبريد الإلكتروني، ويغيّر كل واحد كلمة مروره بنفسه من «نسيت كلمة المرور؟» في نافذة الدخول.')}
              </p>
            </Section>
          ) : null}
        </div>
      </div>
    </div>
  )
}

function Section({ icon: Icon, title, P, children }) {
  return (
    <div className={`rounded-2xl border p-4 ${P.sec}`}>
      <p className="font-display mb-3 flex items-center gap-2 text-[14.5px] font-extrabold">
        <Icon size={16} className="text-emerald-400" /> {title}
      </p>
      {children}
    </div>
  )
}

function Toggle({ on, onClick, disabled }) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      aria-pressed={on}
      className={`relative h-7 w-12 shrink-0 rounded-full transition disabled:opacity-40 ${on ? 'bg-emerald-500' : 'bg-slate-500/40'}`}
    >
      <span className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow transition-all ${on ? 'start-6' : 'start-1'}`} />
    </button>
  )
}

function LockSection({ uid, name, P }) {
  const toast = useToast()
  const [lock, setLock] = useState(() => getLock(uid))
  const [bioOk, setBioOk] = useState('maybe')
  const [setting, setSetting] = useState(false)
  const [a, setA] = useState('')
  const [b, setB] = useState('')
  const [busy, setBusy] = useState(false)

  useEffect(() => { bioAvailable().then(setBioOk) }, [])
  const reload = () => setLock(getLock(uid))

  async function savePin() {
    if (a.length < 4) return toast(tr('الرمز من 4 إلى 6 أرقام'), 'err')
    if (a !== b) return toast(tr('الرمزان غير متطابقين'), 'err')
    await setLockPin(uid, a)
    setA(''); setB(''); setSetting(false); reload()
    toast(tr('تم تفعيل الدخول بالرمز'))
  }

  function turnOff() {
    clearLock(uid); reload()
    toast(tr('تم إيقاف قفل التطبيق'))
  }

  async function toggleBio() {
    if (lock?.bio) { disableBio(uid); reload(); return toast(tr('تم إيقاف البصمة')) }
    setBusy(true)
    try { await enableBio(uid, name); reload(); toast(tr('تم تفعيل الدخول بالبصمة')) } catch (e) { toast(bioErrorText(e), 'err') } finally { setBusy(false) }
  }

  const inp = `w-full rounded-xl border px-3 py-3 text-center font-display text-[20px] tracking-[0.4em] outline-none focus:border-emerald-400 ${P.input}`

  return (
    <Section icon={Lock} title={tr('قفل التطبيق')} P={P}>
      <p className={`mb-3 text-[12px] leading-relaxed ${P.mute}`}>{tr('يُطلب عند فتح التطبيق على هذا الجهاز فقط، وبعد تركه في الخلفية أكثر من دقيقة.')}</p>

      <div className="flex items-center justify-between gap-3">
        <span className="text-[13.5px] font-bold">{tr('الدخول برمز')}</span>
        <Toggle on={!!lock} onClick={() => (lock ? turnOff() : setSetting((v) => !v))} />
      </div>

      {setting || (lock && setting) ? (
        <div className="mt-3 space-y-2">
          <input dir="ltr" type="password" inputMode="numeric" value={a} onChange={(e) => setA(digits(e.target.value))} placeholder={tr('رمز جديد')} className={inp} />
          <input dir="ltr" type="password" inputMode="numeric" value={b} onChange={(e) => setB(digits(e.target.value))} placeholder={tr('أعد كتابة الرمز')} className={inp} />
          <div className="grid grid-cols-2 gap-2">
            <button type="button" onClick={() => { setSetting(false); setA(''); setB('') }} className={`rounded-xl py-2.5 text-[13px] font-bold ${P.soft}`}>{tr('إلغاء')}</button>
            <button type="button" onClick={savePin} className="rounded-xl bg-emerald-600 py-2.5 text-[13px] font-extrabold text-white hover:bg-emerald-500">{tr('حفظ الرمز')}</button>
          </div>
        </div>
      ) : lock ? (
        <button type="button" onClick={() => setSetting(true)} className="mt-2 text-[12.5px] font-extrabold text-emerald-400">{tr('تغيير رمز القفل')}</button>
      ) : null}

      <div className="mt-4 flex items-center justify-between gap-3">
        <span className="flex items-center gap-2 text-[13.5px] font-bold"><Fingerprint size={16} className="text-amber-400" /> {tr('الدخول بالبصمة')}</span>
        <Toggle on={!!lock?.bio} onClick={toggleBio} disabled={!lock || busy || (bioOk === 'no' && !lock?.bio)} />
      </div>
      <p className={`mt-1.5 text-[11.5px] ${P.mute}`}>
        {bioOk === 'no'
          ? tr(inAndroidApp() ? 'البصمة غير متاحة داخل نسخة التطبيق المثبّتة حالياً — افتح التطبيق من Chrome لتفعيلها.' : 'هذا المتصفح لا يدعم البصمة — جرّب Chrome.')
          : !lock
            ? tr('فعّل الدخول برمز أولاً، ثم البصمة.')
            : bioOk === 'maybe' && !lock?.bio
              ? tr('اضغط الزر وضع إصبعك — إذا ظهرت نافذة البصمة فهي تعمل. الرمز يبقى بديلاً.')
              : tr('الرمز يبقى بديلاً إذا لم تعمل البصمة.')}
      </p>
    </Section>
  )
}

function NotifySection({ uid, P }) {
  const toast = useToast()
  const { prefs, update } = useNotifyPrefs(uid)
  const [perm, setPerm] = useState(() => push.getPermission())
  const [busy, setBusy] = useState(false)

  async function flip(key) {
    if (!prefs) return
    const on = !prefs[key]
    try {
      await update({ [key]: on })
      toast(tr(on ? 'تم تشغيل الإشعارات' : 'تم إيقاف الإشعارات'))
    } catch (e) {
      toast(e?.message || tr('حدث خطأ، حاول مرة أخرى'), 'err')
    }
  }

  async function enableDevice() {
    if (busy) return
    const diag = push.diagnose()
    if (!diag.canSchedule) return toast(diag.hint || tr('الإشعارات لا تعمل في المعاينة — جرّبها من التطبيق المنشور'), 'info')
    setBusy(true)
    try {
      const p = await push.requestPermission()
      setPerm(p)
      if (p !== 'granted') return toast(tr('لم يتم السماح بالإشعارات'), 'err')
      await push.subscribe()
      toast(tr('تم تفعيل الإشعارات على هذا الجهاز'))
    } catch (e) {
      toast(e?.message || tr('حدث خطأ، حاول مرة أخرى'), 'err')
    } finally { setBusy(false) }
  }

  return (
    <Section icon={BellRing} title={tr('الإشعارات')} P={P}>
      <div className="flex items-center justify-between gap-3">
        <div className="min-w-0">
          <p className="text-[13.5px] font-bold">{tr('إشعارات الحوالات والشراكات')}</p>
          <p className={`text-[11.5px] leading-relaxed ${P.mute}`}>{tr('حوالة واردة، تسليم، إلغاء، وطلبات الشراكة.')}</p>
        </div>
        <Toggle on={!!prefs?.ops} disabled={!prefs} onClick={() => flip('ops')} />
      </div>
      <div className="mt-4 flex items-center justify-between gap-3">
        <div className="min-w-0">
          <p className="flex items-center gap-1.5 text-[13.5px] font-bold"><ShieldAlert size={15} className="text-rose-400" /> {tr('التنبيهات الأمنية')}</p>
          <p className={`text-[11.5px] leading-relaxed ${P.mute}`}>{tr('عند إدخال رقم سري خاطئ لحوالتك. ننصح بتركها مشغّلة.')}</p>
        </div>
        <Toggle on={!!prefs?.sec} disabled={!prefs} onClick={() => flip('sec')} />
      </div>
      {perm !== 'granted' && (prefs?.ops || prefs?.sec) ? (
        <button type="button" onClick={enableDevice} disabled={busy} className="mt-4 w-full rounded-xl bg-amber-400 py-2.5 text-[13px] font-extrabold text-[#1a1206] hover:bg-amber-300 disabled:opacity-50">
          {tr(busy ? 'جارٍ...' : 'استقبال الإشعارات على هذا الجهاز')}
        </button>
      ) : null}
      <p className={`mt-3 text-[11px] leading-relaxed ${P.mute}`}>{tr('الإيقاف يسري على كل أجهزتك. الحوالات تبقى تظهر داخل التطبيق عادي.')}</p>
    </Section>
  )
}

function PasswordSection({ isHandleLogin, email, P }) {
  const toast = useToast()
  const [cur, setCur] = useState('')
  const [next, setNext] = useState('')
  const [show, setShow] = useState(false)
  const [busy, setBusy] = useState(false)

  async function save() {
    if (next.length < 6) return toast(tr('كلمة المرور الجديدة 6 أحرف على الأقل'), 'err')
    setBusy(true)
    try {
      await team.changePassword(cur, next)
      setCur(''); setNext('')
      toast(tr('تم تغيير كلمة المرور'))
    } catch (e) {
      toast(e?.message || tr('تعذّر التغيير — تأكد من كلمة المرور الحالية'), 'err')
    } finally { setBusy(false) }
  }

  const inp = `w-full rounded-xl border px-3 py-3 text-[14px] outline-none focus:border-emerald-400 ${P.input}`

  return (
    <Section icon={KeyRound} title={tr('تغيير كلمة المرور')} P={P}>
      {isHandleLogin ? (
        <div className="space-y-2">
          <input dir="ltr" type={show ? 'text' : 'password'} value={cur} onChange={(e) => setCur(e.target.value)} autoComplete="current-password" placeholder={tr('كلمة المرور الحالية')} className={inp} />
          <input dir="ltr" type={show ? 'text' : 'password'} value={next} onChange={(e) => setNext(e.target.value)} autoComplete="new-password" placeholder={tr('كلمة المرور الجديدة')} className={inp} />
          <div className="flex items-center justify-between gap-2">
            <button type="button" onClick={() => setShow((v) => !v)} className="flex items-center gap-1.5 text-[12px] font-extrabold text-emerald-400">
              {show ? <EyeOff size={14} /> : <Eye size={14} />} {tr(show ? 'إخفاء' : 'إظهار')}
            </button>
            <button type="button" onClick={save} disabled={busy || !cur || !next} className="rounded-xl bg-emerald-600 px-4 py-2.5 text-[13px] font-extrabold text-white hover:bg-emerald-500 disabled:opacity-50">
              {tr(busy ? 'جارٍ الحفظ...' : 'حفظ')}
            </button>
          </div>
        </div>
      ) : (
        <p className={`flex gap-2 text-[12.5px] leading-relaxed ${P.mute}`}>
          <Mail size={15} className="mt-0.5 shrink-0 text-amber-400" />
          <span>{tr('حسابك بالبريد الإلكتروني{e}. لتغيير كلمة المرور: سجّل الخروج، ثم في نافذة الدخول اضغط «نسيت كلمة المرور؟» ويصلك رابط التغيير على بريدك.', { e: email ? ` (${email})` : '' })}</span>
        </p>
      )}
    </Section>
  )
}

function AgentsSection({ P }) {
  const { allAgents, gid } = useSession()
  const toast = useToast()
  const [busyId, setBusyId] = useState(null)
  const [fresh, setFresh] = useState(null)
  const [copied, setCopied] = useState(false)

  async function reset(agent) {
    if (!gid) return
    setBusyId(agent.userId)
    try {
      const pin = generatePin()
      await team.resetPassword(agent.userId, pin)
      await db.upsertShared('agents', { pin: null, handle: agent.handle, name: agent.name }, agent.userId, {
        groupId: gid, visibleTo: `user:${agent.userId}`, writableBy: 'admins',
      })
      setFresh({ ...agent, pin }); setCopied(false)
      toast(tr('تم إنشاء رمز جديد'))
    } catch (e) {
      toast(e?.message || tr('تعذّر تغيير الرمز'), 'err')
    } finally { setBusyId(null) }
  }

  return (
    <Section icon={Users} title={tr('رموز الوكلاء')} P={P}>
      {fresh ? (
        <div className="mb-3 rounded-xl border border-amber-400/40 bg-amber-400/10 p-3">
          <p className="text-[12px] font-bold">{tr('الرمز الجديد لـ {name}', { name: fresh.name })}</p>
          <p dir="ltr" className="font-display mt-1 text-[24px] font-black tracking-widest text-amber-300">{pinLabel(fresh.pin)}</p>
          <p dir="ltr" className={`text-[11.5px] ${P.mute}`}>@{fresh.handle}</p>
          <button
            type="button"
            onClick={async () => { if (await copyText(credentialsMessage({ appName: tr('الأقدالي للتقنية'), name: fresh.name, handle: fresh.handle, pin: fresh.pin }))) setCopied(true) }}
            className="mt-2 flex items-center gap-1.5 text-[12px] font-extrabold text-emerald-400"
          >
            {copied ? <Check size={14} /> : <Copy size={14} />} {tr(copied ? 'تم النسخ' : 'نسخ بيانات الدخول')}
          </button>
        </div>
      ) : null}
      {allAgents.length === 0 ? (
        <p className={`text-[12.5px] ${P.mute}`}>{tr('لا يوجد وكلاء بعد.')}</p>
      ) : (
        <div className="space-y-2">
          {allAgents.map((a) => (
            <div key={a.userId} className="flex items-center justify-between gap-2">
              <div className="min-w-0">
                <p className="truncate text-[13.5px] font-bold">{a.name}</p>
                <p dir="ltr" className={`truncate text-start text-[11px] ${P.mute}`}>@{a.handle || '—'}</p>
              </div>
              <button
                type="button"
                onClick={() => reset(a)}
                disabled={busyId === a.userId}
                className={`shrink-0 rounded-xl px-3 py-2 text-[12px] font-extrabold disabled:opacity-50 ${P.soft}`}
              >
                {tr(busyId === a.userId ? 'جارٍ...' : 'رمز جديد')}
              </button>
            </div>
          ))}
        </div>
      )}
    </Section>
  )
}
