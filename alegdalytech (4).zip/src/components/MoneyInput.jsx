import { foldTypedDigits } from '../lib/_typed-digits.js'

/** يحوّل أي نص مكتوب إلى أرقام فقط (يدعم الأرقام العربية) */
export function toDigits(v) {
  return foldTypedDigits(String(v ?? ''))
    .replace(/[^\d]/g, '')
    .replace(/^0+(?=\d)/, '')
    .slice(0, 12)
}

/** يعرض الرقم مفصولاً كل ثلاث خانات: 140,000 */
export function groupDigits(v) {
  const d = toDigits(v)
  return d ? d.replace(/\B(?=(\d{3})+(?!\d))/g, ',') : ''
}

/**
 * خانة مبلغ: تعرض الرقم مفصولاً بالفواصل وتعيد القيمة الخام (أرقام فقط) عبر onChange.
 */
export default function MoneyInput({ value, onChange, className = '', placeholder, ...rest }) {
  return (
    <input
      type="text"
      inputMode="numeric"
      autoComplete="off"
      value={groupDigits(value)}
      onChange={(e) => onChange(toDigits(e.target.value))}
      placeholder={placeholder}
      className={`${className} tabular-nums tracking-wide`}
      {...rest}
    />
  )
}
