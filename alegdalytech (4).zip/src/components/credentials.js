// أدوات حسابات الوكلاء: توليد الرموز وأسماء الدخول

/** رمز PIN من 6 أرقام (تلقائي) */
export function generatePin() {
  // مولّد عشوائي آمن من المتصفح (crypto) — مع رفض القيم المنحازة
  const c = typeof crypto !== 'undefined' ? crypto : null
  if (!c?.getRandomValues) throw new Error('Secure random generator unavailable')
  const a = new Uint32Array(1)
  const limit = Math.floor(0x100000000 / 900000) * 900000
  do { c.getRandomValues(a) } while (a[0] >= limit)
  return String(100000 + (a[0] % 900000))
}

/** اسم دخول مقترح من الاسم — أحرف إنجليزية وأرقام فقط */
export function suggestHandle(name, taken = []) {
  const set = new Set((taken || []).map((t) => String(t || '').toLowerCase()))
  const base = String(name || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '')
    .slice(0, 20)
  let handle = base.length >= 3 ? base : `agent${Math.floor(100 + Math.random() * 900)}`
  let n = 1
  while (set.has(handle)) {
    n += 1
    handle = `${base.slice(0, 18) || 'agent'}${n}`
  }
  return handle
}

export const handleOk = (h) => /^[a-z0-9_]{3,30}$/.test(String(h || ''))

/** تنسيق الرمز بصورة مقروءة: 123 456 */
export function pinLabel(pin) {
  const p = String(pin || '')
  if (p.length !== 6) return p || '—'
  return `${p.slice(0, 3)} ${p.slice(3)}`
}

export function maskPin(pin) {
  const p = String(pin || '')
  return p ? '•'.repeat(Math.min(p.length, 6)) : '—'
}

export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(String(text))
    return true
  } catch {
    try {
      const ta = document.createElement('textarea')
      ta.value = String(text)
      ta.style.position = 'fixed'
      ta.style.opacity = '0'
      document.body.appendChild(ta)
      ta.select()
      const ok = document.execCommand('copy')
      document.body.removeChild(ta)
      return ok
    } catch {
      return false
    }
  }
}

/** نص بيانات الدخول الجاهز للإرسال للوكيل */
export function credentialsMessage({ appName = 'الأقدالي للتقنية', name, handle, pin }) {
  return `${appName}\nبيانات دخولك إلى التطبيق:\n\nالاسم: ${name}\nاسم المستخدم: ${handle}\nالرمز السري: ${pin}\n\nاحفظ هذه البيانات ولا تشاركها مع أحد.`
}
