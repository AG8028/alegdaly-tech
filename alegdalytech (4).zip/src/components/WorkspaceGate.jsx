import { useState } from 'react'
import { Building2, Clock, Lock, UserX, AlertTriangle, RefreshCw, Crown, MessageCircle, Phone, UserRound, ArrowLeft, ArrowRight } from 'lucide-react'
import { share } from '../lib/share'
import { db } from '../lib/db'
import { useLiveShared } from '../lib/useLive'
import { useSession } from './Session'
import Logo from './Logo'
import SignOutButton from './SignOut'
import { tr, LangSwitcher, useLang } from './i18n'
import { useMode, ThemeToggle, ModeScope } from './theme'
import { fmtDate, CFG_COLL, CFG_ID, waNumber, resolveOfficeInput } from './saas'

/** حساب جديد غير مرتبط: يختار «أنا صاحب مكتب» أو «أنا وكيل» */
function RoleChooser() {
  const { lang } = useLang()
  const Go = lang === 'ar' ? ArrowLeft : ArrowRight
  const [agent, setAgent] = useState(false)
  const [code, setCode] = useState('')
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState(null)

  async function join(e) {
    e.preventDefault()
    if (busy) return
    setErr(null)
    setBusy(true)
    try {
      const r = await resolveOfficeInput(code, db)
      if (r.id) {
        window.location.hash = `#/join/${encodeURIComponent(r.id)}`
        return
      }
      setErr(r.error === 'ambiguous' ? tr('الكود يطابق أكثر من مكتب، الصق رابط الانضمام كاملاً') : tr('لم نجد مكتباً بهذا الكود، تأكد منه مع صاحب المكتب'))
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="mt-5 space-y-3 text-start">
      <button
        type="button"
        onClick={() => { window.location.hash = '#/offices' }}
        className="flex w-full touch-manipulation items-center gap-3 rounded-2xl bg-gradient-to-br from-[#fbe3a1] via-[#f0b847] to-[#c98a22] px-4 py-3.5 text-[#1a1206] transition hover:brightness-105"
      >
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-black/10"><Crown size={19} /></span>
        <span className="min-w-0 flex-1">
          <span className="block text-[15px] font-black">{tr('أنا صاحب مكتب')}</span>
          <span className="block text-[11.5px] font-bold opacity-70">{tr('اختر باقة واشترك لتحصل على مساحتك')}</span>
        </span>
        <Go size={18} className="shrink-0" />
      </button>

      <div className="rounded-2xl border border-emerald-400/35 bg-emerald-500/[0.08]">
        <button
          type="button"
          onClick={() => setAgent((v) => !v)}
          className="flex w-full touch-manipulation items-center gap-3 px-4 py-3.5 text-emerald-50"
        >
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-emerald-500/15 text-emerald-300"><UserRound size={19} /></span>
          <span className="min-w-0 flex-1 text-start">
            <span className="block text-[15px] font-black">{tr('أنا وكيل')}</span>
            <span className="block text-[11.5px] font-bold text-emerald-200/60">{tr('أدخل كود المكتب أو رابط الانضمام')}</span>
          </span>
          <Go size={18} className={`shrink-0 transition ${agent ? 'rotate-90' : ''}`} />
        </button>
        {agent ? (
          <form onSubmit={join} className="border-t border-emerald-400/15 px-4 pb-4 pt-3">
            <input
              value={code}
              onChange={(e) => setCode(e.target.value)}
              dir="ltr"
              autoCapitalize="characters"
              autoCorrect="off"
              placeholder="AB12CD"
              className="lux-latin w-full rounded-[0.9rem] border border-white/10 bg-white/[0.04] px-3.5 py-3 text-center text-[17px] font-black tracking-[0.3em] text-slate-50 outline-none placeholder:text-slate-600 focus:border-emerald-400/60"
            />
            {err ? <p role="alert" className="mt-2 text-[12px] font-bold text-rose-300">{err}</p> : null}
            <button
              type="submit"
              disabled={busy || !code.trim()}
              className="keep-color mt-3 flex w-full items-center justify-center gap-2 rounded-full bg-emerald-600 py-3 text-[14px] font-extrabold text-white hover:bg-emerald-500 disabled:opacity-50"
            >
              {busy ? <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" /> : null}
              {tr('متابعة')}
            </button>
            <p className="mt-2 text-[11px] leading-relaxed text-slate-500">{tr('اطلب الكود من صاحب المكتب، تجده عنده في شاشة «الوكلاء».')}</p>
          </form>
        ) : null}
      </div>
    </div>
  )
}

/** تواصل مع ALEGDALY TECH — واتساب برسالة جاهزة + الرقم ظاهر للاتصال */
function ContactSupport({ message }) {
  const { data } = useLiveShared(CFG_COLL)
  const cfg = (data || []).find((r) => r.id === CFG_ID)
  const num = waNumber(cfg?.whatsapp)
  if (!num) return null
  return (
    <div className="mt-4 rounded-2xl border border-emerald-400/20 bg-emerald-500/[0.06] p-3.5">
      <p className="text-[12px] font-bold text-slate-300">{tr('تحتاج مساعدة؟ تواصل مع ALEGDALY TECH')}</p>
      <div className="mt-2.5 grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={() => share.whatsapp(num, message)}
          className="keep-color flex items-center justify-center gap-1.5 rounded-xl bg-emerald-600 py-3 text-[13px] font-extrabold text-white hover:bg-emerald-500"
        >
          <MessageCircle size={16} /> {tr('واتساب')}
        </button>
        <a
          href={`tel:+${num}`}
          className="flex items-center justify-center gap-1.5 rounded-xl border border-white/10 bg-white/[0.04] py-3 text-[13px] font-extrabold text-slate-200 hover:bg-white/[0.08]"
        >
          <Phone size={15} /> {tr('اتصال')}
        </a>
      </div>
      <p className="mt-2 text-[11.5px] text-slate-500" dir="ltr">+{num}</p>
    </div>
  )
}

/** شاشة بديلة عندما لا تكون مساحة العمل جاهزة: بلا مساحة · قيد المراجعة · مقفلة · موقوف */
export default function WorkspaceGate() {
  const { workspace, mode, officeName, officeStatus, user, refresh } = useSession()
  const { lang } = useLang()
  const { mode: theme, toggle } = useMode('dark')

  let icon = Building2
  let tone = 'text-amber-300 bg-amber-400/10'
  let title = ''
  let text = ''
  let action = null

  const goOffices = (label) => (
    <a
      href="#/offices"
      className="flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-br from-[#fbe3a1] via-[#f0b847] to-[#c98a22] py-3.5 text-[15px] font-extrabold text-[#1a1206]"
    >
      <Crown size={17} /> {label}
    </a>
  )

  if (workspace === 'none') {
    title = tr('أهلاً بك في ALEGDALY TECH')
    text = tr('حسابك جاهز. اختر من أنت لنكمل:')
    action = <RoleChooser />
  } else if (workspace === 'pending') {
    icon = Clock
    title = tr('طلبك بانتظار موافقة صاحب المكتب')
    text = officeName ? tr('أرسلت طلب انضمام إلى {office}. ستدخل تلقائياً عند الموافقة.', { office: officeName }) : tr('ستدخل تلقائياً عند الموافقة.')
  } else if (workspace === 'removed') {
    icon = UserX
    tone = 'text-rose-300 bg-rose-500/10'
    title = tr('لا يمكنك الدخول إلى هذا المكتب')
    text = tr('أوقف صاحب المكتب حسابك أو رفض طلبك. تواصل معه.')
  } else if (workspace === 'locked') {
    icon = Lock
    tone = 'text-rose-300 bg-rose-500/10'
    if (mode === 'office') {
      title = officeStatus?.status === 'suspended' ? tr('اشتراك مكتبك موقوف') : tr('انتهى اشتراك مكتبك')
      text = officeStatus?.status === 'suspended'
        ? tr('تواصل مع ALEGDALY TECH لإعادة التفعيل. بياناتك محفوظة.')
        : tr('انتهى في {d}. جدّد الاشتراك لتعود إلى مكتبك — كل بياناتك ووكلائك محفوظون.', { d: fmtDate(officeStatus?.expiresAt, lang) })
      if (officeStatus?.status !== 'suspended') action = goOffices(tr('جدّد الاشتراك'))
    } else {
      title = tr('مساحة المكتب مقفلة مؤقتاً')
      text = tr('اشتراك {office} غير فعّال حالياً. ستعود تلقائياً بعد التجديد.', { office: officeName || tr('المكتب') })
    }
  } else if (workspace === 'broken') {
    icon = AlertTriangle
    title = tr('مساحة المكتب قيد التجهيز')
    text = tr('لم يكتمل تجهيز مساحتك بعد. حاول بعد قليل، أو تواصل مع ALEGDALY TECH.')
  }

  const Icon = icon

  // رسالة التواصل الجاهزة حسب الحالة
  const who = user?.email || user?.displayName || ''
  const office = officeName || ''
  const supportMsg =
    workspace === 'locked'
      ? tr('مرحباً، اشتراك مكتب «{office}» متوقف وأريد إعادة تفعيله. حسابي: {who}', { office, who })
      : tr('مرحباً، لديّ مشكلة في الدخول إلى ALEGDALY TECH. حسابي: {who}', { who })
  const showSupport = workspace === 'locked' || workspace === 'broken' || workspace === 'none'

  return (
    <ModeScope mode={theme}>
      <div className="lux-gate skin-dark relative h-full overflow-y-auto bg-[#050a16]" data-mode={theme}>
        <div aria-hidden="true" className="pointer-events-none fixed inset-0 overflow-hidden">
          <div className="lux-orb absolute -top-40 start-[-10%] h-[440px] w-[440px] rounded-full bg-emerald-500/15 blur-[120px]" />
          <div className="lux-orb lux-orb-2 absolute bottom-[-160px] end-[-8%] h-[480px] w-[480px] rounded-full bg-amber-400/12 blur-[130px]" />
          <div className="lux-grid absolute inset-0" />
        </div>
        <div className="relative z-10 mx-auto flex min-h-full w-full max-w-md flex-col px-5 pb-[calc(env(safe-area-inset-bottom,0px)+24px)] pt-[calc(env(safe-area-inset-top,0px)+16px)]">
          <header className="flex items-center justify-between gap-2">
            <Logo className="h-11 w-11" />
            <div className="flex items-center gap-1.5">
              <ThemeToggle mode={theme} onToggle={toggle} />
              <LangSwitcher compact />
            </div>
          </header>

          <div className="flex flex-1 flex-col justify-center py-10">
            <div className="rise relative">
              <div className="absolute -inset-px rounded-[1.6rem] bg-gradient-to-b from-amber-300/40 via-white/5 to-emerald-400/30" />
              <div className="relative rounded-[1.55rem] bg-gradient-to-b from-[#101a30]/95 to-[#080e1c]/95 p-6 text-center">
                <span className={`mx-auto flex h-14 w-14 items-center justify-center rounded-2xl ${tone}`}>
                  <Icon size={26} />
                </span>
                <p className="font-display mt-4 text-[20px] font-black leading-snug text-white">{title}</p>
                <p className="mt-2 text-[13px] leading-relaxed text-slate-400">{text}</p>
                {action ? (workspace === 'none' ? action : <div className="mt-5">{action}</div>) : null}
                {showSupport ? <ContactSupport message={supportMsg} /> : null}
                <button
                  type="button"
                  onClick={refresh}
                  className="mt-3 inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-4 py-2.5 text-[12.5px] font-bold text-slate-300 hover:text-white"
                >
                  <RefreshCw size={14} /> {tr('تحديث')}
                </button>
                <p className="mt-4 text-[11px] text-slate-500">{tr('مسجّل باسم {email}', { email: user?.email || user?.displayName || '—' })}</p>
              </div>
            </div>
            <div className="mt-4">
              <SignOutButton variant="full" mode={theme} />
            </div>
          </div>
        </div>
      </div>
    </ModeScope>
  )
}
