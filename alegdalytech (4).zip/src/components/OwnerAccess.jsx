import { useState } from 'react'
import { Crown, Eye, EyeOff, KeyRound } from 'lucide-react'
import { team } from '../lib/team'
import { auth } from '../lib/auth'
import { useSession } from './Session'
import { Card, Field, PrimaryBtn, fieldCls, useToast } from './ui'
import { handleOk } from './credentials'
import { tr } from './i18n'

/** دخول المالك باسم مستخدم وكلمة مرور — يظهر للمالك الأساسي فقط */
export default function OwnerAccess() {
  const { managers, refresh } = useSession()
  const toast = useToast()
  const existing = (managers || [])[0] || null
  const [open, setOpen] = useState(false)
  const [handle, setHandle] = useState('')
  const [pass, setPass] = useState('')
  const [show, setShow] = useState(false)
  const [busy, setBusy] = useState(false)

  if (!auth.isAppOwner()) return null

  async function save() {
    const h = (existing?.handle || handle).trim().toLowerCase()
    if (!handleOk(h)) return toast(tr('اسم الدخول: أحرف إنجليزية أو أرقام، 3 خانات على الأقل'), 'err')
    if (pass.length < 6) return toast(tr('كلمة المرور 6 خانات على الأقل'), 'err')
    setBusy(true)
    let wasPin = false
    try {
      await team.setRoleAccess('manager', true).catch(() => {})
      const cfg = await team.config().catch(() => null)
      wasPin = cfg?.loginConfig?.pin === true
      // نسمح مؤقتاً بكلمة مرور حرّة، ثم نعيد نظام الرمز للوكلاء
      if (wasPin) await team.setLoginConfig({ pin: false })
      if (existing) {
        await team.resetPassword(existing.userId, pass)
        if (existing.role !== 'manager') await team.setRole(existing.userId, 'manager').catch(() => {})
      } else {
        await team.createMember({ handle: h, password: pass, role: 'manager', displayName: tr('المالك') })
      }
      toast(existing ? tr('تم تغيير كلمة مرور المالك') : tr('تم إنشاء دخول المالك'))
      setPass('')
      setHandle('')
      setOpen(false)
      await refresh()
    } catch (e) {
      const msg = e?.status === 409 ? tr('اسم المستخدم هذا مستخدم، اختر اسماً آخر') : e?.message || tr('تعذّر الحفظ')
      toast(msg, 'err')
    } finally {
      if (wasPin) await team.setLoginConfig({ pin: true }).catch(() => {})
      setBusy(false)
    }
  }

  return (
    <Card className="rise border-amber-300/20 bg-gradient-to-br from-amber-400/[0.07] to-transparent p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-amber-400/15 text-amber-300">
            <Crown size={18} />
          </span>
          <div>
            <p className="font-display text-[15px] font-extrabold text-slate-100">{tr('دخول المالك باسم مستخدم وكلمة مرور')}</p>
            <p className="mt-0.5 text-[12px] leading-relaxed text-slate-400">
              {existing
                ? tr('مفعّل — ادخل من تبويب «المالك» في شاشة الدخول.')
                : tr('أنشئ اسم مستخدم وكلمة مرور لتدخل بهما من أي جهاز بصلاحيات المالك.')}
            </p>
            {existing && (
              <p className="mt-1 flex items-center gap-1 text-[12px] font-bold text-amber-200" dir="ltr">
                <KeyRound size={11} />@{existing.handle}
              </p>
            )}
          </div>
        </div>
        {!open && (
          <button
            type="button"
            onClick={() => setOpen(true)}
            className="shrink-0 rounded-xl border border-amber-300/30 bg-amber-400/10 px-3 py-2 text-[12px] font-bold text-amber-200 transition hover:bg-amber-400/20"
          >
            {existing ? tr('تغيير كلمة المرور') : tr('إنشاء')}
          </button>
        )}
      </div>

      {open && (
        <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-2">
          {!existing && (
            <Field label={tr('اسم المستخدم')} hint={tr('أحرف إنجليزية وأرقام فقط')}>
              <input
                value={handle}
                onChange={(e) => setHandle(e.target.value)}
                autoCapitalize="none"
                autoCorrect="off"
                dir="ltr"
                placeholder="alegdaly"
                className={fieldCls}
              />
            </Field>
          )}
          <Field label={tr('كلمة المرور')} hint={tr('6 خانات على الأقل')}>
            <div className="relative">
              <input
                type={show ? 'text' : 'password'}
                value={pass}
                onChange={(e) => setPass(e.target.value)}
                autoComplete="new-password"
                dir="ltr"
                className={fieldCls}
                style={{ paddingRight: '3rem' }}
              />
              <button
                type="button"
                onClick={() => setShow((s) => !s)}
                aria-label={show ? tr('إخفاء') : tr('إظهار')}
                className="absolute inset-y-0 flex w-12 items-center justify-center text-slate-400 hover:text-amber-200"
                style={{ right: 0 }}
              >
                {show ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </Field>
          <div className="flex gap-2 md:col-span-2">
            <PrimaryBtn onClick={save} disabled={busy}>
              {busy ? tr('جارٍ الحفظ...') : tr('حفظ')}
            </PrimaryBtn>
            <button
              type="button"
              onClick={() => { setOpen(false); setPass('') }}
              className="rounded-xl border border-white/12 px-4 text-[13px] font-bold text-slate-300 hover:bg-white/[0.06]"
            >
              {tr('إلغاء')}
            </button>
          </div>
        </div>
      )}
    </Card>
  )
}
