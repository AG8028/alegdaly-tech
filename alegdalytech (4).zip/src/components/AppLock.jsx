import { useEffect, useState } from 'react'
import { Fingerprint, Delete, LogOut, Lock } from 'lucide-react'
import { auth } from '../lib/auth'
import Logo from './Logo'
import { tr } from './i18n'

/**
 * قفل التطبيق على هذا الجهاز — رمز أرقام و/أو بصمة الهاتف.
 * يُطلب عند فتح التطبيق وبعد بقائه في الخلفية أكثر من دقيقة.
 */
const KEY = (uid) => `alg_lock_${uid}`
const UNLOCK = (uid) => `alg_unlocked_${uid}`
const RELOCK_MS = 60 * 1000

const enc = new TextEncoder()
const toB64 = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf)))
const fromB64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0))
const rand = (n) => crypto.getRandomValues(new Uint8Array(n))

async function hashPin(pin, salt) {
  const d = await crypto.subtle.digest('SHA-256', enc.encode(`${salt}:${pin}`))
  return toB64(d)
}

export function getLock(uid) {
  if (!uid) return null
  try {
    const v = JSON.parse(localStorage.getItem(KEY(uid)) || 'null')
    return v && v.pinHash ? v : null
  } catch { return null }
}

function saveLock(uid, v) {
  try {
    if (v) localStorage.setItem(KEY(uid), JSON.stringify(v))
    else localStorage.removeItem(KEY(uid))
  } catch { /* ignore */ }
  window.dispatchEvent(new Event('alg-lock-change'))
}

export async function setLockPin(uid, pin) {
  const salt = toB64(rand(16))
  const prev = getLock(uid)
  saveLock(uid, { pinHash: await hashPin(pin, salt), salt, len: pin.length, bio: prev?.bio || null })
  markUnlocked(uid)
}

export function clearLock(uid) { saveLock(uid, null) }

function markUnlocked(uid) {
  try { sessionStorage.setItem(UNLOCK(uid), '1') } catch { /* ignore */ }
}

/** داخل تطبيق الأندرويد المثبّت (نافذة مدمجة) وليس المتصفح */
export function inAndroidApp() {
  try { return /; wv\)/.test(navigator.userAgent) } catch { return false }
}

/** 'yes' مؤكد · 'maybe' الفحص التلقائي لم يؤكد (نجرّب مع ذلك) · 'no' لا توجد خاصية بصمة إطلاقاً */
export async function bioAvailable() {
  try {
    if (!window.PublicKeyCredential || !navigator.credentials?.create) return 'no'
    if (!window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable) return 'maybe'
    const ok = await Promise.race([
      window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable(),
      new Promise((r) => setTimeout(() => r(null), 2500)),
    ])
    // بعض هواتف أندرويد تُرجع «لا» هنا مع أن البصمة تعمل — لذلك لا نمنع التجربة
    return ok ? 'yes' : 'maybe'
  } catch { return 'maybe' }
}

export async function enableBio(uid, displayName) {
  const lock = getLock(uid)
  if (!lock) throw new Error(tr('فعّل رمز القفل أولاً'))
  const cred = await navigator.credentials.create({
    publicKey: {
      challenge: rand(32),
      rp: { name: 'ALEGDALY TECH' },
      user: { id: enc.encode(uid).slice(0, 64), name: displayName || 'ALEGDALY', displayName: displayName || 'ALEGDALY' },
      pubKeyCredParams: [{ type: 'public-key', alg: -7 }, { type: 'public-key', alg: -257 }],
      authenticatorSelection: { authenticatorAttachment: 'platform', userVerification: 'preferred', residentKey: 'discouraged' },
      timeout: 60000,
    },
  })
  if (!cred) throw new Error(tr('لم يتم تفعيل البصمة'))
  saveLock(uid, { ...lock, bio: toB64(cred.rawId) })
}

export function disableBio(uid) {
  const lock = getLock(uid)
  if (lock) saveLock(uid, { ...lock, bio: null })
}

async function verifyBio(lock) {
  const res = await navigator.credentials.get({
    publicKey: {
      challenge: rand(32),
      allowCredentials: [{ type: 'public-key', id: fromB64(lock.bio), transports: ['internal', 'hybrid'] }],
      userVerification: 'preferred',
      timeout: 60000,
    },
  })
  return !!res
}

export function bioErrorText(e) {
  const n = e?.name || ''
  if (inAndroidApp() && (n === 'NotSupportedError' || n === 'SecurityError' || n === 'NotAllowedError' || !n)) {
    return tr('البصمة غير متاحة داخل نسخة التطبيق المثبّتة حالياً — تعمل عند فتح التطبيق من متصفح Chrome. الرمز يبقى يعمل.')
  }
  if (n === 'NotAllowedError') return tr('تم إلغاء البصمة أو انتهى الوقت')
  if (n === 'InvalidStateError') return tr('البصمة مسجّلة من قبل على هذا الجهاز')
  if (n === 'SecurityError' || n === 'NotSupportedError') return tr('البصمة لا تعمل في المعاينة — جرّبها من رابط التطبيق المنشور في Chrome')
  return e?.message || tr('تعذّر استخدام البصمة')
}

export function AppLockGate({ user, children }) {
  const uid = user?.id || null
  const [lock, setLock] = useState(() => getLock(uid))
  const [locked, setLocked] = useState(() => {
    const l = getLock(uid)
    if (!l) return false
    try { return sessionStorage.getItem(UNLOCK(uid)) !== '1' } catch { return true }
  })

  useEffect(() => {
    const on = () => setLock(getLock(uid))
    window.addEventListener('alg-lock-change', on)
    return () => window.removeEventListener('alg-lock-change', on)
  }, [uid])

  // إعادة القفل بعد البقاء في الخلفية
  useEffect(() => {
    let hiddenAt = 0
    const on = () => {
      if (document.visibilityState === 'hidden') hiddenAt = Date.now()
      else if (hiddenAt && Date.now() - hiddenAt > RELOCK_MS && getLock(uid)) {
        try { sessionStorage.removeItem(UNLOCK(uid)) } catch { /* ignore */ }
        setLocked(true)
      }
    }
    document.addEventListener('visibilitychange', on)
    return () => document.removeEventListener('visibilitychange', on)
  }, [uid])

  if (!lock || !locked) return children
  return <LockScreen uid={uid} lock={lock} name={user?.displayName} onUnlock={() => { markUnlocked(uid); setLocked(false) }} />
}

function LockScreen({ uid, lock, name, onUnlock }) {
  const [pin, setPin] = useState('')
  const [err, setErr] = useState('')
  const [fails, setFails] = useState(0)
  const [waitUntil, setWaitUntil] = useState(0)
  const [now, setNow] = useState(Date.now())
  const len = lock.len || 4
  const waiting = waitUntil > now

  useEffect(() => {
    if (!waiting) return
    const t = setInterval(() => setNow(Date.now()), 500)
    return () => clearInterval(t)
  }, [waiting])

  async function check(v) {
    const ok = (await hashPin(v, lock.salt)) === lock.pinHash
    if (ok) return onUnlock()
    const f = fails + 1
    setFails(f)
    setPin('')
    if (f >= 5) {
      setWaitUntil(Date.now() + 30000)
      setNow(Date.now())
      setFails(0)
      setErr(tr('محاولات كثيرة — انتظر 30 ثانية'))
    } else setErr(tr('الرمز غير صحيح'))
  }

  function press(d) {
    if (waiting) return
    setErr('')
    const v = (pin + d).slice(0, len)
    setPin(v)
    if (v.length === len) check(v)
  }

  async function useBio() {
    setErr('')
    try { if (await verifyBio(lock)) onUnlock() } catch (e) { setErr(bioErrorText(e)) }
  }

  function forgot() {
    clearLock(uid)
    try { sessionStorage.removeItem(UNLOCK(uid)) } catch { /* ignore */ }
    auth.signOut()
  }

  const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9']
  const keyCls = 'flex h-16 items-center justify-center rounded-2xl border border-white/[0.07] bg-white/[0.04] font-display text-[24px] font-black text-white transition hover:bg-white/[0.08] active:scale-95'

  return (
    <div className="flex h-full flex-col items-center justify-center overflow-y-auto bg-[#060b18] bg-[radial-gradient(ellipse_at_top,rgba(16,185,129,0.12),transparent_60%)] px-6 pb-[calc(env(safe-area-inset-bottom,0px)+24px)] pt-[calc(env(safe-area-inset-top,0px)+24px)] text-slate-100">
      <div className="w-full max-w-xs">
        <Logo className="mx-auto h-16 w-16" />
        <p className="mt-4 flex items-center justify-center gap-1.5 text-[12px] font-extrabold tracking-wide text-amber-300">
          <Lock size={13} /> {tr('التطبيق مقفل')}
        </p>
        <p className="font-display mt-1 text-center text-[20px] font-black">{name ? tr('أهلاً {name}', { name }) : tr('أدخل رمز القفل')}</p>

        <div dir="ltr" className="mt-6 flex justify-center gap-3">
          {Array.from({ length: len }).map((_, i) => (
            <span key={i} className={`h-3.5 w-3.5 rounded-full border transition ${i < pin.length ? 'border-amber-300 bg-amber-300' : 'border-white/25'}`} />
          ))}
        </div>
        <p className="mt-3 h-5 text-center text-[12.5px] font-bold text-rose-300">
          {waiting ? tr('انتظر {n} ثانية', { n: Math.ceil((waitUntil - now) / 1000) }) : err}
        </p>

        <div dir="ltr" className="mt-3 grid grid-cols-3 gap-3">
          {keys.map((k) => (
            <button key={k} type="button" onClick={() => press(k)} className={keyCls}>{k}</button>
          ))}
          {lock.bio ? (
            <button type="button" onClick={useBio} aria-label={tr('البصمة')} className={`${keyCls} text-emerald-300`}>
              <Fingerprint size={28} />
            </button>
          ) : <span />}
          <button type="button" onClick={() => press('0')} className={keyCls}>0</button>
          <button type="button" onClick={() => { setErr(''); setPin((p) => p.slice(0, -1)) }} aria-label="delete" className={`${keyCls} text-slate-400`}>
            <Delete size={24} />
          </button>
        </div>

        {lock.bio ? (
          <button type="button" onClick={useBio} className="mt-5 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-b from-amber-200 to-amber-400 py-3.5 text-[14px] font-extrabold text-[#1a1206]">
            <Fingerprint size={18} /> {tr('الدخول بالبصمة')}
          </button>
        ) : null}

        <button type="button" onClick={forgot} className="mx-auto mt-5 flex items-center gap-1.5 text-[12px] font-bold text-slate-400 hover:text-slate-200">
          <LogOut size={13} className="rtl:rotate-180" /> {tr('نسيت الرمز؟ سجّل الخروج وادخل من جديد')}
        </button>
      </div>
    </div>
  )
}
