import { useEffect, useRef, useState } from 'react'
import { ShieldCheck, Mail, RefreshCw, Smartphone } from 'lucide-react'
import { auth } from '../lib/auth'
import { email as mailer } from '../lib/email'
import { db } from '../lib/db'
import Logo from './Logo'
import { tr, LangSwitcher } from './i18n'
import { useMode, ThemeToggle, ModeScope } from './theme'

// رمز تحقق بالبريد عند الدخول من أي جهاز جديد: كل جهاز يُوثَّق وحده بعد إدخال الرمز.
// الأجهزة التي كان الحساب يعمل عليها قبل هذا التحديث تبقى موثوقة (لا يُطلب منها رمز من جديد).
const VERIFIED_COLL = 'account_verified'
const DEV_KEY = (uid) => `alg_dev_ok_${uid}`
const KEY = (uid) => `alg_verified_${uid}`
const OLD_KEY = (uid) => `alg_otp_ok_${uid}`

function isVerifiedLocal(uid) {
  try {
    return (
      localStorage.getItem(DEV_KEY(uid)) === '1' ||
      localStorage.getItem(KEY(uid)) === '1' ||
      !!localStorage.getItem(OLD_KEY(uid))
    )
  } catch {
    return false
  }
}

function trustDevice(uid) {
  try { localStorage.setItem(DEV_KEY(uid), '1') } catch { /* ignore */ }
}

function markVerified(uid, addr) {
  trustDevice(uid)
  db.upsert(VERIFIED_COLL, { email: addr || '', at: new Date().toISOString() }, 'me').catch(() => {})
}

/** لم يعد الخروج يطلب رمزاً جديداً — التأكيد مرة واحدة عند إنشاء الحساب */
export function forgetOtp() {}

const toLatin = (s) => String(s || '').replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[۰-۹]/g, (d) => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/\D/g, '')

/**
 * رمز تحقق بالبريد عند أول دخول من كل جهاز جديد (بعدها دخول عادي على نفس الجهاز).
 * حسابات الفريق بالاسم والرمز السري (بلا بريد حقيقي) لا تمر بهذه الشاشة.
 */
export default function OtpGate({ user, children }) {
  const uid = user?.id || null
  const addr = user?.email || ''
  const [state, setState] = useState(() => (!uid || !addr ? 'ok' : isVerifiedLocal(uid) ? 'ok' : 'checking'))

  useEffect(() => {
    let alive = true
    if (!uid || !addr) { setState('ok'); return }
    if (isVerifiedLocal(uid)) { setState('ok'); return }
    // جهاز جديد + حساب له بريد حقيقي → يُطلب الرمز دائماً، حتى للمالك وأعضاء الفريق
    // (حسابات الاسم والرمز السري بلا بريد لا يمكن إرسال رمز لها، فتُعالج أعلاه)
    if (alive) setState('need')
    return () => { alive = false }
  }, [uid, addr])

  if (state === 'ok') return children
  if (state === 'checking') {
    return (
      <div className="flex h-full items-center justify-center bg-[#060b18]">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-white/15 border-t-emerald-400" />
      </div>
    )
  }
  return <OtpScreen addr={addr} onDone={() => { markVerified(uid, addr); setState('ok') }} />
}

function OtpScreen({ addr, onDone }) {
  const { mode, toggle } = useMode('dark')
  const [sent, setSent] = useState(false)
  const [code, setCode] = useState('')
  const [busy, setBusy] = useState(false)
  const [msg, setMsg] = useState(null) // { tone, text }
  const [wait, setWait] = useState(0)
  const inputRef = useRef(null)

  useEffect(() => {
    if (wait <= 0) return undefined
    const t = setTimeout(() => setWait((w) => w - 1), 1000)
    return () => clearTimeout(t)
  }, [wait])

  async function send() {
    if (busy || wait > 0) return
    setBusy(true)
    setMsg(null)
    try {
      await mailer.sendCode(addr, {
        subject: tr('رمز تأكيد جهاز جديد — ALEGDALY TECH'),
        body: tr('طلب أحدهم الدخول إلى حسابك من جهاز جديد.\n\nرمز التأكيد هو {code}\n\nينتهي خلال 10 دقائق. لا تعطِ هذا الرمز لأي شخص، ولا أحد من فريق التطبيق سيطلبه منك.\n\nإذا لم تكن أنت، لا تُدخل الرمز، وغيّر كلمة مرور حسابك فوراً.'),
      })
      setSent(true)
      setWait(60)
      setMsg({ tone: 'ok', text: tr('أرسلنا رمزاً إلى بريدك. افحص البريد الوارد والرسائل غير المرغوبة.') })
      setTimeout(() => inputRef.current?.focus(), 50)
    } catch (e) {
      const secs = Number(e?.body?.retryAfterSeconds) || 0
      if (secs > 0) setWait(secs)
      setMsg({
        tone: 'err',
        text: e?.code === 'RATE_LIMITED'
          ? tr('طلبت رموزاً كثيرة. انتظر {n} ثانية ثم حاول.', { n: secs || 60 })
          : e?.code === 'QUOTA_EXCEEDED'
            ? tr('تعذّر إرسال الرمز الآن (تجاوز حد الرسائل اليومي). حاول لاحقاً.')
            : e?.message || tr('حدث خطأ، حاول مرة أخرى'),
      })
    } finally {
      setBusy(false)
    }
  }

  async function verify(e) {
    e?.preventDefault()
    const c = toLatin(code)
    if (busy || c.length < 4) return
    setBusy(true)
    setMsg(null)
    try {
      const ok = await mailer.checkCode(addr, c)
      if (ok) onDone()
      else {
        setMsg({ tone: 'err', text: tr('الرمز غير صحيح أو منتهي. بعد 5 محاولات خاطئة اطلب رمزاً جديداً.') })
        setCode('')
      }
    } catch (err) {
      setMsg({ tone: 'err', text: err?.message || tr('حدث خطأ، حاول مرة أخرى') })
    } finally {
      setBusy(false)
    }
  }

  return (
    <ModeScope mode={mode}>
      <div className="lux-gate skin-dark relative h-full overflow-y-auto bg-[#050a16]" data-mode={mode}>
        <div aria-hidden="true" className="pointer-events-none fixed inset-0 overflow-hidden">
          <div className="lux-orb absolute -top-40 start-[-10%] h-[440px] w-[440px] rounded-full bg-emerald-500/15 blur-[120px]" />
          <div className="lux-orb lux-orb-2 absolute bottom-[-160px] end-[-8%] h-[480px] w-[480px] rounded-full bg-amber-400/12 blur-[130px]" />
          <div className="lux-grid absolute inset-0" />
        </div>
        <div className="relative z-10 mx-auto flex min-h-full w-full max-w-md flex-col px-5 pb-[calc(env(safe-area-inset-bottom,0px)+24px)] pt-[calc(env(safe-area-inset-top,0px)+16px)]">
          <header className="flex items-center justify-between gap-2">
            <Logo className="h-11 w-11" />
            <div className="flex items-center gap-1.5">
              <ThemeToggle mode={mode} onToggle={toggle} />
              <LangSwitcher compact />
            </div>
          </header>

          <div className="flex flex-1 flex-col justify-center py-10">
            <div className="rise relative">
              <div className="absolute -inset-px rounded-[1.6rem] bg-gradient-to-b from-amber-300/40 via-white/5 to-emerald-400/30" />
              <div className="relative rounded-[1.55rem] bg-gradient-to-b from-[#101a30]/95 to-[#080e1c]/95 p-6 text-center">
                <span className="relative mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-500/10 text-emerald-300">
                  <Smartphone size={26} />
                  <span className="absolute -bottom-1.5 -end-1.5 flex h-6 w-6 items-center justify-center rounded-full bg-amber-400 text-[#1a1206] ring-4 ring-[#0d1628]">
                    <ShieldCheck size={13} />
                  </span>
                </span>
                <p className="font-display mt-4 text-[20px] font-black leading-snug text-white">{tr('تأكيد جهاز جديد')}</p>
                <p className="mt-2 text-[13px] leading-relaxed text-slate-400">
                  {tr('لحماية حسابك، نطلب رمز تحقق عند الدخول من أي جهاز جديد. أرسل الرمز إلى بريدك وأدخله هنا — بعدها لا يُطلب على هذا الجهاز مرة أخرى.')}
                </p>
                <p className="mt-3 inline-flex max-w-full items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5 text-[12px] font-bold text-slate-200" dir="ltr">
                  <Mail size={13} className="shrink-0 text-amber-300" />
                  <span className="truncate">{addr}</span>
                </p>

                {sent ? (
                  <form onSubmit={verify} className="mt-5">
                    <input
                      ref={inputRef}
                      value={code}
                      onChange={(e) => setCode(toLatin(e.target.value).slice(0, 8))}
                      inputMode="numeric"
                      autoComplete="one-time-code"
                      dir="ltr"
                      placeholder="••••••"
                      className="w-full rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-3.5 text-center font-display text-[26px] font-black tracking-[0.5em] text-white outline-none placeholder:text-slate-600 focus:border-emerald-400/60 focus:ring-4 focus:ring-emerald-400/10"
                    />
                    <button
                      type="submit"
                      disabled={busy || toLatin(code).length < 4}
                      className="mt-3 w-full rounded-2xl bg-gradient-to-br from-emerald-400 to-emerald-600 py-3.5 text-[15px] font-extrabold text-[#04140d] disabled:opacity-50"
                    >
                      {busy ? tr('جارٍ التحقق...') : tr('تأكيد')}
                    </button>
                    <button
                      type="button"
                      onClick={send}
                      disabled={busy || wait > 0}
                      className="mt-3 inline-flex items-center gap-1.5 text-[12.5px] font-bold text-slate-400 hover:text-white disabled:opacity-50"
                    >
                      <RefreshCw size={13} />
                      {wait > 0 ? tr('إعادة الإرسال بعد {n} ث', { n: wait }) : tr('أرسل رمزاً جديداً')}
                    </button>
                  </form>
                ) : (
                  <button
                    type="button"
                    onClick={send}
                    disabled={busy || wait > 0}
                    className="mt-5 w-full rounded-2xl bg-gradient-to-br from-emerald-400 to-emerald-600 py-3.5 text-[15px] font-extrabold text-[#04140d] disabled:opacity-50"
                  >
                    {busy ? tr('جارٍ الإرسال...') : wait > 0 ? tr('إعادة الإرسال بعد {n} ث', { n: wait }) : tr('أرسل رمز التحقق')}
                  </button>
                )}

                {msg ? (
                  <p className={`mt-4 rounded-xl px-3 py-2.5 text-[12.5px] font-bold ${msg.tone === 'ok' ? 'bg-emerald-500/10 text-emerald-200' : 'bg-rose-500/10 text-rose-200'}`}>
                    {msg.text}
                  </p>
                ) : null}
              </div>
            </div>

            <button
              type="button"
              onClick={() => auth.signOut()}
              className="mt-4 w-full rounded-2xl border border-white/10 bg-white/[0.03] py-3 text-[13px] font-bold text-slate-300 hover:text-white"
            >
              {tr('الدخول بحساب آخر')}
            </button>
          </div>
        </div>
      </div>
    </ModeScope>
  )
}
