import { push } from '../lib/push'
import { getNotifyPrefs } from './notifyPrefs'
import { fmt } from './fees'

/**
 * إشعار فوري لصاحب المكتب عندما يسجّل الوكيل أي حركة — يصل حتى والتطبيق مغلق
 * إذا فعّل صاحب المكتب الإشعارات. لا يوقف العملية أبداً إذا فشل.
 */
export function notifyOwner(session, { title, body, url = '#/' }) {
  try {
    const mode = session?.mode
    if (mode === 'officeAgent' && session.officeId) {
      // مكتب مشترك: صاحب المكتب = معرّف المكتب
      const ownerId = session.officeId
      getNotifyPrefs(ownerId)
        .then((p) => (p.ops === false ? null : push.send(ownerId, { title, body, url })))
        .catch(() => null)
      return
    }
    if (session?.gid) push.sendToAdmins(session.gid, { title, body, url }).catch(() => null)
  } catch { /* الإشعار لا يمنع الحفظ */ }
}

/** نص الإشعار لحركة الوكيل */
export function agentTxMessage(name, row) {
  const who = name || 'وكيل'
  if (row.kind === 'cash') {
    return { title: '💵 تسليم كاش', body: `${who} سلّم ${fmt(row.amount)} FCFA${row.ref ? ` · ${row.ref}` : ''}`, url: '#/cash' }
  }
  if (row.direction === 'in') {
    return { title: `⬇️ دخول ${row.app || ''}`.trim(), body: `${who} سجّل دخول ${fmt(row.amount)} FCFA`, url: '#/history' }
  }
  return {
    title: `📤 حوالة ${row.app || ''} جديدة`.trim(),
    body: `${who} حوّل ${fmt(row.amount)} FCFA · عمولة ${fmt(row.clientFee)}${row.cashGiven ? ` · كاش ${fmt(row.cashGiven)}` : ''}`,
    url: '#/history',
  }
}
