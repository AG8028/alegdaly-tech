import { useEffect, useMemo, useRef, useState } from 'react'
import { HashRouter, Routes, Route, NavLink, useLocation, useNavigate, Navigate } from 'react-router-dom'
import { LayoutDashboard, Send, HandCoins, ScrollText, Users, Building2, Crown, Landmark, ListChecks, Plus, Inbox, Scale } from 'lucide-react'
import { auth } from './lib/auth'
import LuxGate from './components/LuxGate'
import { SessionProvider, useSession } from './components/Session'
import { ToastProvider } from './components/ui'
import { LangProvider, LangSwitcher, tr } from './components/i18n'
import Dashboard from './pages/Dashboard'
import Transfer from './pages/Transfer'
import Settlement from './pages/Settlement'
import History from './pages/History'
import Team from './pages/Team'
import Sales from './pages/Sales'
import Offices from './pages/Offices'
import OfficeTeam from './pages/OfficeTeam'
import Libya, { LyProvider, useLyData } from './pages/Libya'
import OfficeJoin, { joinIdFromHash } from './pages/OfficeJoin'
import WorkspaceGate from './components/WorkspaceGate'
import Privacy from './pages/Privacy'
import { daysLeft } from './components/saas'
import AgentShell from './pages/AgentShell'
import Logo from './components/Logo'
import { ThemeProvider, useMode, usePref, ThemeToggle, ModeScope } from './components/theme'
import SignOutButton from './components/SignOut'
import OtpGate from './components/OtpGate'
import { AppLockGate } from './components/AppLock'
import { SettingsButton } from './components/SettingsSheet'
import { useTyping } from './hooks/useTyping'
import { FormFlow } from './hooks/useFormFlow'

function BrandMark({ small = false, title, sub, badge }) {
  return (
    <div className="flex min-w-0 items-center gap-2.5">
      <Logo className={`shrink-0 ${small ? 'h-11 w-11' : 'h-14 w-14'}`} />
      <div className="min-w-0 leading-tight">
        <p className={`font-display truncate font-extrabold tracking-tight text-white ${small ? 'text-[14px]' : 'text-[17px]'}`}>
          {title || tr('الأقدالي للتقنية')}
        </p>
        <p className="truncate text-[9.5px] font-bold tracking-[0.14em] text-emerald-400/70">{sub || `ALEGDALY TECH · ${tr('تحويلات')}`}</p>
        {badge ? (
          <span className="mt-1 inline-flex items-center gap-1 rounded-full border border-amber-300/35 bg-amber-400/10 px-2 py-[1px] text-[9.5px] font-extrabold text-amber-200">
            <Crown size={9} className="shrink-0" />
            {badge}
          </span>
        ) : null}
      </div>
    </div>
  )
}

function ScrollReset({ scrollRef }) {
  const { pathname } = useLocation()
  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = 0
  }, [pathname, scrollRef])
  return null
}

const SECTION_KEY = 'alg_section'
const isLyPath = (p) => p === '/ly' || p.startsWith('/ly/')

/** مبدّل الأقسام: سيفا / ليبيا — التبديل يكون فقط بلمس هذا الزر */
function SectionSwitch({ inLy, full = false }) {
  const navigate = useNavigate()
  const opt = (ly, Icon, label, sub) => {
    const active = ly === inLy
    return (
      <button
        type="button"
        onClick={() => { if (!active) navigate(ly ? '/ly' : '/') }}
        aria-pressed={active}
        className={`flex min-h-[40px] flex-1 items-center justify-center gap-1.5 rounded-[10px] px-3 text-[12px] font-extrabold transition ${
          active
            ? ly ? 'bg-amber-400 text-[#1a1206] shadow-[0_6px_18px_-8px_rgba(251,191,36,0.9)]' : 'bg-emerald-500 text-emerald-950 shadow-[0_6px_18px_-8px_rgba(16,185,129,0.9)]'
            : 'text-slate-400 hover:bg-white/[0.06] hover:text-slate-200'
        }`}
      >
        <Icon size={14} />
        <span>{label}</span>
        <span className={`text-[9.5px] font-black tracking-wider ${active ? 'opacity-70' : 'opacity-50'}`}>{sub}</span>
      </button>
    )
  }
  return (
    <div className={`flex gap-1 rounded-xl border border-white/10 bg-black/30 p-1 ${full ? 'w-full' : ''}`}>
      {opt(false, LayoutDashboard, tr('سيفا'), 'FCFA')}
      {opt(true, Landmark, tr('ليبيا'), 'LYD')}
    </div>
  )
}

function OwnerShell() {
  const { pathname } = useLocation()
  const inLy = isLyPath(pathname)
  const navigate = useNavigate()
  // تذكّر آخر قسم اختاره المستخدم — يفتح التطبيق عليه في المرة القادمة
  useEffect(() => {
    try { localStorage.setItem(SECTION_KEY, inLy ? 'ly' : 'cfa') } catch { /* ignore */ }
  }, [inLy])
  const restored = useRef(false)
  useEffect(() => {
    if (restored.current) return
    restored.current = true
    try {
      if (pathname === '/' && localStorage.getItem(SECTION_KEY) === 'ly') navigate('/ly', { replace: true })
    } catch { /* ignore */ }
  }, [pathname, navigate])
  // بيانات قسم ليبيا لا تُحمَّل إلا داخل القسم — قسم سيفا لا يتأثر
  return inLy ? (
    <LyProvider>
      <ShellFrame inLy />
    </LyProvider>
  ) : (
    <ShellFrame inLy={false} />
  )
}

function ShellFrame({ inLy }) {
  const { roster, isOffice, officeName, officeStatus, subState, pendingMembers } = useSession()
  const ly = useLyData()
  const scrollRef = useRef(null)
  const typing = useTyping()
  const { mode, toggle } = useMode('dark')
  const days = isOffice ? daysLeft(officeStatus?.expiresAt) : null
  const brandTitle = isOffice ? officeName : null
  const brandSub = isOffice ? 'ALEGDALY TECH' : null
  const brandBadge = isOffice ? tr('مكتب مشترك') : null

  const lyIn = inLy ? ly?.inPending || 0 : 0
  const lyReq = inLy ? ly?.reqPending || 0 : 0
  const nav = useMemo(
    () => inLy ? [
      { to: '/ly', label: tr('الرئيسية'), icon: LayoutDashboard, end: true },
      { to: '/ly/list', label: tr('الحوالات'), icon: ListChecks },
      { to: '/ly/new', label: tr('جديدة'), icon: Plus },
      { to: '/ly/in', label: tr('الواردة'), icon: Inbox, badge: lyIn },
      { to: '/ly/clear', label: tr('المقاصة'), icon: Scale },
      { to: '/ly/offices', label: tr('المكاتب'), icon: Building2, badge: lyReq },
    ] : [
      { to: '/', label: tr('الرئيسية'), icon: LayoutDashboard, end: true },
      { to: '/transfer', label: tr('حوالة'), icon: Send },
      { to: '/cash', label: tr('تصفية'), icon: HandCoins },
      { to: '/history', label: tr('السجل'), icon: ScrollText },
      { to: '/team', label: tr('الوكلاء'), icon: Users, badge: isOffice ? pendingMembers.length : 0 },
      ...(isOffice ? [] : [{ to: '/sales', label: tr('المكاتب'), icon: Building2 }]),
    ],
    [inLy, isOffice, pendingMembers.length, lyIn, lyReq],
  )
  const activeTab = inLy ? 'bg-amber-400/15 text-amber-100' : 'bg-emerald-500/15 text-emerald-200'
  const activeIcon = inLy ? 'text-amber-300' : 'text-emerald-300'
  const activePill = inLy ? 'bg-amber-400/15' : 'bg-emerald-500/15'

  const subBanner = isOffice ? (
    <a
      href="#/offices"
      className={`flex items-center justify-between gap-2 rounded-2xl border px-3 py-2.5 text-[11.5px] font-extrabold transition ${
        subState === 'ending'
          ? 'border-amber-400/40 bg-amber-500/10 text-amber-200 hover:bg-amber-500/20'
          : 'border-white/[0.07] bg-white/[0.03] text-slate-300 hover:bg-white/[0.06]'
      }`}
    >
      <span className="flex items-center gap-1.5">
        <Crown size={14} className="text-amber-300" />
        {tr('الاشتراك')}: {tr('باقي {n} يوم', { n: Math.max(0, days || 0) })}
      </span>
      <span className="text-amber-300">{tr('تجديد')}</span>
    </a>
  ) : null

  const links = nav.map((item) => (
    <NavLink
      key={item.to}
      to={item.to}
      end={item.end}
      className={({ isActive }) =>
        `flex flex-1 items-center gap-2.5 rounded-xl px-3 py-2.5 text-[13px] font-bold transition ${
          isActive ? activeTab : 'text-slate-400 hover:bg-white/[0.05] hover:text-slate-200'
        }`
      }
    >
      <item.icon size={17} />
      <span className="flex-1">{item.label}</span>
      {item.badge ? <span className="rounded-full bg-amber-400 px-1.5 text-[10px] font-black text-[#1a1206]">{item.badge}</span> : null}
    </NavLink>
  ))

  const tabs = nav.map((item) => (
    <NavLink
      key={item.to}
      to={item.to}
      end={item.end}
      className={({ isActive }) =>
        `flex min-w-0 flex-1 flex-col items-center gap-1 py-2.5 text-[10px] font-bold transition ${
          isActive ? activeIcon : 'text-slate-500'
        }`
      }
    >
      {({ isActive }) => (
        <>
          <span className={`relative flex h-8 w-11 items-center justify-center rounded-xl transition ${isActive ? activePill : ''}`}>
            <item.icon size={18} />
            {item.badge ? (
              <span className="absolute -top-1 end-0.5 min-w-[16px] rounded-full bg-amber-400 px-1 text-[9.5px] font-black leading-4 text-[#1a1206]">{item.badge}</span>
            ) : null}
          </span>
          {item.label}
        </>
      )}
    </NavLink>
  ))

  return (
    <ModeScope mode={mode}>
    <div className="skin-dark flex h-full bg-[#060b18] text-slate-100" data-mode={mode}>
      <aside className="skin-aside hidden h-full min-h-0 w-64 shrink-0 flex-col overflow-y-auto overscroll-contain [&>*]:shrink-0 border-e border-white/[0.07] bg-gradient-to-b from-[#0a1526] to-[#060b18] px-4 pb-6 pt-[calc(env(safe-area-inset-top,0px)+24px)] md:flex">
        <div className="px-1">
          <BrandMark title={brandTitle} sub={brandSub} badge={brandBadge} />
        </div>
        <div className="mt-6">
          <SectionSwitch inLy={inLy} full />
        </div>
        <nav className="mt-4 flex flex-col gap-1">
          {links}
        </nav>
        <div className="mt-auto space-y-3">
          {inLy ? null : subBanner}
          <LangSwitcher />
          <ThemeToggle mode={mode} onToggle={toggle} withLabel />
          <SettingsButton mode={mode} variant="side" />
          <div className="rounded-2xl border border-white/[0.07] bg-white/[0.03] p-3">
            <p className="text-[11px] font-bold text-slate-500">{tr('عدد الوكلاء')}</p>
            <p className="font-display text-[19px] font-black text-white">{roster.length}</p>
          </div>
          <SignOutButton variant="side" mode={mode} />
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        {typing ? <div className="app-top-gap shrink-0 md:hidden" /> : (
        <header className="relative z-20 shrink-0 border-b border-white/[0.07] bg-[#081120]/90 px-4 pb-3 app-top-safe backdrop-blur-xl md:hidden">
          <div className="flex items-center justify-between gap-2">
            <div className="min-w-0 flex-1">
              <BrandMark small title={brandTitle} sub={brandSub} badge={brandBadge} />
            </div>
            <div className="flex shrink-0 items-center gap-1.5">
              <SettingsButton mode={mode} />
              <ThemeToggle mode={mode} onToggle={toggle} />
              <SignOutButton mode={mode} />
            </div>
          </div>
          <div className="mt-2 flex items-center gap-2">
            <div className="min-w-0 flex-1">
              <SectionSwitch inLy={inLy} full />
            </div>
            <LangSwitcher compact />
          </div>
          {subBanner && !inLy ? <div className="mt-2">{subBanner}</div> : null}
        </header>
        )}

        <main ref={scrollRef} className="min-h-0 flex-1 overflow-y-auto">
          <ScrollReset scrollRef={scrollRef} />
          <div className={`mx-auto w-full max-w-6xl px-4 py-5 md:px-8 md:py-8 md:pb-10 ${typing ? 'pb-[45vh]' : 'pb-[calc(6.5rem+env(safe-area-inset-bottom,0px))]'}`}>
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/transfer" element={<Transfer />} />
              <Route path="/cash" element={<Settlement />} />
              <Route path="/history" element={<History />} />
              <Route path="/team" element={isOffice ? <OfficeTeam /> : <Team />} />
              {!isOffice && <Route path="/sales" element={<Sales />} />}
              <Route path="/ly" element={<Libya />} />
              <Route path="/ly/:tab" element={<Libya />} />
              <Route path="/libya" element={<Navigate to="/ly" replace />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </div>
        </main>
      </div>

      {typing ? null : (
      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-white/[0.08] bg-[#081120]/95 pb-[env(safe-area-inset-bottom,0px)] backdrop-blur-xl md:hidden">
        <div className="flex items-stretch">{tabs}</div>
      </nav>
      )}
    </div>
    </ModeScope>
  )
}


function Router() {
  const { ready, canManage, workspace } = useSession()
  // شاشة التحميل تتبع الوضع المختار حتى لا تومض
  const mode = usePref() || 'dark'
  if (!ready) {
    return (
      <div className={`flex h-full items-center justify-center ${mode === 'light' ? 'bg-[#f6f4ee]' : 'bg-[#060b18]'}`}>
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-white/15 border-t-emerald-400" />
      </div>
    )
  }
  if (workspace !== 'ok') return <WorkspaceGate />
  return canManage ? <OwnerShell /> : <AgentShell />
}

const isOfficesHash = () => {
  try { return window.location.hash.startsWith('#/offices') } catch { return false }
}

const isPrivacyUrl = () => {
  try {
    return /\/privacy\/?$/.test(window.location.pathname) || window.location.hash.startsWith('#/privacy')
  } catch { return false }
}

const publicPage = () => (isPrivacyUrl() ? 'privacy' : isOfficesHash() ? 'offices' : joinIdFromHash() ? 'join' : null)

function Root() {
  const [user, setUser] = useState(() => auth.getCurrentUser())
  const [page, setPage] = useState(publicPage)
  const [joinId, setJoinId] = useState(joinIdFromHash)

  useEffect(() => auth.onAuthChange((u) => setUser(u)), [])
  // هذا الجهاز يخص المالك الأساسي → يظهر له زر الدخول بحساب المالك في شاشة الدخول
  useEffect(() => {
    if (!user) return
    try {
      if (auth.isAppOwner()) localStorage.setItem('alg_owner_device', '1')
    } catch { /* ignore */ }
  }, [user])
  useEffect(() => {
    const on = () => {
      setPage(publicPage())
      setJoinId(joinIdFromHash())
    }
    window.addEventListener('hashchange', on)
    return () => window.removeEventListener('hashchange', on)
  }, [])

  // سياسة الخصوصية — عامة تماماً، تفتح بدون تسجيل دخول
  if (page === 'privacy') return <Privacy />

  // صفحة اشتراك المكاتب — عامة، لا تحتاج حساب وكيل
  if (page === 'offices') {
    return (
      <OtpGate user={user}>
        <ToastProvider>
          <Offices />
        </ToastProvider>
      </OtpGate>
    )
  }

  // رابط انضمام وكيل إلى مكتب مشترك
  if (page === 'join' && joinId) {
    return (
      <OtpGate user={user}>
        <ToastProvider>
          <OfficeJoin officeId={joinId} />
        </ToastProvider>
      </OtpGate>
    )
  }

  if (!user) return <LuxGate />

  return (
    <OtpGate user={user}>
      <AppLockGate user={user}>
        <ToastProvider>
          <HashRouter>
            <SessionProvider>
              <Router />
            </SessionProvider>
          </HashRouter>
        </ToastProvider>
      </AppLockGate>
    </OtpGate>
  )
}

export default function App() {
  return (
    <LangProvider>
      <ThemeProvider>
        <FormFlow />
        <Root />
      </ThemeProvider>
    </LangProvider>
  )
}
